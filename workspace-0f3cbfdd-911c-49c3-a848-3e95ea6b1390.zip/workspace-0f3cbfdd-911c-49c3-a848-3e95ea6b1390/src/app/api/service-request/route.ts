import { NextRequest, NextResponse } from 'next/server'

interface ServiceRequest {
  serviceName: string
  serviceUrl: string
  serviceDescription?: string
  userId?: string
  timestamp: number
}

// In-memory storage for demo purposes
// In production, this would be stored in a database
const serviceRequests: ServiceRequest[] = []

export async function POST(request: NextRequest) {
  try {
    const { serviceName, serviceUrl, serviceDescription, userId } = await request.json()

    // Validate required fields
    if (!serviceName || !serviceUrl) {
      return NextResponse.json(
        { error: 'Service name and URL are required' },
        { status: 400 }
      )
    }

    // Validate URL format
    try {
      new URL(serviceUrl)
    } catch {
      return NextResponse.json(
        { error: 'Invalid URL format' },
        { status: 400 }
      )
    }

    // Create service request
    const serviceRequest: ServiceRequest = {
      serviceName: serviceName.trim(),
      serviceUrl: serviceUrl.trim(),
      serviceDescription: serviceDescription?.trim(),
      userId: userId || 'anonymous',
      timestamp: Date.now()
    }

    // Store the request
    serviceRequests.push(serviceRequest)

    // Log the request (in production, this would be saved to database)
    console.log('New service request:', serviceRequest)

    // Simulate processing delay
    await new Promise(resolve => setTimeout(resolve, 500))

    return NextResponse.json({
      message: 'Service request submitted successfully',
      requestId: serviceRequests.length,
      service: {
        name: serviceRequest.serviceName,
        url: serviceRequest.serviceUrl,
        description: serviceRequest.serviceDescription
      }
    })

  } catch (error) {
    console.error('Error processing service request:', error)
    return NextResponse.json(
      { error: 'Failed to process service request' },
      { status: 500 }
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')

    // In production, you would filter by user and implement pagination
    let requests = serviceRequests

    if (userId) {
      requests = requests.filter(req => req.userId === userId)
    }

    // Sort by timestamp (newest first)
    requests.sort((a, b) => b.timestamp - a.timestamp)

    return NextResponse.json({
      requests: requests,
      total: requests.length
    })

  } catch (error) {
    console.error('Error fetching service requests:', error)
    return NextResponse.json(
      { error: 'Failed to fetch service requests' },
      { status: 500 }
    )
  }
}