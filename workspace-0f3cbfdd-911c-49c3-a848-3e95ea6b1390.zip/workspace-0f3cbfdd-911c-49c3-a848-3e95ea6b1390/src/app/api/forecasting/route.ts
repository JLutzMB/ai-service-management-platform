import { NextRequest, NextResponse } from 'next/server'
import { ForecastingService } from '@/lib/forecasting-service'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const serviceId = searchParams.get('serviceId')
    const timeframe = searchParams.get('timeframe') as '7d' | '30d' | '90d' | null

    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      )
    }

    const forecastingService = ForecastingService.getInstance()

    if (serviceId) {
      // Generate forecast for specific service
      const forecast = await forecastingService.generateServiceForecast(
        serviceId, 
        timeframe || '30d'
      )
      return NextResponse.json(forecast)
    } else {
      // Generate budget prediction for user
      const budgetPrediction = await forecastingService.generateBudgetPrediction(userId)
      return NextResponse.json(budgetPrediction)
    }

  } catch (error) {
    console.error('Forecasting error:', error)
    return NextResponse.json(
      { error: 'Failed to generate forecast' },
      { status: 500 }
    )
  }
}