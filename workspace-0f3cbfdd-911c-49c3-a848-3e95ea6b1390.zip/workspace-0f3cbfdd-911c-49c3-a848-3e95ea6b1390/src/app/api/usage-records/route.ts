import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const serviceId = searchParams.get('serviceId')
    const userId = searchParams.get('userId')
    const startDate = searchParams.get('startDate')
    const endDate = searchParams.get('endDate')

    if (!serviceId && !userId) {
      return NextResponse.json(
        { error: 'Service ID or User ID is required' },
        { status: 400 }
      )
    }

    const whereClause: any = {}
    if (serviceId) {
      whereClause.aiServiceId = serviceId
    }
    if (userId) {
      whereClause.aiService = { userId }
    }
    if (startDate && endDate) {
      whereClause.date = {
        gte: new Date(startDate),
        lte: new Date(endDate)
      }
    }

    const usageRecords = await db.usageRecord.findMany({
      where: whereClause,
      include: {
        aiService: {
          select: {
            id: true,
            name: true,
            provider: true
          }
        }
      },
      orderBy: { date: 'desc' },
      take: 1000
    })

    return NextResponse.json(usageRecords)
  } catch (error) {
    console.error('Error fetching usage records:', error)
    return NextResponse.json(
      { error: 'Failed to fetch usage records' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const {
      serviceId,
      tokensUsed,
      creditsUsed,
      cost,
      model,
      endpoint
    } = body

    if (!serviceId || !tokensUsed) {
      return NextResponse.json(
        { error: 'Service ID and tokens used are required' },
        { status: 400 }
      )
    }

    // Check if service exists
    const service = await db.aIService.findUnique({
      where: { id: serviceId }
    })

    if (!service) {
      return NextResponse.json(
        { error: 'Service not found' },
        { status: 404 }
      )
    }

    // Create usage record
    const usageRecord = await db.usageRecord.create({
      data: {
        aiServiceId: serviceId,
        tokensUsed: parseFloat(tokensUsed),
        creditsUsed: creditsUsed ? parseFloat(creditsUsed) : 0,
        cost: cost ? parseFloat(cost) : null,
        model,
        endpoint
      }
    })

    // Update service totals
    await db.aIService.update({
      where: { id: serviceId },
      data: {
        tokens: {
          decrement: parseFloat(tokensUsed)
        },
        credits: creditsUsed ? {
          decrement: parseFloat(creditsUsed)
        } : undefined
      }
    })

    return NextResponse.json(usageRecord, { status: 201 })
  } catch (error) {
    console.error('Error creating usage record:', error)
    return NextResponse.json(
      { error: 'Failed to create usage record' },
      { status: 500 }
    )
  }
}