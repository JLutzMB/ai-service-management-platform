import { NextRequest, NextResponse } from 'next/server'
import { SyncService } from '@/lib/sync-service'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { userId, serviceId } = body

    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      )
    }

    const syncService = SyncService.getInstance()

    if (serviceId) {
      // Sync specific service
      const result = await syncService.syncService(serviceId)
      return NextResponse.json(result)
    } else {
      // Sync all services for user
      const results = await syncService.syncAllServices(userId)
      return NextResponse.json({
        success: true,
        message: 'Sync completed',
        results
      })
    }
  } catch (error) {
    console.error('Sync error:', error)
    return NextResponse.json(
      { error: 'Failed to sync services' },
      { status: 500 }
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const serviceId = searchParams.get('serviceId')

    if (!serviceId) {
      return NextResponse.json(
        { error: 'Service ID is required' },
        { status: 400 }
      )
    }

    const syncService = SyncService.getInstance()
    const status = await syncService.getSyncStatus(serviceId)

    return NextResponse.json(status)
  } catch (error) {
    console.error('Error getting sync status:', error)
    return NextResponse.json(
      { error: 'Failed to get sync status' },
      { status: 500 }
    )
  }
}