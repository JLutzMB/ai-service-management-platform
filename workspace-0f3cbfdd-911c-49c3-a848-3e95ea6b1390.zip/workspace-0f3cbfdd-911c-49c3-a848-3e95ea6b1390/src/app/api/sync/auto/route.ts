import { NextRequest, NextResponse } from 'next/server'
import { SyncService } from '@/lib/sync-service'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { userId, serviceId, action, intervalMinutes } = body

    if (!userId || !serviceId || !action) {
      return NextResponse.json(
        { error: 'User ID, service ID, and action are required' },
        { status: 400 }
      )
    }

    const syncService = SyncService.getInstance()

    switch (action) {
      case 'start':
        const interval = intervalMinutes || 30
        await syncService.startAutoSync(serviceId, interval)
        return NextResponse.json({
          success: true,
          message: `Auto-sync started with ${interval} minute interval`
        })

      case 'stop':
        syncService.stopAutoSync(serviceId)
        return NextResponse.json({
          success: true,
          message: 'Auto-sync stopped'
        })

      default:
        return NextResponse.json(
          { error: 'Invalid action. Use "start" or "stop"' },
          { status: 400 }
        )
    }
  } catch (error) {
    console.error('Auto-sync error:', error)
    return NextResponse.json(
      { error: 'Failed to manage auto-sync' },
      { status: 500 }
    )
  }
}