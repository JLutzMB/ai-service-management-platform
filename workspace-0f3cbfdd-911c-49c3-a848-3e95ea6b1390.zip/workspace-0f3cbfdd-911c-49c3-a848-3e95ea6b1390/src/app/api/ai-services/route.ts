import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      )
    }

    const services = await db.aIService.findMany({
      where: { userId },
      include: {
        usageRecords: {
          orderBy: { date: 'desc' },
          take: 30
        }
      },
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json(services)
  } catch (error) {
    console.error('Error fetching AI services:', error)
    return NextResponse.json(
      { error: 'Failed to fetch AI services' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const {
      userId,
      name,
      provider,
      apiKey,
      baseUrl,
      credits,
      tokens,
      creditLimit,
      tokenLimit,
      planType,
      billingCycle,
      renewalDate,
      pricePer1kTokens,
      monthlyCost,
      currency
    } = body

    if (!userId || !name || !provider) {
      return NextResponse.json(
        { error: 'User ID, name, and provider are required' },
        { status: 400 }
      )
    }

    const service = await db.aIService.create({
      data: {
        userId,
        name,
        provider,
        authType: apiKey ? 'api-key' : 'none',
        apiKey,
        baseUrl,
        credits: credits ? parseFloat(credits) : null,
        tokens: tokens ? parseFloat(tokens) : null,
        creditLimit: creditLimit ? parseFloat(creditLimit) : null,
        tokenLimit: tokenLimit ? parseFloat(tokenLimit) : null,
        planType,
        billingCycle,
        renewalDate: renewalDate ? new Date(renewalDate) : null,
        pricePer1kTokens: pricePer1kTokens ? parseFloat(pricePer1kTokens) : null,
        monthlyCost: monthlyCost ? parseFloat(monthlyCost) : null,
        currency: currency || 'USD'
      }
    })

    return NextResponse.json(service, { status: 201 })
  } catch (error) {
    console.error('Error creating AI service:', error)
    return NextResponse.json(
      { error: 'Failed to create AI service' },
      { status: 500 }
    )
  }
}