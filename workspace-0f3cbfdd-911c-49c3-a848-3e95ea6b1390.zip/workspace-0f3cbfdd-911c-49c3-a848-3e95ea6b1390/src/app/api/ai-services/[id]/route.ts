import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const service = await db.aIService.findUnique({
      where: { id: params.id },
      include: {
        usageRecords: {
          orderBy: { date: 'desc' },
          take: 100
        }
      }
    })

    if (!service) {
      return NextResponse.json(
        { error: 'Service not found' },
        { status: 404 }
      )
    }

    return NextResponse.json(service)
  } catch (error) {
    console.error('Error fetching AI service:', error)
    return NextResponse.json(
      { error: 'Failed to fetch AI service' },
      { status: 500 }
    )
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json()
    const {
      name,
      provider,
      apiKey,
      baseUrl,
      isActive,
      credits,
      tokens,
      creditLimit,
      tokenLimit,
      planType,
      billingCycle,
      renewalDate,
      pricePer1kTokens,
      monthlyCost,
      currency
    } = body

    const service = await db.aIService.update({
      where: { id: params.id },
      data: {
        ...(name && { name }),
        ...(provider && { provider }),
        ...(apiKey !== undefined && { apiKey }),
        ...(baseUrl !== undefined && { baseUrl }),
        ...(isActive !== undefined && { isActive }),
        ...(credits !== undefined && { credits: credits ? parseFloat(credits) : null }),
        ...(tokens !== undefined && { tokens: tokens ? parseFloat(tokens) : null }),
        ...(creditLimit !== undefined && { creditLimit: creditLimit ? parseFloat(creditLimit) : null }),
        ...(tokenLimit !== undefined && { tokenLimit: tokenLimit ? parseFloat(tokenLimit) : null }),
        ...(planType !== undefined && { planType }),
        ...(billingCycle !== undefined && { billingCycle }),
        ...(renewalDate !== undefined && { renewalDate: renewalDate ? new Date(renewalDate) : null }),
        ...(pricePer1kTokens !== undefined && { pricePer1kTokens: pricePer1kTokens ? parseFloat(pricePer1kTokens) : null }),
        ...(monthlyCost !== undefined && { monthlyCost: monthlyCost ? parseFloat(monthlyCost) : null }),
        ...(currency !== undefined && { currency })
      }
    })

    return NextResponse.json(service)
  } catch (error) {
    console.error('Error updating AI service:', error)
    return NextResponse.json(
      { error: 'Failed to update AI service' },
      { status: 500 }
    )
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await db.aIService.delete({
      where: { id: params.id }
    })

    return NextResponse.json({ message: 'Service deleted successfully' })
  } catch (error) {
    console.error('Error deleting AI service:', error)
    return NextResponse.json(
      { error: 'Failed to delete AI service' },
      { status: 500 }
    )
  }
}