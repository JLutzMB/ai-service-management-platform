import { NextRequest, NextResponse } from 'next/server'
import { NotificationService } from '@/lib/notification-service'

export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json()
    const { action, userId } = body

    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      )
    }

    const notificationService = NotificationService.getInstance()

    switch (action) {
      case 'mark_read':
        await notificationService.markAsRead(params.id, userId)
        return NextResponse.json({ success: true, message: 'Notification marked as read' })

      case 'delete':
        await notificationService.deleteNotification(params.id, userId)
        return NextResponse.json({ success: true, message: 'Notification deleted' })

      default:
        return NextResponse.json(
          { error: 'Invalid action. Use "mark_read" or "delete"' },
          { status: 400 }
        )
    }
  } catch (error) {
    console.error('Error updating notification:', error)
    return NextResponse.json(
      { error: 'Failed to update notification' },
      { status: 500 }
    )
  }
}