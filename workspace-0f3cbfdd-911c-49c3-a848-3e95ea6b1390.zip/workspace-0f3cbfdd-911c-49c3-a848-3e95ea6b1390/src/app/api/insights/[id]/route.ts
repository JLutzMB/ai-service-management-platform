import { NextRequest, NextResponse } from 'next/server'
import { InsightsEngine } from '@/lib/insights-engine'

export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json()
    const { action, userId } = body

    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      )
    }

    const insightsEngine = InsightsEngine.getInstance()

    switch (action) {
      case 'dismiss':
        await insightsEngine.dismissInsight(params.id, userId)
        return NextResponse.json({ success: true, message: 'Insight dismissed' })

      default:
        return NextResponse.json(
          { error: 'Invalid action. Use "dismiss"' },
          { status: 400 }
        )
    }
  } catch (error) {
    console.error('Error updating insight:', error)
    return NextResponse.json(
      { error: 'Failed to update insight' },
      { status: 500 }
    )
  }
}