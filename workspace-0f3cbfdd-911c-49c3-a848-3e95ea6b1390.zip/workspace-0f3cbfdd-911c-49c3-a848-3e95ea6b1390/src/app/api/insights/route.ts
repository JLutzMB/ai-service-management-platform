import { NextRequest, NextResponse } from 'next/server'
import { InsightsEngine } from '@/lib/insights-engine'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const type = searchParams.get('type')

    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      )
    }

    const insightsEngine = InsightsEngine.getInstance()
    const insights = await insightsEngine.getInsights(userId, type || undefined)

    return NextResponse.json(insights)
  } catch (error) {
    console.error('Error fetching insights:', error)
    return NextResponse.json(
      { error: 'Failed to fetch insights' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { userId } = body

    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      )
    }

    const insightsEngine = InsightsEngine.getInstance()
    const insights = await insightsEngine.generateInsights(userId)

    return NextResponse.json({
      success: true,
      message: 'Insights generated successfully',
      insights,
      count: insights.length
    })
  } catch (error) {
    console.error('Error generating insights:', error)
    return NextResponse.json(
      { error: 'Failed to generate insights' },
      { status: 500 }
    )
  }
}