import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST(request: NextRequest) {
  try {
    const { userId } = await request.json();

    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      );
    }

    // Fetch all user data
    const user = await db.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        email: true,
        name: true,
        createdAt: true,
        updatedAt: true,
        subscriptionTier: true,
        subscriptionStatus: true,
        subscriptionExpiresAt: true
      }
    });

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    // Fetch user's AI services
    const services = await db.aIService.findMany({
      where: { userId },
      select: {
        id: true,
        name: true,
        provider: true,
        isActive: true,
        authType: true,
        createdAt: true,
        updatedAt: true,
        credits: true,
        tokens: true,
        creditLimit: true,
        tokenLimit: true,
        planType: true,
        renewalDate: true,
        pricePer1kTokens: true,
        monthlyCost: true,
        currency: true
      }
    });

    // Fetch usage records
    const usageRecords = await db.usageRecord.findMany({
      where: {
        aiService: {
          userId: userId
        }
      },
      select: {
        id: true,
        date: true,
        tokensUsed: true,
        creditsUsed: true,
        cost: true,
        model: true,
        endpoint: true,
        aiServiceId: true
      }
    });

    // Fetch notifications
    const notifications = await db.notification.findMany({
      where: { userId },
      select: {
        id: true,
        type: true,
        title: true,
        message: true,
        isRead: true,
        createdAt: true,
        serviceId: true
      }
    });

    // Fetch insights
    const insights = await db.insight.findMany({
      where: { userId },
      select: {
        id: true,
        type: true,
        title: true,
        description: true,
        impact: true,
        confidence: true,
        isDismissed: true,
        createdAt: true,
        serviceId: true
      }
    });

    // Compile the export data
    const exportData = {
      user,
      services,
      usageRecords,
      notifications,
      insights,
      exportedAt: new Date().toISOString(),
      version: '1.0'
    };

    // In a real application, you would:
    // 1. Generate a file (JSON, CSV, etc.)
    // 2. Upload it to cloud storage
    // 3. Send an email with download link
    // 4. Store the export record in the database

    // For now, we'll just return the data directly
    return NextResponse.json({ 
      success: true, 
      message: 'Data export completed successfully',
      exportData,
      downloadUrl: `/api/user/export/download?userId=${userId}&timestamp=${Date.now()}`
    });
  } catch (error) {
    console.error('Error exporting user data:', error);
    return NextResponse.json(
      { error: 'Failed to export user data' },
      { status: 500 }
    );
  }
}