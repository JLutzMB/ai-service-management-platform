import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// In a real application, you would store API keys securely in the database
// For now, we'll use a simple in-memory approach
const apiKeys = new Map<string, any[]>();

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');

    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      );
    }

    // Get or create empty array for user
    const userApiKeys = apiKeys.get(userId) || [];

    return NextResponse.json({ apiKeys: userApiKeys });
  } catch (error) {
    console.error('Error fetching API keys:', error);
    return NextResponse.json(
      { error: 'Failed to fetch API keys' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const { userId, name } = await request.json();

    if (!userId || !name) {
      return NextResponse.json(
        { error: 'User ID and name are required' },
        { status: 400 }
      );
    }

    // Generate a new API key
    const newApiKey = {
      id: Date.now().toString(),
      name,
      key: `sk_${Math.random().toString(36).substr(2, 32)}`,
      createdAt: new Date().toISOString().split('T')[0],
      lastUsed: "Never",
      isActive: true
    };

    // Get existing keys or create new array
    const userApiKeys = apiKeys.get(userId) || [];
    userApiKeys.push(newApiKey);
    apiKeys.set(userId, userApiKeys);

    return NextResponse.json({ 
      success: true, 
      apiKey: newApiKey,
      message: 'API key generated successfully'
    });
  } catch (error) {
    console.error('Error generating API key:', error);
    return NextResponse.json(
      { error: 'Failed to generate API key' },
      { status: 500 }
    );
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');
    const keyId = searchParams.get('keyId');

    if (!userId || !keyId) {
      return NextResponse.json(
        { error: 'User ID and Key ID are required' },
        { status: 400 }
      );
    }

    // Get existing keys
    const userApiKeys = apiKeys.get(userId) || [];
    
    // Remove the specified key
    const updatedKeys = userApiKeys.filter(key => key.id !== keyId);
    apiKeys.set(userId, updatedKeys);

    return NextResponse.json({ 
      success: true, 
      message: 'API key revoked successfully' 
    });
  } catch (error) {
    console.error('Error revoking API key:', error);
    return NextResponse.json(
      { error: 'Failed to revoke API key' },
      { status: 500 }
    );
  }
}