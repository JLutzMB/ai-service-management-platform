import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// In a real application, you would store notification preferences in the database
// For now, we'll use a simple in-memory approach
const notificationPreferences = new Map<string, any>();

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');

    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      );
    }

    // Get or create default preferences
    const preferences = notificationPreferences.get(userId) || {
      emailNotifications: true,
      pushNotifications: true,
      usageAlerts: true,
      renewalReminders: true,
      costAlerts: true,
      serviceUpdates: false,
      marketingEmails: false
    };

    return NextResponse.json({ preferences });
  } catch (error) {
    console.error('Error fetching notification preferences:', error);
    return NextResponse.json(
      { error: 'Failed to fetch notification preferences' },
      { status: 500 }
    );
  }
}

export async function PUT(request: NextRequest) {
  try {
    const { userId, preferences } = await request.json();

    if (!userId || !preferences) {
      return NextResponse.json(
        { error: 'User ID and preferences are required' },
        { status: 400 }
      );
    }

    // Store the preferences
    notificationPreferences.set(userId, preferences);

    return NextResponse.json({ 
      success: true, 
      message: 'Notification preferences updated successfully',
      preferences 
    });
  } catch (error) {
    console.error('Error updating notification preferences:', error);
    return NextResponse.json(
      { error: 'Failed to update notification preferences' },
      { status: 500 }
    );
  }
}