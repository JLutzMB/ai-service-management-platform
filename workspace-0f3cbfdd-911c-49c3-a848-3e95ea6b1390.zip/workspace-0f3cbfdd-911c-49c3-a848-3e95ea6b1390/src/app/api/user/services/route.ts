import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');

    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      );
    }

    const services = await db.aIService.findMany({
      where: { userId },
      select: {
        id: true,
        name: true,
        provider: true,
        isActive: true,
        authType: true,
        createdAt: true,
        updatedAt: true,
        credits: true,
        tokens: true,
        creditLimit: true,
        tokenLimit: true,
        planType: true,
        renewalDate: true,
        pricePer1kTokens: true,
        monthlyCost: true,
        currency: true,
        lastSync: true
      }
    });

    return NextResponse.json({ services });
  } catch (error) {
    console.error('Error fetching user services:', error);
    return NextResponse.json(
      { error: 'Failed to fetch user services' },
      { status: 500 }
    );
  }
}

export async function PUT(request: NextRequest) {
  try {
    const { serviceId, userId, updates } = await request.json();

    if (!serviceId || !userId || !updates) {
      return NextResponse.json(
        { error: 'Service ID, User ID, and updates are required' },
        { status: 400 }
      );
    }

    const updatedService = await db.aIService.update({
      where: { 
        id: serviceId,
        userId: userId
      },
      data: {
        ...updates,
        updatedAt: new Date()
      },
      select: {
        id: true,
        name: true,
        provider: true,
        isActive: true,
        updatedAt: true
      }
    });

    return NextResponse.json({ service: updatedService });
  } catch (error) {
    console.error('Error updating service:', error);
    return NextResponse.json(
      { error: 'Failed to update service' },
      { status: 500 }
    );
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const serviceId = searchParams.get('serviceId');
    const userId = searchParams.get('userId');

    if (!serviceId || !userId) {
      return NextResponse.json(
        { error: 'Service ID and User ID are required' },
        { status: 400 }
      );
    }

    await db.aIService.delete({
      where: { 
        id: serviceId,
        userId: userId
      }
    });

    return NextResponse.json({ 
      success: true, 
      message: 'Service deleted successfully' 
    });
  } catch (error) {
    console.error('Error deleting service:', error);
    return NextResponse.json(
      { error: 'Failed to delete service' },
      { status: 500 }
    );
  }
}