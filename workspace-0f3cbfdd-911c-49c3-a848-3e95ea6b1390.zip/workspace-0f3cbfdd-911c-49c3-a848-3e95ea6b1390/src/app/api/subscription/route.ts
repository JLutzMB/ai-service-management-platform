import { NextRequest, NextResponse } from 'next/server'
import { subscriptionService } from '@/lib/subscription-service'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      )
    }

    const subscription = await subscriptionService.getUserSubscription(userId)
    
    if (!subscription) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      )
    }

    const serviceLimit = await subscriptionService.getServiceLimit(userId)
    const canAddService = await subscriptionService.canAddService(userId)
    const isActive = await subscriptionService.checkSubscriptionStatus(userId)

    return NextResponse.json({
      subscription: {
        tier: subscription.subscriptionTier,
        status: subscription.subscriptionStatus,
        expiresAt: subscription.subscriptionExpiresAt,
        isActive
      },
      limits: {
        serviceLimit,
        canAddService
      },
      features: subscriptionService.getSubscriptionFeatures(subscription.subscriptionTier)
    })
  } catch (error) {
    console.error('Error fetching subscription:', error)
    return NextResponse.json(
      { error: 'Failed to fetch subscription' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const { userId, action, tier, billingCycle } = await request.json()

    if (!userId || !action) {
      return NextResponse.json(
        { error: 'User ID and action are required' },
        { status: 400 }
      )
    }

    switch (action) {
      case 'upgrade':
        if (!tier) {
          return NextResponse.json(
            { error: 'Tier is required for upgrade' },
            { status: 400 }
          )
        }
        
        const updatedUser = await subscriptionService.upgradeSubscription(userId, tier)
        
        return NextResponse.json({
          message: 'Subscription upgraded successfully',
          subscription: {
            tier: updatedUser.subscriptionTier,
            status: updatedUser.subscriptionStatus,
            price: subscriptionService.getSubscriptionPrice(tier, billingCycle || 'monthly')
          }
        })

      case 'cancel':
        const cancelledUser = await subscriptionService.cancelSubscription(userId)
        
        return NextResponse.json({
          message: 'Subscription cancelled successfully',
          subscription: {
            tier: cancelledUser.subscriptionTier,
            status: cancelledUser.subscriptionStatus
          }
        })

      case 'check_limit':
        const canAddService = await subscriptionService.canAddService(userId)
        const serviceLimit = await subscriptionService.getServiceLimit(userId)
        
        return NextResponse.json({
          canAddService,
          serviceLimit
        })

      default:
        return NextResponse.json(
          { error: 'Invalid action' },
          { status: 400 }
        )
    }
  } catch (error) {
    console.error('Error managing subscription:', error)
    return NextResponse.json(
      { error: 'Failed to manage subscription' },
      { status: 500 }
    )
  }
}