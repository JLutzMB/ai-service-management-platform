import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const code = searchParams.get('code');
    const state = searchParams.get('state');
    const error = searchParams.get('error');
    const serviceId = searchParams.get('service');

    if (error) {
      return NextResponse.redirect(
        `${process.env.NEXT_PUBLIC_APP_URL}/auth/error?error=${encodeURIComponent(error)}`
      );
    }

    if (!code || !state || !serviceId) {
      return NextResponse.redirect(
        `${process.env.NEXT_PUBLIC_APP_URL}/auth/error?error=missing_parameters`
      );
    }

    // Here you would exchange the code for tokens with the specific service
    // This is a simplified example - you'd need to implement service-specific logic
    const tokens = await exchangeCodeForTokens(code, serviceId);

    // Store the tokens in the database
    await db.aIService.update({
      where: { id: serviceId },
      data: {
        accessToken: tokens.accessToken,
        refreshToken: tokens.refreshToken,
        tokenExpiresAt: tokens.expiresAt,
        authType: 'oauth',
        isActive: true,
      },
    });

    // Redirect back to the dashboard with success message
    return NextResponse.redirect(
      `${process.env.NEXT_PUBLIC_APP_URL}?auth=success&service=${serviceId}`
    );
  } catch (error) {
    console.error('OAuth callback error:', error);
    return NextResponse.redirect(
      `${process.env.NEXT_PUBLIC_APP_URL}/auth/error?error=server_error`
    );
  }
}

async function exchangeCodeForTokens(code: string, serviceId: string) {
  // This is a placeholder function - you'd implement service-specific OAuth flows
  // For example:
  // - OpenAI: API key based (no OAuth)
  // - Google: Use Google's OAuth2 API
  // - GitHub: Use GitHub's OAuth API
  // - Custom services: Implement their specific OAuth flow
  
  // For demo purposes, we'll return mock tokens
  return {
    accessToken: 'mock_access_token_' + Math.random().toString(36),
    refreshToken: 'mock_refresh_token_' + Math.random().toString(36),
    expiresAt: new Date(Date.now() + 3600 * 1000), // 1 hour from now
  };
}