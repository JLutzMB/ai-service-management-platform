import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getAuthProvider } from '@/lib/auth-providers';
import { getAIServiceById } from '@/lib/ai-services-directory';

export async function POST(request: NextRequest) {
  try {
    const { serviceId, userId } = await request.json();

    if (!serviceId || !userId) {
      return NextResponse.json(
        { error: 'Service ID and User ID are required' },
        { status: 400 }
      );
    }

    const serviceConfig = getAIServiceById(serviceId);
    if (!serviceConfig) {
      return NextResponse.json(
        { error: 'Service not found' },
        { status: 404 }
      );
    }

    // Get the authentication provider
    const authProvider = getAuthProvider(serviceId);
    if (!authProvider) {
      return NextResponse.json(
        { error: 'Authentication provider not found for this service' },
        { status: 404 }
      );
    }

    // Check if user exists, if not create a default user
    let user = await db.user.findUnique({
      where: { id: userId }
    })

    if (!user) {
      // Create a default user if not found
      user = await db.user.create({
        data: {
          id: userId,
          email: `user-${userId}@example.com`,
          name: 'User',
          subscriptionTier: 'free',
          subscriptionStatus: 'active'
        }
      })
    }

    // Create the service record in the database
    const aiService = await db.aIService.create({
      data: {
        name: serviceConfig.name,
        provider: serviceConfig.id,
        authType: serviceConfig.authType,
        userId,
        isActive: false, // Will be activated after successful authentication
      },
    });

    // Initialize authentication
    const authInitResult = await authProvider.initializeAuth(userId);

    // Prepare response based on auth type
    let response: any = {
      success: true,
      serviceId: aiService.id,
      authType: serviceConfig.authType,
      service: serviceConfig,
    };

    if (authInitResult.requiresInput) {
      response.requiresInput = true;
      response.inputFields = authInitResult.inputFields;
      response.message = authInitResult.message;
    } else if (authProvider.getAuthUrl) {
      const state = JSON.stringify({
        serviceId: aiService.id,
        userId,
        timestamp: Date.now()
      });
      response.oauthUrl = authProvider.getAuthUrl(state);
    } else {
      // Service doesn't require authentication
      await db.aIService.update({
        where: { id: aiService.id },
        data: { isActive: true }
      });
      response.isActive = true;
    }

    return NextResponse.json(response);
  } catch (error) {
    console.error('OAuth authorization error:', error);
    return NextResponse.json(
      { error: 'Failed to initialize authorization' },
      { status: 500 }
    );
  }
}