import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getAuthProvider } from '@/lib/auth-providers';
import { getAIServiceById } from '@/lib/ai-services-directory';

export async function POST(request: NextRequest) {
  try {
    const { serviceId, userId, credentials } = await request.json();

    if (!serviceId || !userId || !credentials) {
      return NextResponse.json(
        { error: 'Service ID, User ID, and credentials are required' },
        { status: 400 }
      );
    }

    const serviceConfig = getAIServiceById(serviceId);
    if (!serviceConfig) {
      return NextResponse.json(
        { error: 'Service not found' },
        { status: 404 }
      );
    }

    // Get the authentication provider
    const authProvider = getAuthProvider(serviceId);
    if (!authProvider) {
      return NextResponse.json(
        { error: 'Authentication provider not found for this service' },
        { status: 404 }
      );
    }

    // Check if user exists, if not create a default user
    let user = await db.user.findUnique({
      where: { id: userId }
    })

    if (!user) {
      // Create a default user if not found
      user = await db.user.create({
        data: {
          id: userId,
          email: `user-${userId}@example.com`,
          name: 'User',
          subscriptionTier: 'free',
          subscriptionStatus: 'active'
        }
      })
    }

    // Validate the credentials using the provider
    const isValid = await authProvider.validateCredentials(credentials);
    if (!isValid) {
      return NextResponse.json(
        { error: 'Invalid credentials' },
        { status: 401 }
      );
    }

    // Create or update the service record with the credentials
    const aiService = await db.aIService.upsert({
      where: {
        userId_provider: {
          userId,
          provider: serviceId,
        },
      },
      update: {
        ...credentials,
        authType: 'api-key',
        isActive: true,
        updatedAt: new Date(),
      },
      create: {
        name: serviceConfig.name,
        provider: serviceId,
        ...credentials,
        authType: 'api-key',
        userId,
        isActive: true,
      },
    });

    return NextResponse.json({
      success: true,
      serviceId: aiService.id,
      authType: 'api-key',
    });
  } catch (error) {
    console.error('API key authentication error:', error);
    return NextResponse.json(
      { error: 'Failed to authenticate with API key' },
      { status: 500 }
    );
  }
}