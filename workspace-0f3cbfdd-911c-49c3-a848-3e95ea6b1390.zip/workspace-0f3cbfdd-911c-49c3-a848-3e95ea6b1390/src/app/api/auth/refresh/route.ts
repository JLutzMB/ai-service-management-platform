import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST(request: NextRequest) {
  try {
    const { serviceId } = await request.json();

    if (!serviceId) {
      return NextResponse.json(
        { error: 'Service ID is required' },
        { status: 400 }
      );
    }

    // Get the service from the database
    const service = await db.aIService.findUnique({
      where: { id: serviceId },
    });

    if (!service || !service.refreshToken) {
      return NextResponse.json(
        { error: 'Service not found or no refresh token available' },
        { status: 404 }
      );
    }

    // Check if the token is expired (or about to expire)
    const now = new Date();
    const expiresAt = service.tokenExpiresAt;
    const shouldRefresh = !expiresAt || expiresAt <= new Date(now.getTime() + 5 * 60 * 1000); // Refresh if expires in less than 5 minutes

    if (!shouldRefresh) {
      return NextResponse.json({
        success: true,
        message: 'Token is still valid',
        expiresAt: service.tokenExpiresAt,
      });
    }

    // Refresh the token (this would be service-specific)
    const newTokens = await refreshAccessToken(service.provider, service.refreshToken);

    // Update the service with new tokens
    await db.aIService.update({
      where: { id: serviceId },
      data: {
        accessToken: newTokens.accessToken,
        refreshToken: newTokens.refreshToken || service.refreshToken,
        tokenExpiresAt: newTokens.expiresAt,
        updatedAt: new Date(),
      },
    });

    return NextResponse.json({
      success: true,
      message: 'Token refreshed successfully',
      expiresAt: newTokens.expiresAt,
    });
  } catch (error) {
    console.error('Token refresh error:', error);
    return NextResponse.json(
      { error: 'Failed to refresh token' },
      { status: 500 }
    );
  }
}

async function refreshAccessToken(provider: string, refreshToken: string) {
  // This is a placeholder function - you'd implement service-specific token refresh logic
  // For example:
  // - Google: Use Google's OAuth2 refresh token endpoint
  // - GitHub: Use GitHub's refresh token endpoint
  // - Custom services: Implement their specific refresh logic
  
  // For demo purposes, we'll return mock tokens
  return {
    accessToken: 'new_access_token_' + Math.random().toString(36),
    refreshToken: refreshToken, // Keep the same refresh token
    expiresAt: new Date(Date.now() + 3600 * 1000), // 1 hour from now
  };
}