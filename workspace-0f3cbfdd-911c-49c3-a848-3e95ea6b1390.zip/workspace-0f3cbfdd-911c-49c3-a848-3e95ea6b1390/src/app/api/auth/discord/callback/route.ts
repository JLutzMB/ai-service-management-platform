import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { MidjourneyAuthProvider } from '@/lib/auth-providers';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const code = searchParams.get('code');
    const state = searchParams.get('state');
    const error = searchParams.get('error');

    if (error) {
      return NextResponse.redirect(
        `${process.env.NEXT_PUBLIC_APP_URL}/auth/error?error=${encodeURIComponent(error)}`
      );
    }

    if (!code || !state) {
      return NextResponse.redirect(
        `${process.env.NEXT_PUBLIC_APP_URL}/auth/error?error=missing_parameters`
      );
    }

    // Parse state to get service info
    let stateData;
    try {
      stateData = JSON.parse(state);
    } catch (err) {
      return NextResponse.redirect(
        `${process.env.NEXT_PUBLIC_APP_URL}/auth/error?error=invalid_state`
      );
    }

    const { serviceId, userId } = stateData;

    // Use the Midjourney auth provider
    const authProvider = new MidjourneyAuthProvider();
    const credentials = await authProvider.handleCallback(code, state, userId);

    // Store the credentials in the database
    await db.aIService.update({
      where: { id: serviceId },
      data: {
        accessToken: credentials.accessToken,
        refreshToken: credentials.refreshToken,
        tokenExpiresAt: credentials.expiresAt,
        authType: 'oauth',
        isActive: true,
      },
    });

    // Redirect back to the dashboard with success message
    return NextResponse.redirect(
      `${process.env.NEXT_PUBLIC_APP_URL}/auth/success?service=midjourney`
    );
  } catch (error) {
    console.error('Discord OAuth callback error:', error);
    return NextResponse.redirect(
      `${process.env.NEXT_PUBLIC_APP_URL}/auth/error?error=discord_oauth_failed`
    );
  }
}