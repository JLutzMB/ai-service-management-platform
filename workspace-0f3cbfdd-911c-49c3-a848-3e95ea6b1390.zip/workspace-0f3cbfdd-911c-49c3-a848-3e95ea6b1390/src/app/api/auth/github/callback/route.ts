import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { GitHubCopilotAuthProvider } from '@/lib/auth-providers';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const code = searchParams.get('code');
    const state = searchParams.get('state');
    const error = searchParams.get('error');

    if (error) {
      return NextResponse.redirect(
        `${process.env.NEXT_PUBLIC_APP_URL}/auth/error?error=${encodeURIComponent(error)}`
      );
    }

    if (!code || !state) {
      return NextResponse.redirect(
        `${process.env.NEXT_PUBLIC_APP_URL}/auth/error?error=missing_parameters`
      );
    }

    // Parse state to get service info
    let stateData;
    try {
      stateData = JSON.parse(state);
    } catch (err) {
      return NextResponse.redirect(
        `${process.env.NEXT_PUBLIC_APP_URL}/auth/error?error=invalid_state`
      );
    }

    const { serviceId, userId } = stateData;

    // Use the GitHub Copilot auth provider
    const authProvider = new GitHubCopilotAuthProvider();
    const credentials = await authProvider.handleCallback(code, state, userId);

    // Store the credentials in the database
    await db.aIService.update({
      where: { id: serviceId },
      data: {
        accessToken: credentials.accessToken,
        tokenExpiresAt: credentials.expiresAt,
        authType: 'oauth',
        isActive: true,
      },
    });

    // Redirect back to the dashboard with success message
    return NextResponse.redirect(
      `${process.env.NEXT_PUBLIC_APP_URL}/auth/success?service=github-copilot`
    );
  } catch (error) {
    console.error('GitHub OAuth callback error:', error);
    return NextResponse.redirect(
      `${process.env.NEXT_PUBLIC_APP_URL}/auth/error?error=github_oauth_failed`
    );
  }
}