import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const serviceId = searchParams.get('serviceId')
    const days = parseInt(searchParams.get('days') || '30')

    if (!userId && !serviceId) {
      return NextResponse.json(
        { error: 'User ID or Service ID is required' },
        { status: 400 }
      )
    }

    const startDate = new Date()
    startDate.setDate(startDate.getDate() - days)

    // Build where clause
    const whereClause: any = {
      date: {
        gte: startDate
      }
    }
    
    if (serviceId) {
      whereClause.aiServiceId = serviceId
    } else if (userId) {
      whereClause.aiService = { userId }
    }

    // Get usage records grouped by date
    const usageRecords = await db.usageRecord.findMany({
      where: whereClause,
      orderBy: { date: 'asc' }
    })

    // Group by date and calculate totals
    const dailyStats = new Map()
    
    usageRecords.forEach(record => {
      const dateKey = record.date.toISOString().split('T')[0]
      
      if (!dailyStats.has(dateKey)) {
        dailyStats.set(dateKey, {
          date: dateKey,
          tokens: 0,
          cost: 0,
          credits: 0,
          requests: 0
        })
      }
      
      const stats = dailyStats.get(dateKey)
      stats.tokens += record.tokensUsed
      stats.cost += record.cost || 0
      stats.credits += record.creditsUsed
      stats.requests += 1
    })

    // Convert to array and sort by date
    const analyticsData = Array.from(dailyStats.values()).sort((a, b) => 
      new Date(a.date).getTime() - new Date(b.date).getTime()
    )

    // Calculate summary statistics
    const totalTokens = analyticsData.reduce((sum, day) => sum + day.tokens, 0)
    const totalCost = analyticsData.reduce((sum, day) => sum + day.cost, 0)
    const totalCredits = analyticsData.reduce((sum, day) => sum + day.credits, 0)
    const totalRequests = analyticsData.reduce((sum, day) => sum + day.requests, 0)
    const avgDailyTokens = totalTokens / analyticsData.length
    const avgDailyCost = totalCost / analyticsData.length

    // Get service breakdown if userId is provided
    let serviceBreakdown = []
    if (userId && !serviceId) {
      const services = await db.aIService.findMany({
        where: { userId },
        include: {
          usageRecords: {
            where: {
              date: {
                gte: startDate
              }
            }
          }
        }
      })

      serviceBreakdown = services.map(service => {
        const serviceTokens = service.usageRecords.reduce((sum, record) => sum + record.tokensUsed, 0)
        const serviceCost = service.usageRecords.reduce((sum, record) => sum + (record.cost || 0), 0)
        const serviceCredits = service.usageRecords.reduce((sum, record) => sum + record.creditsUsed, 0)
        const serviceRequests = service.usageRecords.length

        return {
          service: {
            id: service.id,
            name: service.name,
            provider: service.provider
          },
          tokens: serviceTokens,
          cost: serviceCost,
          credits: serviceCredits,
          requests: serviceRequests
        }
      })
    }

    return NextResponse.json({
      dailyData: analyticsData,
      summary: {
        totalTokens,
        totalCost,
        totalCredits,
        totalRequests,
        avgDailyTokens,
        avgDailyCost,
        days: analyticsData.length
      },
      serviceBreakdown: serviceBreakdown.length > 0 ? serviceBreakdown : undefined
    })
  } catch (error) {
    console.error('Error fetching analytics:', error)
    return NextResponse.json(
      { error: 'Failed to fetch analytics' },
      { status: 500 }
    )
  }
}