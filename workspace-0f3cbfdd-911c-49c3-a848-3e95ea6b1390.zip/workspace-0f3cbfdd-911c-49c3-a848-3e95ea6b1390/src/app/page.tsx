"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { 
  Brain, 
  DollarSign, 
  Calendar, 
  TrendingUp, 
  Plus, 
  Settings,
  BarChart3,
  Clock,
  Zap,
  AlertTriangle,
  RefreshCw,
  Wifi,
  WifiOff,
  Activity,
  Target,
  Lightbulb,
  Crown,
  Check,
  Users,
  Star
} from "lucide-react"
import { AIServiceCard } from "@/components/ai-service-card"
import { UsageChart } from "@/components/usage-chart"
import { ServiceSelector } from "@/components/service-selector"
import { EnhancedServiceSelector } from "@/components/enhanced-service-selector"
import { OAuthAuthorization } from "@/components/oauth-authorization"
import { RealTimeNotifications } from "@/components/real-time-notifications"
import { SettingsLayout } from "@/components/settings/settings-layout"
import { useRealTime } from "@/hooks/use-real-time"
import { toast } from "sonner"
import { AIServiceConfig } from "@/lib/ai-services-directory"

interface AIService {
  id: string
  name: string
  provider: string
  isActive: boolean
  credits?: number
  tokens?: number
  creditLimit?: number
  tokenLimit?: number
  planType?: string
  renewalDate?: string
  pricePer1kTokens?: number
  monthlyCost?: number
  currency?: string
  lastSync?: string
  syncStatus?: 'synced' | 'syncing' | 'error'
}

interface UsageData {
  date: string
  tokens: number
  cost: number
}

interface Notification {
  id: string
  type: 'info' | 'warning' | 'error' | 'success'
  title: string
  message: string
  isRead: boolean
  createdAt: string
  serviceId?: string
  serviceName?: string
  metadata?: any
}

interface Insight {
  id: string
  type: 'cost_optimization' | 'usage_pattern' | 'recommendation' | 'anomaly' | 'forecast'
  title: string
  description: string
  impact: 'low' | 'medium' | 'high'
  confidence: number
  isDismissed: boolean
  createdAt: string
  serviceId?: string
  serviceName?: string
}

export default function Dashboard() {
  const [services, setServices] = useState<AIService[]>([])
  const [usageData, setUsageData] = useState<UsageData[]>([])
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [insights, setInsights] = useState<Insight[]>([])
  const [selectedService, setSelectedService] = useState<AIServiceConfig | null>(null)
  const [isOAuthDialogOpen, setIsOAuthDialogOpen] = useState(false)
  const [isSettingsOpen, setIsSettingsOpen] = useState(false)
  const [loading, setLoading] = useState(true)
  const [syncing, setSyncing] = useState<string[]>([])
  const [userId] = useState("cmdypf4pf0006shrbkmv1mk8i") // Test user ID from database
  const [subscriptionLimits, setSubscriptionLimits] = useState<{ serviceLimit: number; canAddService: boolean } | null>(null)

  // Real-time updates
  const { isConnected, reconnect } = useRealTime({
    userId,
    enabled: true,
    onNotification: (notification) => {
      setNotifications(prev => [notification, ...prev.slice(0, 49)])
      toast(notification.title, { description: notification.message })
    },
    onSyncUpdate: (data) => {
      setServices(prev => prev.map(service => 
        service.id === data.serviceId 
          ? { ...service, ...data.data, syncStatus: 'synced' }
          : service
      ))
      setSyncing(prev => prev.filter(id => id !== data.serviceId))
    },
    onUsageAlert: (data) => {
      toast.error(`Usage Alert: ${data.title}`, { description: data.message })
    },
    onServiceStatus: (data) => {
      setServices(prev => prev.map(service => 
        service.id === data.serviceId 
          ? { ...service, isActive: data.status === 'active' }
          : service
      ))
    }
  })

  // Mock data for demonstration
  useEffect(() => {
    // Fetch subscription limits
    const fetchSubscriptionLimits = async () => {
      try {
        const response = await fetch(`/api/subscription?userId=${userId}`)
        if (response.ok) {
          const data = await response.json()
          setSubscriptionLimits(data.limits)
        }
      } catch (error) {
        console.error('Error fetching subscription limits:', error)
      }
    }

    fetchSubscriptionLimits()

    // Simulate API call
    setTimeout(() => {
      setServices([
        {
          id: "1",
          name: "OpenAI GPT-4",
          provider: "OpenAI",
          isActive: true,
          credits: 45.50,
          creditLimit: 100,
          tokens: 1250000,
          tokenLimit: 2000000,
          planType: "Pro",
          renewalDate: "2024-02-15",
          pricePer1kTokens: 0.03,
          monthlyCost: 20,
          currency: "USD",
          lastSync: new Date().toISOString(),
          syncStatus: "synced"
        },
        {
          id: "2",
          name: "Claude 3",
          provider: "Anthropic",
          isActive: true,
          credits: 78.20,
          creditLimit: 150,
          tokens: 890000,
          tokenLimit: 1500000,
          planType: "Pro",
          renewalDate: "2024-03-01",
          pricePer1kTokens: 0.015,
          monthlyCost: 15,
          currency: "USD",
          lastSync: new Date(Date.now() - 5 * 60 * 1000).toISOString(),
          syncStatus: "synced"
        },
        {
          id: "3",
          name: "Gemini Pro",
          provider: "Google",
          isActive: false,
          credits: 120.00,
          creditLimit: 200,
          tokens: 2100000,
          tokenLimit: 5000000,
          planType: "Enterprise",
          renewalDate: "2024-04-10",
          pricePer1kTokens: 0.002,
          monthlyCost: 50,
          currency: "USD",
          lastSync: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
          syncStatus: "error"
        }
      ])

      // Mock usage data for the last 30 days
      const mockUsageData: UsageData[] = []
      const today = new Date()
      for (let i = 29; i >= 0; i--) {
        const date = new Date(today)
        date.setDate(date.getDate() - i)
        mockUsageData.push({
          date: date.toISOString().split('T')[0],
          tokens: Math.floor(Math.random() * 50000) + 10000,
          cost: Math.random() * 5 + 1
        })
      }
      setUsageData(mockUsageData)

      // Mock notifications
      setNotifications([
        {
          id: "1",
          type: "warning",
          title: "High Usage Warning",
          message: "OpenAI GPT-4 has used 85% of its token limit",
          isRead: false,
          createdAt: new Date(Date.now() - 10 * 60 * 1000).toISOString(),
          serviceId: "1",
          serviceName: "OpenAI GPT-4"
        },
        {
          id: "2",
          type: "error",
          title: "Connection Error",
          message: "Failed to sync with Google Gemini Pro",
          isRead: false,
          createdAt: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
          serviceId: "3",
          serviceName: "Gemini Pro"
        }
      ])

      // Mock insights
      setInsights([
        {
          id: "1",
          type: "cost_optimization",
          title: "Cost Optimization Opportunity",
          description: "You could save 15% by switching to a different pricing plan for OpenAI GPT-4",
          impact: "medium",
          confidence: 0.8,
          isDismissed: false,
          createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
          serviceId: "1",
          serviceName: "OpenAI GPT-4"
        },
        {
          id: "2",
          type: "usage_pattern",
          title: "Usage Spike Detected",
          description: "Unusual increase in token usage detected for Claude 3",
          impact: "high",
          confidence: 0.9,
          isDismissed: false,
          createdAt: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(),
          serviceId: "2",
          serviceName: "Claude 3"
        }
      ])

      setLoading(false)
    }, 1000)
  }, [])

  const totalCredits = services.reduce((sum, service) => sum + (service.credits || 0), 0)
  const totalTokens = services.reduce((sum, service) => sum + (service.tokens || 0), 0)
  const totalMonthlyCost = services.reduce((sum, service) => sum + (service.monthlyCost || 0), 0)
  const activeServices = services.filter(service => service.isActive).length

  const handleServiceSelect = (service: AIServiceConfig) => {
    // Check if user can add more services
    if (subscriptionLimits && !subscriptionLimits.canAddService) {
      toast.error('You have reached your service limit. Upgrade to Pro to connect more services.')
      return
    }
    
    setSelectedService(service)
    setIsOAuthDialogOpen(true)
  }

  const handleOAuthSuccess = async (credentials: any) => {
    try {
      setIsOAuthDialogOpen(false)
      setSelectedService(null)
      
      // If it's API key auth, we need to validate through the API
      if (credentials.type === 'api-key') {
        const response = await fetch('/api/auth/api-key', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            serviceId: selectedService!.id,
            userId: 'cmdypf4pf0006shrbkmv1mk8i', // TODO: Get actual user ID
            credentials
          })
        })

        if (!response.ok) {
          const errorData = await response.json()
          throw new Error(errorData.error || 'Failed to validate credentials')
        }
      }

      // Add the new service to the list
      const newService: AIService = {
        id: Math.random().toString(36).substr(2, 9),
        name: selectedService!.name,
        provider: selectedService!.id,
        isActive: true,
        credits: selectedService!.hasFreeTier ? 10 : undefined,
        tokens: selectedService!.hasFreeTier ? 100000 : undefined,
        creditLimit: selectedService!.hasFreeTier ? 10 : undefined,
        tokenLimit: selectedService!.hasFreeTier ? 100000 : undefined,
        planType: selectedService!.hasFreeTier ? "Free" : "Pro",
        renewalDate: selectedService!.hasFreeTier ? undefined : new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        pricePer1kTokens: 0.01,
        monthlyCost: selectedService!.hasFreeTier ? 0 : 10,
        currency: "USD",
        lastSync: new Date().toISOString(),
        syncStatus: "synced"
      }
      
      setServices(prev => [...prev, newService])
      toast.success(`${selectedService!.name} connected successfully!`)
    } catch (error) {
      console.error('Failed to connect service:', error)
      toast.error('Failed to connect service')
    }
  }

  const handleOAuthError = (error: string) => {
    console.error('OAuth error:', error)
    toast.error('Failed to authorize service')
  }

  const handleSyncService = async (serviceId: string) => {
    setSyncing(prev => [...prev, serviceId])
    setServices(prev => prev.map(service => 
      service.id === serviceId 
        ? { ...service, syncStatus: 'syncing' as const }
        : service
    ))

    // Simulate sync process
    setTimeout(() => {
      setServices(prev => prev.map(service => 
        service.id === serviceId 
          ? { 
              ...service, 
              syncStatus: 'synced' as const,
              lastSync: new Date().toISOString(),
              credits: Math.max(0, (service.credits || 0) - Math.random() * 5),
              tokens: Math.max(0, (service.tokens || 0) - Math.floor(Math.random() * 50000))
            }
          : service
      ))
      setSyncing(prev => prev.filter(id => id !== serviceId))
      toast.success("Service synced successfully")
    }, 2000)
  }

  const handleSyncAll = async () => {
    const activeServiceIds = services.filter(s => s.isActive).map(s => s.id)
    setSyncing(activeServiceIds)
    
    // Simulate syncing all services
    setTimeout(() => {
      setServices(prev => prev.map(service => 
        activeServiceIds.includes(service.id)
          ? { 
              ...service, 
              syncStatus: 'synced' as const,
              lastSync: new Date().toISOString(),
              credits: Math.max(0, (service.credits || 0) - Math.random() * 5),
              tokens: Math.max(0, (service.tokens || 0) - Math.floor(Math.random() * 50000))
            }
          : service
      ))
      setSyncing([])
      toast.success("All services synced successfully")
    }, 3000)
  }

  const getRenewalStatus = (renewalDate?: string) => {
    if (!renewalDate) return null
    const renewal = new Date(renewalDate)
    const today = new Date()
    const daysUntilRenewal = Math.ceil((renewal.getTime() - today.getTime()) / (1000 * 60 * 60 * 24))
    
    if (daysUntilRenewal <= 7) {
      return { status: "warning", days: daysUntilRenewal }
    } else if (daysUntilRenewal <= 3) {
      return { status: "danger", days: daysUntilRenewal }
    }
    return { status: "normal", days: daysUntilRenewal }
  }

  const getUpcomingRenewals = () => {
    return services
      .filter(service => service.isActive && service.renewalDate)
      .map(service => ({
        ...service,
        renewalStatus: getRenewalStatus(service.renewalDate)
      }))
      .sort((a, b) => {
        const aDays = a.renewalStatus?.days || 999
        const bDays = b.renewalStatus?.days || 999
        return aDays - bDays
      })
      .slice(0, 3)
  }

  const upcomingRenewals = getUpcomingRenewals()

  const handleNotificationClick = (notification: Notification) => {
    // Handle notification click (e.g., navigate to service)
    console.log('Notification clicked:', notification)
  }

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
          <div className="flex items-center gap-4">
            <div>
              <h1 className="text-3xl font-bold tracking-tight">AI Services Dashboard</h1>
              <p className="text-muted-foreground">
                Monitor your AI service usage, credits, and billing information
              </p>
            </div>
            <div className="flex items-center gap-2">
              {isConnected ? (
                <Badge variant="outline" className="text-green-600 border-green-600">
                  <Wifi className="h-3 w-3 mr-1" />
                  Live
                </Badge>
              ) : (
                <Badge variant="outline" className="text-red-600 border-red-600">
                  <WifiOff className="h-3 w-3 mr-1" />
                  Offline
                </Badge>
              )}
              {subscriptionLimits && (
                <Badge variant="outline" className={subscriptionLimits.canAddService ? "text-blue-600 border-blue-600" : "text-orange-600 border-orange-600"}>
                  {subscriptionLimits.serviceLimit === Infinity ? "Pro" : `Free (${services.length}/${subscriptionLimits.serviceLimit})`}
                </Badge>
              )}
              {!isConnected && (
                <Button variant="ghost" size="sm" onClick={reconnect}>
                  <RefreshCw className="h-3 w-3 mr-1" />
                  Reconnect
                </Button>
              )}
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <RealTimeNotifications 
              userId={userId}
              onNotificationClick={handleNotificationClick}
            />
            <EnhancedServiceSelector onServiceSelect={handleServiceSelect}>
              <Button disabled={subscriptionLimits && !subscriptionLimits.canAddService}>
                <Plus className="mr-2 h-4 w-4" />
                Add Service
              </Button>
            </EnhancedServiceSelector>
            <Button variant="outline" onClick={handleSyncAll} disabled={syncing.length > 0}>
              {syncing.length > 0 ? (
                <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <RefreshCw className="mr-2 h-4 w-4" />
              )}
              Sync All
            </Button>
            <Button variant="outline" onClick={() => setIsSettingsOpen(true)}>
              <Settings className="mr-2 h-4 w-4" />
              Settings
            </Button>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Credits</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">${totalCredits.toFixed(2)}</div>
              <p className="text-xs text-muted-foreground">
                Across {activeServices} active services
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Tokens</CardTitle>
              <Brain className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {(totalTokens / 1000000).toFixed(1)}M
              </div>
              <p className="text-xs text-muted-foreground">
                Available tokens
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Monthly Cost</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">${totalMonthlyCost.toFixed(2)}</div>
              <p className="text-xs text-muted-foreground">
                Total monthly subscriptions
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Services</CardTitle>
              <Zap className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{activeServices}</div>
              <p className="text-xs text-muted-foreground">
                Out of {services.length} total services
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Alerts for upcoming renewals */}
        {upcomingRenewals.some(r => r.renewalStatus?.status === "danger") && (
          <Alert className="border-red-200 bg-red-50">
            <AlertTriangle className="h-4 w-4 text-red-600" />
            <AlertDescription className="text-red-800">
              <strong>Urgent:</strong> Some services need renewal within 3 days. Check your billing settings.
            </AlertDescription>
          </Alert>
        )}

        {upcomingRenewals.some(r => r.renewalStatus?.status === "warning") && (
          <Alert className="border-yellow-200 bg-yellow-50">
            <Clock className="h-4 w-4 text-yellow-600" />
            <AlertDescription className="text-yellow-800">
              <strong>Reminder:</strong> Some services need renewal within 7 days.
            </AlertDescription>
          </Alert>
        )}

        {/* Main Content Tabs */}
        <Tabs defaultValue="services" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="services">Services</TabsTrigger>
            <TabsTrigger value="usage">Usage Analytics</TabsTrigger>
            <TabsTrigger value="insights">Insights</TabsTrigger>
            <TabsTrigger value="billing">Billing Overview</TabsTrigger>
            <TabsTrigger value="subscription">Subscription</TabsTrigger>
          </TabsList>

          <TabsContent value="services" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {loading ? (
                Array.from({ length: 3 }).map((_, i) => (
                  <Card key={i}>
                    <CardHeader>
                      <div className="h-6 bg-gray-200 rounded animate-pulse"></div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="h-4 bg-gray-200 rounded animate-pulse"></div>
                        <div className="h-4 bg-gray-200 rounded animate-pulse"></div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                services.map((service) => (
                  <AIServiceCard
                    key={service.id}
                    service={service}
                    onSync={() => handleSyncService(service.id)}
                    isSyncing={syncing.includes(service.id)}
                    onEdit={() => toast.info("Edit functionality coming soon")}
                    onToggle={() => toast.info("Toggle functionality coming soon")}
                  />
                ))
              )}
            </div>
          </TabsContent>

          <TabsContent value="usage" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="h-5 w-5" />
                    Token Usage (Last 30 Days)
                  </CardTitle>
                  <CardDescription>
                    Daily token consumption across all services
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <UsageChart data={usageData} type="tokens" />
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <DollarSign className="h-5 w-5" />
                    Cost Analysis (Last 30 Days)
                  </CardTitle>
                  <CardDescription>
                    Daily cost breakdown across all services
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <UsageChart data={usageData} type="cost" />
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="insights" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="h-5 w-5" />
                    Active Insights
                  </CardTitle>
                  <CardDescription>
                    AI-powered recommendations and analysis
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {insights.length > 0 ? (
                      insights.map((insight) => (
                        <div key={insight.id} className="p-4 border rounded-lg">
                          <div className="flex items-start justify-between mb-2">
                            <h4 className="font-medium">{insight.title}</h4>
                            <div className="flex items-center gap-2">
                              <Badge variant={
                                insight.impact === 'high' ? 'destructive' :
                                insight.impact === 'medium' ? 'default' : 'secondary'
                              }>
                                {insight.impact}
                              </Badge>
                              <Badge variant="outline">
                                {Math.round(insight.confidence * 100)}%
                              </Badge>
                            </div>
                          </div>
                          <p className="text-sm text-muted-foreground mb-2">
                            {insight.description}
                          </p>
                          <div className="flex items-center justify-between text-xs text-muted-foreground">
                            <span>{insight.serviceName}</span>
                            <span>{new Date(insight.createdAt).toLocaleDateString()}</span>
                          </div>
                        </div>
                      ))
                    ) : (
                      <p className="text-center text-muted-foreground py-8">
                        No insights available yet
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="h-5 w-5" />
                    Recent Activity
                  </CardTitle>
                  <CardDescription>
                    Latest system events and notifications
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {notifications.length > 0 ? (
                      notifications.slice(0, 5).map((notification) => (
                        <div key={notification.id} className="flex items-start gap-3 p-3 border rounded-lg">
                          <div className={`h-2 w-2 rounded-full mt-2 ${
                            notification.type === 'error' ? 'bg-red-500' :
                            notification.type === 'warning' ? 'bg-yellow-500' :
                            notification.type === 'success' ? 'bg-green-500' : 'bg-blue-500'
                          }`} />
                          <div className="flex-1">
                            <h4 className="font-medium text-sm">{notification.title}</h4>
                            <p className="text-xs text-muted-foreground">{notification.message}</p>
                            <p className="text-xs text-muted-foreground mt-1">
                              {new Date(notification.createdAt).toLocaleString()}
                            </p>
                          </div>
                        </div>
                      ))
                    ) : (
                      <p className="text-center text-muted-foreground py-8">
                        No recent activity
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="billing" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Upcoming Renewals</CardTitle>
                  <CardDescription>
                    Services that need renewal soon
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {upcomingRenewals.length > 0 ? (
                      upcomingRenewals.map((service) => (
                        <div key={service.id} className="flex items-center justify-between p-3 border rounded-lg">
                          <div>
                            <h4 className="font-medium">{service.name}</h4>
                            <p className="text-sm text-muted-foreground">
                              {service.provider} • {service.planType}
                            </p>
                          </div>
                          <div className="text-right">
                            <Badge 
                              variant={
                                service.renewalStatus?.status === "danger" ? "destructive" :
                                service.renewalStatus?.status === "warning" ? "default" : "secondary"
                              }
                            >
                              {service.renewalStatus?.days} days
                            </Badge>
                            <p className="text-sm text-muted-foreground mt-1">
                              ${service.monthlyCost}/mo
                            </p>
                          </div>
                        </div>
                      ))
                    ) : (
                      <p className="text-center text-muted-foreground py-8">
                        No upcoming renewals
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Billing Summary</CardTitle>
                  <CardDescription>
                    Monthly cost breakdown by service
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {services
                      .filter(service => service.isActive)
                      .map((service) => (
                        <div key={service.id} className="flex items-center justify-between">
                          <div>
                            <h4 className="font-medium">{service.name}</h4>
                            <p className="text-sm text-muted-foreground">
                              {service.planType} • ${service.pricePer1kTokens}/1k tokens
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="font-medium">${service.monthlyCost}/mo</p>
                            <p className="text-sm text-muted-foreground">
                              ${(service.credits || 0).toFixed(2)} credits
                            </p>
                          </div>
                        </div>
                      ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="subscription" className="space-y-6">
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Crown className="h-5 w-5" />
                    Subscription Management
                  </CardTitle>
                  <CardDescription>
                    Manage your subscription plan and view usage limits
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-semibold mb-2">Current Usage</h4>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span>Services Connected:</span>
                          <span className="font-medium">{services.length}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Service Limit:</span>
                          <span className="font-medium">
                            {subscriptionLimits?.serviceLimit === Infinity ? "Unlimited" : subscriptionLimits?.serviceLimit}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span>Available Slots:</span>
                          <span className="font-medium">
                            {subscriptionLimits?.serviceLimit === Infinity ? "Unlimited" : Math.max(0, (subscriptionLimits?.serviceLimit || 0) - services.length)}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div>
                      <h4 className="font-semibold mb-2">Subscription Benefits</h4>
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <Check className="h-4 w-4 text-green-600" />
                          <span className="text-sm">Real-time sync</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Check className="h-4 w-4 text-green-600" />
                          <span className="text-sm">Advanced analytics</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Check className="h-4 w-4 text-green-600" />
                          <span className="text-sm">Cost optimization</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Check className="h-4 w-4 text-green-600" />
                          <span className="text-sm">Priority support</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Subscription Plans */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader className="text-center">
                    <CardTitle className="flex items-center justify-center gap-2">
                      <Users className="h-5 w-5" />
                      Free
                    </CardTitle>
                    <div className="text-3xl font-bold">$0<span className="text-sm font-normal text-muted-foreground">/month</span></div>
                    <CardDescription>Perfect for individuals managing a few AI services</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2 mb-6">
                      <li className="flex items-center gap-2 text-sm">
                        <Check className="h-4 w-4 text-green-600" />
                        Connect up to 2 AI services
                      </li>
                      <li className="flex items-center gap-2 text-sm">
                        <Check className="h-4 w-4 text-green-600" />
                        Basic usage tracking
                      </li>
                      <li className="flex items-center gap-2 text-sm">
                        <Check className="h-4 w-4 text-green-600" />
                        Manual sync only
                      </li>
                      <li className="flex items-center gap-2 text-sm">
                        <Check className="h-4 w-4 text-green-600" />
                        Email notifications
                      </li>
                      <li className="flex items-center gap-2 text-sm">
                        <Check className="h-4 w-4 text-green-600" />
                        Basic analytics
                      </li>
                    </ul>
                    <Button className="w-full" variant="outline" disabled>
                      Current Plan
                    </Button>
                  </CardContent>
                </Card>

                <Card className="ring-2 ring-primary">
                  <CardHeader className="text-center">
                    <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                      <Badge className="bg-primary text-primary-foreground">
                        <Star className="h-3 w-3 mr-1" />
                        Most Popular
                      </Badge>
                    </div>
                    <CardTitle className="flex items-center justify-center gap-2">
                      <Zap className="h-5 w-5" />
                      Pro
                    </CardTitle>
                    <div className="text-3xl font-bold">$4.99<span className="text-sm font-normal text-muted-foreground">/month</span></div>
                    <CardDescription>Billed annually at $59.88 (28% savings)</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2 mb-6">
                      <li className="flex items-center gap-2 text-sm">
                        <Check className="h-4 w-4 text-green-600" />
                        Unlimited AI service connections
                      </li>
                      <li className="flex items-center gap-2 text-sm">
                        <Check className="h-4 w-4 text-green-600" />
                        Real-time sync
                      </li>
                      <li className="flex items-center gap-2 text-sm">
                        <Check className="h-4 w-4 text-green-600" />
                        Advanced analytics & insights
                      </li>
                      <li className="flex items-center gap-2 text-sm">
                        <Check className="h-4 w-4 text-green-600" />
                        Cost optimization recommendations
                      </li>
                      <li className="flex items-center gap-2 text-sm">
                        <Check className="h-4 w-4 text-green-600" />
                        Priority support
                      </li>
                      <li className="flex items-center gap-2 text-sm">
                        <Check className="h-4 w-4 text-green-600" />
                        Custom notification rules
                      </li>
                      <li className="flex items-center gap-2 text-sm">
                        <Check className="h-4 w-4 text-green-600" />
                        API access
                      </li>
                    </ul>
                    <Button className="w-full" onClick={() => {
                      // This would typically open a payment flow
                      toast.info('Payment integration coming soon!')
                    }}>
                      Upgrade to Pro
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        {/* Settings Dialog */}
        <Dialog open={isSettingsOpen} onOpenChange={setIsSettingsOpen}>
          <DialogContent className="max-w-7xl max-h-[90vh] overflow-hidden p-0">
            <div className="h-full flex flex-col">
              <DialogHeader className="px-8 pt-8 pb-4 border-b">
                <DialogTitle className="text-2xl font-bold">Settings</DialogTitle>
              </DialogHeader>
              <div className="flex-1 overflow-y-auto px-8 pb-8">
                <SettingsLayout userId={userId} />
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* OAuth Authorization Dialog */}
        {selectedService && (
          <OAuthAuthorization
            service={selectedService}
            isOpen={isOAuthDialogOpen}
            onClose={() => {
              setIsOAuthDialogOpen(false)
              setSelectedService(null)
            }}
            onSuccess={handleOAuthSuccess}
            onError={handleOAuthError}
          />
        )}
      </div>
    </div>
  )
}