'use client';

import { useEffect, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle, Home, RefreshCw, Sparkles } from 'lucide-react';
import { useRouter } from 'next/navigation';

export default function AuthSuccessPage() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const service = searchParams.get('service');
  const [countdown, setCountdown] = useState(5);

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          router.push('/');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [router]);

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
          </div>
          <CardTitle className="text-green-600">Successfully Connected!</CardTitle>
          <CardDescription>
            Your AI service has been linked to the dashboard
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-2 mb-2">
              <Sparkles className="w-4 h-4 text-yellow-500" />
              <span className="font-medium">What happens next:</span>
            </div>
            <ul className="text-sm text-muted-foreground space-y-1 text-left">
              <li>• Your usage data will be automatically synced</li>
              <li>• You'll receive notifications about credits and renewals</li>
              <li>• AI-powered insights will help optimize your usage</li>
              <li>• Real-time monitoring will begin immediately</li>
            </ul>
          </div>

          {service && (
            <div className="bg-blue-50 p-3 rounded-lg">
              <p className="text-sm font-medium text-blue-800">
                Service: {service.replace(/[-_]/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
              </p>
            </div>
          )}

          <div className="text-center">
            <p className="text-sm text-muted-foreground mb-4">
              Redirecting to dashboard in {countdown} seconds...
            </p>
          </div>

          <div className="flex space-x-2">
            <Button onClick={() => router.push('/')} className="flex-1">
              <Home className="w-4 h-4 mr-2" />
              Go to Dashboard
            </Button>
            <Button variant="outline" onClick={() => window.location.reload()} className="flex-1">
              <RefreshCw className="w-4 h-4 mr-2" />
              Refresh Page
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}