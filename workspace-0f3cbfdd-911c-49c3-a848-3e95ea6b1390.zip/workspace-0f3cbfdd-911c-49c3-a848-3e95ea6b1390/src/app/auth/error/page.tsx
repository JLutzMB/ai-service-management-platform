'use client';

import { AuthErrorHandler } from '@/components/auth-error-handler';

export default function AuthErrorPage() {
  return <AuthErrorHandler />;
}