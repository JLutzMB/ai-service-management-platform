'use client';

import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, XCircle, ExternalLink, Key, Shield, AlertTriangle, Loader2 } from 'lucide-react';
import { AIServiceConfig } from '@/lib/ai-services-directory';
import { getAuthProvider, AuthProvider, AuthInitResult, AuthInputField, AuthCredentials } from '@/lib/auth-providers';

interface OAuthAuthorizationProps {
  service: AIServiceConfig;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (credentials: AuthCredentials) => void;
  onError: (error: string) => void;
}

export function OAuthAuthorization({ 
  service, 
  isOpen, 
  onClose, 
  onSuccess, 
  onError 
}: OAuthAuthorizationProps) {
  const [step, setStep] = useState<'start' | 'input' | 'oauth' | 'processing' | 'success' | 'error'>('start');
  const [inputValues, setInputValues] = useState<Record<string, string>>({});
  const [error, setError] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [authInitResult, setAuthInitResult] = useState<AuthInitResult | null>(null);
  const [authProvider, setAuthProvider] = useState<AuthProvider | null>(null);

  useEffect(() => {
    if (isOpen && service) {
      const provider = getAuthProvider(service.id);
      if (provider) {
        setAuthProvider(provider);
        initializeAuth(provider);
      } else {
        setError('Authentication provider not found for this service');
        setStep('error');
      }
    }
  }, [isOpen, service]);

  const initializeAuth = async (provider: AuthProvider) => {
    try {
      setIsProcessing(true);
      const result = await provider.initializeAuth('cmdypf4pf0006shrbkmv1mk8i'); // TODO: Get actual user ID
      setAuthInitResult(result);
      
      if (result.requiresInput && result.inputFields) {
        setStep('input');
      } else if (result.authUrl || provider.getAuthUrl) {
        setStep('oauth');
      } else {
        // For services that don't require authentication
        handleSuccess({ type: 'none' });
      }
    } catch (error) {
      setError('Failed to initialize authentication');
      setStep('error');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleInputChange = (fieldName: string, value: string) => {
    setInputValues(prev => ({ ...prev, [fieldName]: value }));
  };

  const handleApiKeySubmit = async () => {
    if (!authProvider) return;

    // Validate required fields
    if (authInitResult?.inputFields) {
      const missingFields = authInitResult.inputFields
        .filter(field => field.required && !inputValues[field.name])
        .map(field => field.label);

      if (missingFields.length > 0) {
        setError(`Please fill in: ${missingFields.join(', ')}`);
        return;
      }
    }

    setIsProcessing(true);
    setStep('processing');

    try {
      const credentials: AuthCredentials = {
        type: 'api-key',
        ...inputValues
      };

      const isValid = await authProvider.validateCredentials(credentials);
      if (isValid) {
        handleSuccess(credentials);
      } else {
        setError('Invalid credentials. Please check and try again.');
        setStep('error');
      }
    } catch (error) {
      setError('Failed to validate credentials');
      setStep('error');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleOAuthStart = () => {
    if (!authProvider || !authProvider.getAuthUrl) return;

    const state = JSON.stringify({
      serviceId: service.id,
      timestamp: Date.now(),
      userId: 'cmdypf4pf0006shrbkmv1mk8i' // TODO: Get actual user ID
    });

    const authUrl = authProvider.getAuthUrl(state);
    
    // Open OAuth URL in a new window
    const width = 600;
    const height = 700;
    const left = (window.innerWidth - width) / 2;
    const top = (window.innerHeight - height) / 2;
    
    const oauthWindow = window.open(
      authUrl,
      'oauth',
      `width=${width},height=${height},left=${left},top=${top}`
    );

    // Listen for messages from the OAuth window
    const handleMessage = (event: MessageEvent) => {
      if (event.data.type === 'oauth-success') {
        handleOAuthSuccess(event.data.credentials);
      } else if (event.data.type === 'oauth-error') {
        handleOAuthError(event.data.error);
      }
      window.removeEventListener('message', handleMessage);
    };

    window.addEventListener('message', handleMessage);
    setStep('oauth');
  };

  const handleOAuthSuccess = (credentials: AuthCredentials) => {
    setIsProcessing(true);
    setStep('processing');
    
    setTimeout(() => {
      setIsProcessing(false);
      setStep('success');
      onSuccess(credentials);
    }, 2000);
  };

  const handleOAuthError = (error: string) => {
    setError(error);
    setStep('error');
    onError(error);
  };

  const handleSuccess = (credentials: AuthCredentials) => {
    setIsProcessing(false);
    setStep('success');
    onSuccess(credentials);
  };

  const handleClose = () => {
    setStep('start');
    setInputValues({});
    setError('');
    setIsProcessing(false);
    setAuthInitResult(null);
    setAuthProvider(null);
    onClose();
  };

  const renderInputFields = () => {
    if (!authInitResult?.inputFields) return null;

    return authInitResult.inputFields.map((field) => (
      <div key={field.name} className="space-y-2">
        <Label htmlFor={field.name}>{field.label}</Label>
        <Input
          id={field.name}
          type={field.type}
          value={inputValues[field.name] || ''}
          onChange={(e) => handleInputChange(field.name, e.target.value)}
          placeholder={field.placeholder}
          required={field.required}
        />
      </div>
    ));
  };

  const renderStepContent = () => {
    switch (step) {
      case 'start':
        return (
          <div className="space-y-6">
            <div className="flex items-center space-x-4">
              <img
                src={service.logo}
                alt={service.name}
                className="w-16 h-16 rounded-lg object-cover"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.src = 'https://via.placeholder.com/64x64?text=AI';
                }}
              />
              <div>
                <h3 className="text-lg font-semibold">{service.name}</h3>
                <p className="text-sm text-gray-600">{service.description}</p>
                <div className="flex items-center space-x-2 mt-2">
                  <Badge variant="outline">{service.category}</Badge>
                  {service.hasFreeTier && (
                    <Badge variant="secondary">Free Tier Available</Badge>
                  )}
                </div>
              </div>
            </div>

            {authInitResult?.message && (
              <div className="bg-blue-50 p-4 rounded-lg">
                <p className="text-sm text-blue-800">{authInitResult.message}</p>
              </div>
            )}

            <div className="space-y-4">
              <div className="bg-blue-50 p-4 rounded-lg">
                <h4 className="font-semibold text-sm mb-2">Features you'll get:</h4>
                <div className="flex flex-wrap gap-2">
                  {service.features.map((feature, index) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      {feature}
                    </Badge>
                  ))}
                </div>
              </div>

              <div className="bg-green-50 p-4 rounded-lg">
                <h4 className="font-semibold text-sm mb-2">Pricing:</h4>
                <p className="text-sm text-gray-700">{service.pricing}</p>
              </div>

              <Alert>
                <Shield className="h-4 w-4" />
                <AlertDescription>
                  Your credentials are encrypted and stored securely. We only access the data needed to track your usage and credits.
                </AlertDescription>
              </Alert>
            </div>

            <div className="flex space-x-3">
              {authInitResult?.requiresInput ? (
                <Button onClick={() => setStep('input')} className="flex-1">
                  <Key className="w-4 h-4 mr-2" />
                  Enter Credentials
                </Button>
              ) : authProvider?.getAuthUrl ? (
                <Button onClick={handleOAuthStart} className="flex-1">
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Connect with {service.name}
                </Button>
              ) : (
                <Button onClick={() => handleSuccess({ type: 'none' })} className="flex-1">
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Connect Service
                </Button>
              )}
            </div>
          </div>
        );

      case 'input':
        return (
          <div className="space-y-6">
            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Key className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-lg font-semibold">Enter Your Credentials</h3>
              <p className="text-sm text-gray-600 mt-2">
                Please provide your {service.name} credentials to connect the service.
              </p>
            </div>

            <div className="space-y-4">
              {renderInputFields()}

              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  Your credentials will be encrypted and stored securely. Never share your credentials with others.
                </AlertDescription>
              </Alert>

              <div className="bg-blue-50 p-4 rounded-lg">
                <h4 className="font-semibold text-sm mb-2">Need help finding your credentials?</h4>
                <Button variant="outline" size="sm" asChild>
                  <a href={service.website} target="_blank" rel="noopener noreferrer">
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Visit {service.name} Documentation
                  </a>
                </Button>
              </div>
            </div>

            <div className="flex space-x-3">
              <Button onClick={handleApiKeySubmit} className="flex-1" disabled={isProcessing}>
                {isProcessing ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <CheckCircle className="w-4 h-4 mr-2" />
                )}
                Connect Service
              </Button>
              <Button variant="outline" onClick={() => setStep('start')}>
                Back
              </Button>
            </div>
          </div>
        );

      case 'oauth':
        return (
          <div className="space-y-6">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <ExternalLink className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold">Connecting to {service.name}</h3>
              <p className="text-sm text-gray-600 mt-2">
                A new window has opened. Please complete the authorization process there.
              </p>
            </div>

            <div className="bg-yellow-50 p-4 rounded-lg">
              <h4 className="font-semibold text-sm mb-2">What happens next:</h4>
              <ul className="text-sm text-gray-700 space-y-1">
                <li>• You'll be redirected to {service.name}</li>
                <li>• You'll need to sign in and grant permissions</li>
                <li>• You'll be redirected back to this dashboard</li>
                <li>• Your account will be automatically connected</li>
              </ul>
            </div>

            <div className="flex space-x-3">
              <Button variant="outline" onClick={handleOAuthStart} className="flex-1">
                <ExternalLink className="w-4 h-4 mr-2" />
                Reopen Authorization Window
              </Button>
              <Button variant="outline" onClick={handleClose}>
                Cancel
              </Button>
            </div>
          </div>
        );

      case 'processing':
        return (
          <div className="space-y-6">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Loader2 className="w-8 h-8 text-blue-600 animate-spin" />
              </div>
              <h3 className="text-lg font-semibold">Connecting to {service.name}</h3>
              <p className="text-sm text-gray-600 mt-2">
                Please wait while we validate your credentials...
              </p>
            </div>
          </div>
        );

      case 'success':
        return (
          <div className="space-y-6">
            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-lg font-semibold">Successfully Connected!</h3>
              <p className="text-sm text-gray-600 mt-2">
                Your {service.name} account has been successfully linked to the dashboard.
              </p>
            </div>

            <div className="bg-green-50 p-4 rounded-lg">
              <h4 className="font-semibold text-sm mb-2">What's next:</h4>
              <ul className="text-sm text-gray-700 space-y-1">
                <li>• Your usage data will be automatically synced</li>
                <li>• You'll receive notifications about credits and renewals</li>
                <li>• You can monitor your spending and usage patterns</li>
                <li>• AI-powered insights will help optimize your usage</li>
              </ul>
            </div>

            <Button onClick={handleClose} className="w-full">
              Go to Dashboard
            </Button>
          </div>
        );

      case 'error':
        return (
          <div className="space-y-6">
            <div className="text-center">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <XCircle className="w-8 h-8 text-red-600" />
              </div>
              <h3 className="text-lg font-semibold">Connection Failed</h3>
              <p className="text-sm text-gray-600 mt-2">
                {error || 'Failed to connect to your account. Please try again.'}
              </p>
            </div>

            <div className="bg-red-50 p-4 rounded-lg">
              <h4 className="font-semibold text-sm mb-2">Troubleshooting tips:</h4>
              <ul className="text-sm text-gray-700 space-y-1">
                <li>• Make sure your credentials are correct</li>
                <li>• Check if your account has the necessary permissions</li>
                <li>• Ensure your API key is active and not expired</li>
                <li>• Try refreshing the page and connecting again</li>
              </ul>
            </div>

            <div className="flex space-x-3">
              <Button onClick={() => setStep('start')} className="flex-1">
                Try Again
              </Button>
              <Button variant="outline" onClick={handleClose}>
                Cancel
              </Button>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] p-0">
        <div className="h-full flex flex-col">
          <DialogHeader className="px-8 pt-8 pb-6 border-b">
            <DialogTitle className="text-2xl font-bold">Connect {service.name}</DialogTitle>
          </DialogHeader>
          <div className="flex-1 overflow-y-auto px-8 pb-8">
            {renderStepContent()}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}