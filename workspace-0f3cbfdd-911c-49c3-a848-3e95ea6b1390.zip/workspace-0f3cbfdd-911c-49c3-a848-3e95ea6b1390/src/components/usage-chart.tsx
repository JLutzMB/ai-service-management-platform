"use client"

import { useMemo } from "react"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

interface UsageData {
  date: string
  tokens: number
  cost: number
}

interface UsageChartProps {
  data: UsageData[]
  type: "tokens" | "cost"
}

export function UsageChart({ data, type }: UsageChartProps) {
  const chartData = useMemo(() => {
    return data.map(item => ({
      ...item,
      formattedDate: new Date(item.date).toLocaleDateString('en-US', { 
        month: 'short', 
        day: 'numeric' 
      })
    }))
  }, [data])

  const formatValue = (value: number) => {
    if (type === "tokens") {
      if (value >= 1000000) {
        return `${(value / 1000000).toFixed(1)}M`
      } else if (value >= 1000) {
        return `${(value / 1000).toFixed(1)}K`
      }
      return value.toString()
    } else {
      return `$${value.toFixed(2)}`
    }
  }

  const getColor = () => {
    return type === "tokens" ? "#3b82f6" : "#10b981"
  }

  const getLabel = () => {
    return type === "tokens" ? "Tokens Used" : "Cost ($)"
  }

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload
      return (
        <div className="bg-background border rounded-lg p-3 shadow-lg">
          <p className="font-medium">{label}</p>
          <p className="text-sm text-muted-foreground">
            {type === "tokens" ? "Tokens: " : "Cost: "}
            <span className="font-medium text-foreground">
              {type === "tokens" 
                ? `${data.tokens.toLocaleString()} tokens`
                : `$${data.cost.toFixed(2)}`
              }
            </span>
          </p>
          {type === "tokens" && (
            <p className="text-sm text-muted-foreground">
              Cost: <span className="font-medium text-foreground">${data.cost.toFixed(2)}</span>
            </p>
          )}
        </div>
      )
    }
    return null
  }

  return (
    <div className="w-full h-64">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={chartData}>
          <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
          <XAxis 
            dataKey="formattedDate" 
            className="text-xs"
            tick={{ fill: 'hsl(var(--muted-foreground))' }}
          />
          <YAxis 
            className="text-xs"
            tick={{ fill: 'hsl(var(--muted-foreground))' }}
            tickFormatter={formatValue}
          />
          <Tooltip content={<CustomTooltip />} />
          <Line
            type="monotone"
            dataKey={type}
            stroke={getColor()}
            strokeWidth={2}
            dot={{ fill: getColor(), strokeWidth: 2, r: 4 }}
            activeDot={{ r: 6, fill: getColor() }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}