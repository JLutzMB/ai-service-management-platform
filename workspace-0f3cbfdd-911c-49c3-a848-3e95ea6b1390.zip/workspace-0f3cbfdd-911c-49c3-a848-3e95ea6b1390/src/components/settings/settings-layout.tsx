"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { 
  User, 
  Bell, 
  CreditCard, 
  Key, 
  Database, 
  Palette, 
  Shield,
  Save,
  RotateCcw,
  Trash2,
  Plus,
  Download
} from "lucide-react"
import { toast } from "sonner"

interface SettingsProps {
  userId: string
}

export function SettingsLayout({ userId }: SettingsProps) {
  const [loading, setLoading] = useState(false)
  const [activeTab, setActiveTab] = useState("profile")

  // Profile state
  const [profile, setProfile] = useState({
    name: "Test User",
    email: "test@example.com",
    bio: "",
    timezone: "UTC",
    language: "en"
  })

  // Notification settings
  const [notifications, setNotifications] = useState({
    emailNotifications: true,
    pushNotifications: true,
    usageAlerts: true,
    renewalReminders: true,
    costAlerts: true,
    serviceUpdates: false,
    marketingEmails: false
  })

  // Service settings
  const [services, setServices] = useState([
    {
      id: "1",
      name: "OpenAI GPT-4",
      provider: "OpenAI",
      isActive: true,
      autoSync: true,
      syncFrequency: "hourly"
    },
    {
      id: "2", 
      name: "Claude 3",
      provider: "Anthropic",
      isActive: true,
      autoSync: true,
      syncFrequency: "daily"
    }
  ])

  // Billing settings
  const [billing, setBilling] = useState({
    plan: "free",
    billingCycle: "monthly",
    autoRenew: true,
    paymentMethod: "•••• 4242"
  })

  // API settings
  const [apiKeys, setApiKeys] = useState([
    {
      id: "1",
      name: "Production API Key",
      key: "sk_••••••••••••••••••••••••••",
      createdAt: "2024-01-15",
      lastUsed: "2024-01-20",
      isActive: true
    }
  ])

  // Privacy settings
  const [privacy, setPrivacy] = useState({
    dataRetention: "365",
    analyticsSharing: false,
    crashReports: true,
    marketingConsent: false
  })

  // Appearance settings
  const [appearance, setAppearance] = useState({
    theme: "light",
    accentColor: "blue",
    fontSize: "medium",
    denseMode: false
  })

  const handleSaveProfile = async () => {
    setLoading(true)
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000))
      toast.success("Profile updated successfully")
    } catch (error) {
      toast.error("Failed to update profile")
    } finally {
      setLoading(false)
    }
  }

  const handleSaveNotifications = async () => {
    setLoading(true)
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000))
      toast.success("Notification settings updated")
    } catch (error) {
      toast.error("Failed to update notification settings")
    } finally {
      setLoading(false)
    }
  }

  const handleGenerateApiKey = async () => {
    setLoading(true)
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000))
      const newKey = {
        id: Date.now().toString(),
        name: `API Key ${apiKeys.length + 1}`,
        key: `sk_${Math.random().toString(36).substr(2, 32)}`,
        createdAt: new Date().toISOString().split('T')[0],
        lastUsed: "Never",
        isActive: true
      }
      setApiKeys(prev => [newKey, ...prev])
      toast.success("New API key generated")
    } catch (error) {
      toast.error("Failed to generate API key")
    } finally {
      setLoading(false)
    }
  }

  const handleRevokeApiKey = async (keyId: string) => {
    try {
      setApiKeys(prev => prev.filter(key => key.id !== keyId))
      toast.success("API key revoked")
    } catch (error) {
      toast.error("Failed to revoke API key")
    }
  }

  const handleExportData = async () => {
    setLoading(true)
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000))
      toast.success("Data export started. You'll receive an email when it's ready.")
    } catch (error) {
      toast.error("Failed to start data export")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold tracking-tight">Settings</h1>
        <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
          Manage your account, preferences, and configurations
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-8">
        <TabsList className="grid w-full grid-cols-7 h-auto p-1 bg-muted/50 rounded-lg">
          <TabsTrigger 
            value="profile" 
            className="flex flex-col items-center gap-2 py-3 px-2 data-[state=active]:bg-background data-[state=active]:shadow-sm rounded-md transition-all"
          >
            <User className="h-4 w-4" />
            <span className="text-xs font-medium">Profile</span>
          </TabsTrigger>
          <TabsTrigger 
            value="notifications" 
            className="flex flex-col items-center gap-2 py-3 px-2 data-[state=active]:bg-background data-[state=active]:shadow-sm rounded-md transition-all"
          >
            <Bell className="h-4 w-4" />
            <span className="text-xs font-medium">Notifications</span>
          </TabsTrigger>
          <TabsTrigger 
            value="services" 
            className="flex flex-col items-center gap-2 py-3 px-2 data-[state=active]:bg-background data-[state=active]:shadow-sm rounded-md transition-all"
          >
            <Database className="h-4 w-4" />
            <span className="text-xs font-medium">Services</span>
          </TabsTrigger>
          <TabsTrigger 
            value="billing" 
            className="flex flex-col items-center gap-2 py-3 px-2 data-[state=active]:bg-background data-[state=active]:shadow-sm rounded-md transition-all"
          >
            <CreditCard className="h-4 w-4" />
            <span className="text-xs font-medium">Billing</span>
          </TabsTrigger>
          <TabsTrigger 
            value="api" 
            className="flex flex-col items-center gap-2 py-3 px-2 data-[state=active]:bg-background data-[state=active]:shadow-sm rounded-md transition-all"
          >
            <Key className="h-4 w-4" />
            <span className="text-xs font-medium">API</span>
          </TabsTrigger>
          <TabsTrigger 
            value="privacy" 
            className="flex flex-col items-center gap-2 py-3 px-2 data-[state=active]:bg-background data-[state=active]:shadow-sm rounded-md transition-all"
          >
            <Shield className="h-4 w-4" />
            <span className="text-xs font-medium">Privacy</span>
          </TabsTrigger>
          <TabsTrigger 
            value="appearance" 
            className="flex flex-col items-center gap-2 py-3 px-2 data-[state=active]:bg-background data-[state=active]:shadow-sm rounded-md transition-all"
          >
            <Palette className="h-4 w-4" />
            <span className="text-xs font-medium">Appearance</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="profile" className="space-y-6">
          <Card className="border-border/50 shadow-sm">
            <CardHeader className="space-y-4 pb-6">
              <div className="space-y-2">
                <CardTitle className="text-xl">Profile Information</CardTitle>
                <CardDescription className="text-base">
                  Update your personal information and account details
                </CardDescription>
              </div>
            </CardHeader>
            <CardContent className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <Label htmlFor="name" className="text-sm font-medium">Full Name</Label>
                  <Input
                    id="name"
                    value={profile.name}
                    onChange={(e) => setProfile(prev => ({ ...prev, name: e.target.value }))}
                    className="h-11"
                  />
                </div>
                <div className="space-y-3">
                  <Label htmlFor="email" className="text-sm font-medium">Email Address</Label>
                  <Input
                    id="email"
                    type="email"
                    value={profile.email}
                    onChange={(e) => setProfile(prev => ({ ...prev, email: e.target.value }))}
                    className="h-11"
                  />
                </div>
              </div>
              <div className="space-y-3">
                <Label htmlFor="bio" className="text-sm font-medium">Bio</Label>
                <Textarea
                  id="bio"
                  placeholder="Tell us about yourself..."
                  value={profile.bio}
                  onChange={(e) => setProfile(prev => ({ ...prev, bio: e.target.value }))}
                  className="min-h-[100px] resize-none"
                />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <Label htmlFor="timezone" className="text-sm font-medium">Timezone</Label>
                  <Select value={profile.timezone} onValueChange={(value) => setProfile(prev => ({ ...prev, timezone: value }))}>
                    <SelectTrigger className="h-11">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="UTC">UTC</SelectItem>
                      <SelectItem value="America/New_York">Eastern Time</SelectItem>
                      <SelectItem value="America/Los_Angeles">Pacific Time</SelectItem>
                      <SelectItem value="Europe/London">London</SelectItem>
                      <SelectItem value="Asia/Tokyo">Tokyo</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-3">
                  <Label htmlFor="language" className="text-sm font-medium">Language</Label>
                  <Select value={profile.language} onValueChange={(value) => setProfile(prev => ({ ...prev, language: value }))}>
                    <SelectTrigger className="h-11">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="en">English</SelectItem>
                      <SelectItem value="es">Spanish</SelectItem>
                      <SelectItem value="fr">French</SelectItem>
                      <SelectItem value="de">German</SelectItem>
                      <SelectItem value="ja">Japanese</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="flex justify-end pt-4">
                <Button onClick={handleSaveProfile} disabled={loading} className="h-11 px-6">
                  <Save className="mr-2 h-4 w-4" />
                  Save Changes
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-6">
          <Card className="border-border/50 shadow-sm">
            <CardHeader className="space-y-4 pb-6">
              <div className="space-y-2">
                <CardTitle className="text-xl">Notification Preferences</CardTitle>
                <CardDescription className="text-base">
                  Choose how you want to receive notifications
                </CardDescription>
              </div>
            </CardHeader>
            <CardContent className="space-y-8">
              <div className="space-y-6">
                <div className="flex items-center justify-between py-2">
                  <div className="space-y-1">
                    <Label className="text-base font-medium">Email Notifications</Label>
                    <p className="text-sm text-muted-foreground">
                      Receive notifications via email
                    </p>
                  </div>
                  <Switch
                    checked={notifications.emailNotifications}
                    onCheckedChange={(checked) => setNotifications(prev => ({ ...prev, emailNotifications: checked }))}
                  />
                </div>
                <Separator className="my-4" />
                <div className="flex items-center justify-between py-2">
                  <div className="space-y-1">
                    <Label className="text-base font-medium">Push Notifications</Label>
                    <p className="text-sm text-muted-foreground">
                      Receive push notifications in your browser
                    </p>
                  </div>
                  <Switch
                    checked={notifications.pushNotifications}
                    onCheckedChange={(checked) => setNotifications(prev => ({ ...prev, pushNotifications: checked }))}
                  />
                </div>
                <Separator className="my-4" />
                <div className="flex items-center justify-between py-2">
                  <div className="space-y-1">
                    <Label className="text-base font-medium">Usage Alerts</Label>
                    <p className="text-sm text-muted-foreground">
                      Get notified when approaching usage limits
                    </p>
                  </div>
                  <Switch
                    checked={notifications.usageAlerts}
                    onCheckedChange={(checked) => setNotifications(prev => ({ ...prev, usageAlerts: checked }))}
                  />
                </div>
                <Separator className="my-4" />
                <div className="flex items-center justify-between py-2">
                  <div className="space-y-1">
                    <Label className="text-base font-medium">Renewal Reminders</Label>
                    <p className="text-sm text-muted-foreground">
                      Receive reminders before subscription renewals
                    </p>
                  </div>
                  <Switch
                    checked={notifications.renewalReminders}
                    onCheckedChange={(checked) => setNotifications(prev => ({ ...prev, renewalReminders: checked }))}
                  />
                </div>
                <Separator className="my-4" />
                <div className="flex items-center justify-between py-2">
                  <div className="space-y-1">
                    <Label className="text-base font-medium">Cost Alerts</Label>
                    <p className="text-sm text-muted-foreground">
                      Get notified about unusual spending patterns
                    </p>
                  </div>
                  <Switch
                    checked={notifications.costAlerts}
                    onCheckedChange={(checked) => setNotifications(prev => ({ ...prev, costAlerts: checked }))}
                  />
                </div>
                <Separator className="my-4" />
                <div className="flex items-center justify-between py-2">
                  <div className="space-y-1">
                    <Label className="text-base font-medium">Service Updates</Label>
                    <p className="text-sm text-muted-foreground">
                      Receive updates about service changes
                    </p>
                  </div>
                  <Switch
                    checked={notifications.serviceUpdates}
                    onCheckedChange={(checked) => setNotifications(prev => ({ ...prev, serviceUpdates: checked }))}
                  />
                </div>
                <Separator className="my-4" />
                <div className="flex items-center justify-between py-2">
                  <div className="space-y-1">
                    <Label className="text-base font-medium">Marketing Emails</Label>
                    <p className="text-sm text-muted-foreground">
                      Receive marketing and promotional emails
                    </p>
                  </div>
                  <Switch
                    checked={notifications.marketingEmails}
                    onCheckedChange={(checked) => setNotifications(prev => ({ ...prev, marketingEmails: checked }))}
                  />
                </div>
              </div>
              <div className="flex justify-end pt-4">
                <Button onClick={handleSaveNotifications} disabled={loading} className="h-11 px-6">
                  <Save className="mr-2 h-4 w-4" />
                  Save Preferences
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="services" className="space-y-6">
          <Card className="border-border/50 shadow-sm">
            <CardHeader className="space-y-4 pb-6">
              <div className="space-y-2">
                <CardTitle className="text-xl">Service Management</CardTitle>
                <CardDescription className="text-base">
                  Configure your connected AI services and their settings
                </CardDescription>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {services.map((service) => (
                <div key={service.id} className="flex items-center justify-between p-6 border border-border/50 rounded-lg bg-muted/20">
                  <div className="space-y-2">
                    <div className="flex items-center gap-3">
                      <h4 className="font-semibold text-lg">{service.name}</h4>
                      <Badge variant={service.isActive ? "default" : "secondary"} className="text-xs">
                        {service.isActive ? "Active" : "Inactive"}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground font-medium">{service.provider}</p>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium">Auto Sync</span>
                      <Switch
                        checked={service.autoSync}
                        onCheckedChange={(checked) => {
                          setServices(prev => prev.map(s => 
                            s.id === service.id ? { ...s, autoSync: checked } : s
                          ))
                        }}
                      />
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium">Frequency</span>
                      <Select value={service.syncFrequency} onValueChange={(value) => {
                        setServices(prev => prev.map(s => 
                          s.id === service.id ? { ...s, syncFrequency: value } : s
                        ))
                      }}>
                        <SelectTrigger className="w-32 h-9">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="hourly">Hourly</SelectItem>
                          <SelectItem value="daily">Daily</SelectItem>
                          <SelectItem value="weekly">Weekly</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="billing" className="space-y-6">
          <Card className="border-border/50 shadow-sm">
            <CardHeader className="space-y-4 pb-6">
              <div className="space-y-2">
                <CardTitle className="text-xl">Billing & Subscription</CardTitle>
                <CardDescription className="text-base">
                  Manage your subscription and payment methods
                </CardDescription>
              </div>
            </CardHeader>
            <CardContent className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-6">
                  <h4 className="font-semibold text-lg">Current Plan</h4>
                  <div className="p-6 border border-border/50 rounded-lg bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-950/20 dark:to-indigo-950/20">
                    <div className="flex items-center justify-between mb-4">
                      <span className="font-semibold text-lg capitalize">{billing.plan}</span>
                      <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200 dark:bg-green-950/20 dark:text-green-400 dark:border-green-800">
                        Active
                      </Badge>
                    </div>
                    <p className="text-muted-foreground mb-6 font-medium">
                      {billing.plan === "free" ? "2 service limit" : "Unlimited services"}
                    </p>
                    <Button variant="outline" className="w-full h-11 font-medium">
                      Upgrade Plan
                    </Button>
                  </div>
                </div>
                <div className="space-y-6">
                  <h4 className="font-semibold text-lg">Payment Method</h4>
                  <div className="p-6 border border-border/50 rounded-lg bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-950/20 dark:to-pink-950/20">
                    <div className="flex items-center justify-between mb-4">
                      <span className="font-semibold text-lg">{billing.paymentMethod}</span>
                      <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950/20 dark:text-blue-400 dark:border-blue-800">
                        Default
                      </Badge>
                    </div>
                    <p className="text-muted-foreground mb-6 font-medium">
                      Expires 12/2025
                    </p>
                    <Button variant="outline" className="w-full h-11 font-medium">
                      Update Payment Method
                    </Button>
                  </div>
                </div>
              </div>
              <div className="space-y-6">
                <div className="flex items-center justify-between py-4 px-6 border border-border/50 rounded-lg bg-muted/20">
                  <div className="space-y-1">
                    <Label className="text-base font-medium">Auto Renewal</Label>
                    <p className="text-sm text-muted-foreground">
                      Automatically renew your subscription
                    </p>
                  </div>
                  <Switch
                    checked={billing.autoRenew}
                    onCheckedChange={(checked) => setBilling(prev => ({ ...prev, autoRenew: checked }))}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="api" className="space-y-6">
          <Card className="border-border/50 shadow-sm">
            <CardHeader className="space-y-4 pb-6">
              <div className="space-y-2">
                <CardTitle className="text-xl">API Keys</CardTitle>
                <CardDescription className="text-base">
                  Manage your API keys for programmatic access
                </CardDescription>
              </div>
            </CardHeader>
            <CardContent className="space-y-8">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 p-6 border border-border/50 rounded-lg bg-muted/20">
                <div className="space-y-2">
                  <h4 className="font-semibold text-base">API Access</h4>
                  <p className="text-sm text-muted-foreground max-w-md">
                    API keys allow you to access your account programmatically. Keep them secure and never share them publicly.
                  </p>
                </div>
                <Button onClick={handleGenerateApiKey} disabled={loading} className="h-11 px-6 font-medium whitespace-nowrap">
                  <Plus className="mr-2 h-4 w-4" />
                  Generate New Key
                </Button>
              </div>
              <div className="space-y-4">
                {apiKeys.map((apiKey) => (
                  <div key={apiKey.id} className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-6 border border-border/50 rounded-lg bg-card">
                    <div className="space-y-3 flex-1">
                      <div className="flex items-center gap-3">
                        <h4 className="font-semibold text-base">{apiKey.name}</h4>
                        <Badge variant={apiKey.isActive ? "default" : "secondary"} className="text-xs">
                          {apiKey.isActive ? "Active" : "Inactive"}
                        </Badge>
                      </div>
                      <div className="space-y-2">
                        <p className="text-sm font-mono text-muted-foreground bg-muted/50 px-3 py-2 rounded-md">
                          {apiKey.key}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          Created: {apiKey.createdAt} • Last used: {apiKey.lastUsed}
                        </p>
                      </div>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleRevokeApiKey(apiKey.id)}
                      className="h-9 px-4 font-medium text-red-600 border-red-200 hover:bg-red-50 hover:text-red-700 dark:border-red-800 dark:hover:bg-red-950/20 dark:hover:text-red-400"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="privacy" className="space-y-6">
          <Card className="border-border/50 shadow-sm">
            <CardHeader className="space-y-4 pb-6">
              <div className="space-y-2">
                <CardTitle className="text-xl">Privacy & Data</CardTitle>
                <CardDescription className="text-base">
                  Manage your data privacy and export options
                </CardDescription>
              </div>
            </CardHeader>
            <CardContent className="space-y-8">
              <div className="space-y-6">
                <div className="flex items-center justify-between py-2">
                  <div className="space-y-1">
                    <Label className="text-base font-medium">Data Retention Period</Label>
                    <p className="text-sm text-muted-foreground">
                      How long to keep your data
                    </p>
                  </div>
                  <Select value={privacy.dataRetention} onValueChange={(value) => setPrivacy(prev => ({ ...prev, dataRetention: value }))}>
                    <SelectTrigger className="w-32 h-9">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="30">30 days</SelectItem>
                      <SelectItem value="90">90 days</SelectItem>
                      <SelectItem value="365">1 year</SelectItem>
                      <SelectItem value="forever">Forever</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Separator className="my-4" />
                <div className="flex items-center justify-between py-2">
                  <div className="space-y-1">
                    <Label className="text-base font-medium">Analytics Sharing</Label>
                    <p className="text-sm text-muted-foreground">
                      Share anonymous usage data to improve the service
                    </p>
                  </div>
                  <Switch
                    checked={privacy.analyticsSharing}
                    onCheckedChange={(checked) => setPrivacy(prev => ({ ...prev, analyticsSharing: checked }))}
                  />
                </div>
                <Separator className="my-4" />
                <div className="flex items-center justify-between py-2">
                  <div className="space-y-1">
                    <Label className="text-base font-medium">Crash Reports</Label>
                    <p className="text-sm text-muted-foreground">
                      Send crash reports to help fix bugs
                    </p>
                  </div>
                  <Switch
                    checked={privacy.crashReports}
                    onCheckedChange={(checked) => setPrivacy(prev => ({ ...prev, crashReports: checked }))}
                  />
                </div>
                <Separator className="my-4" />
                <div className="flex items-center justify-between py-2">
                  <div className="space-y-1">
                    <Label className="text-base font-medium">Marketing Consent</Label>
                    <p className="text-sm text-muted-foreground">
                      Allow marketing communications
                    </p>
                  </div>
                  <Switch
                    checked={privacy.marketingConsent}
                    onCheckedChange={(checked) => setPrivacy(prev => ({ ...prev, marketingConsent: checked }))}
                  />
                </div>
              </div>
              <div className="space-y-6 p-6 border border-border/50 rounded-lg bg-muted/20">
                <h4 className="font-semibold text-lg mb-2">Data Export</h4>
                <p className="text-sm text-muted-foreground mb-4">
                  Download all your data in a portable format. This includes your profile, services, usage records, notifications, and insights.
                </p>
                <Button onClick={handleExportData} disabled={loading} className="h-11 px-6 font-medium">
                  <Download className="mr-2 h-4 w-4" />
                  Export My Data
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="appearance" className="space-y-6">
          <Card className="border-border/50 shadow-sm">
            <CardHeader className="space-y-4 pb-6">
              <div className="space-y-2">
                <CardTitle className="text-xl">Appearance</CardTitle>
                <CardDescription className="text-base">
                  Customize the look and feel of the application
                </CardDescription>
              </div>
            </CardHeader>
            <CardContent className="space-y-8">
              <div className="space-y-6">
                <div className="flex items-center justify-between py-2">
                  <div className="space-y-1">
                    <Label className="text-base font-medium">Theme</Label>
                    <p className="text-sm text-muted-foreground">
                      Choose your preferred theme
                    </p>
                  </div>
                  <Select value={appearance.theme} onValueChange={(value) => setAppearance(prev => ({ ...prev, theme: value }))}>
                    <SelectTrigger className="w-32 h-9">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="light">Light</SelectItem>
                      <SelectItem value="dark">Dark</SelectItem>
                      <SelectItem value="system">System</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Separator className="my-4" />
                <div className="flex items-center justify-between py-2">
                  <div className="space-y-1">
                    <Label className="text-base font-medium">Accent Color</Label>
                    <p className="text-sm text-muted-foreground">
                      Choose your accent color
                    </p>
                  </div>
                  <Select value={appearance.accentColor} onValueChange={(value) => setAppearance(prev => ({ ...prev, accentColor: value }))}>
                    <SelectTrigger className="w-32 h-9">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="blue">Blue</SelectItem>
                      <SelectItem value="green">Green</SelectItem>
                      <SelectItem value="purple">Purple</SelectItem>
                      <SelectItem value="orange">Orange</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Separator className="my-4" />
                <div className="flex items-center justify-between py-2">
                  <div className="space-y-1">
                    <Label className="text-base font-medium">Font Size</Label>
                    <p className="text-sm text-muted-foreground">
                      Adjust the font size
                    </p>
                  </div>
                  <Select value={appearance.fontSize} onValueChange={(value) => setAppearance(prev => ({ ...prev, fontSize: value }))}>
                    <SelectTrigger className="w-32 h-9">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="small">Small</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="large">Large</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Separator className="my-4" />
                <div className="flex items-center justify-between py-2">
                  <div className="space-y-1">
                    <Label className="text-base font-medium">Dense Mode</Label>
                    <p className="text-sm text-muted-foreground">
                      Use more compact layout
                    </p>
                  </div>
                  <Switch
                    checked={appearance.denseMode}
                    onCheckedChange={(checked) => setAppearance(prev => ({ ...prev, denseMode: checked }))}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}