'use client';

import { useEffect } from 'react';
import { useSearchParams } from 'next/navigation';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertTriangle, RefreshCw, Home } from 'lucide-react';
import { useRouter } from 'next/navigation';

export function AuthErrorHandler() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const error = searchParams.get('error');
  const service = searchParams.get('service');

  useEffect(() => {
    if (error) {
      console.error('Auth error:', error);
    }
  }, [error]);

  if (!error) {
    return null;
  }

  const getErrorMessage = (error: string) => {
    switch (error) {
      case 'access_denied':
        return 'You denied access to the service. Please try again and accept the permissions when prompted.';
      case 'invalid_request':
        return 'The authorization request was invalid. Please try again.';
      case 'unauthorized_client':
        return 'The application is not authorized to access this service.';
      case 'unsupported_response_type':
        return 'The authorization server does not support this response type.';
      case 'invalid_scope':
        return 'The requested scope is invalid or not supported.';
      case 'server_error':
        return 'The authorization server encountered an error. Please try again later.';
      case 'temporarily_unavailable':
        return 'The authorization server is temporarily unavailable. Please try again later.';
      case 'missing_parameters':
        return 'Required parameters are missing from the authorization request.';
      case 'invalid_token':
        return 'The access token is invalid or has expired.';
      case 'expired_token':
        return 'The access token has expired. Please reconnect the service.';
      case 'revoked_token':
        return 'The access token has been revoked. Please reconnect the service.';
      default:
        return 'An unknown error occurred during authorization.';
    }
  };

  const getErrorTitle = (error: string) => {
    switch (error) {
      case 'access_denied':
        return 'Access Denied';
      case 'invalid_token':
      case 'expired_token':
      case 'revoked_token':
        return 'Token Error';
      case 'server_error':
      case 'temporarily_unavailable':
        return 'Service Unavailable';
      default:
        return 'Authorization Failed';
    }
  };

  const handleRetry = () => {
    if (service) {
      router.push(`/?service=${service}&retry=true`);
    } else {
      router.push('/');
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <div className="flex items-center space-x-2">
            <AlertTriangle className="h-5 w-5 text-red-600" />
            <CardTitle className="text-red-600">{getErrorTitle(error)}</CardTitle>
          </div>
          <CardDescription>
            There was a problem connecting to the AI service
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription className="text-sm">
              {getErrorMessage(error)}
            </AlertDescription>
          </Alert>

          <div className="space-y-2">
            <h4 className="font-medium text-sm">Troubleshooting steps:</h4>
            <ul className="text-sm text-muted-foreground space-y-1">
              <li>• Make sure you're logged into the correct account</li>
              <li>• Check that the service has proper API access enabled</li>
              <li>• Ensure your account has the necessary permissions</li>
              <li>• Try clearing your browser cookies and cache</li>
              <li>• Contact the service support if the problem persists</li>
            </ul>
          </div>

          <div className="flex space-x-2">
            <Button onClick={handleRetry} className="flex-1">
              <RefreshCw className="w-4 h-4 mr-2" />
              Try Again
            </Button>
            <Button variant="outline" onClick={() => router.push('/')} className="flex-1">
              <Home className="w-4 h-4 mr-2" />
              Go Home
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}