'use client';

import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Search, 
  Plus, 
  ExternalLink, 
  Star, 
  Zap, 
  Key, 
  Shield, 
  Users,
  MessageCircle,
  Image as ImageIcon,
  Music,
  Video,
  Code,
  Wand2,
  Globe,
  PlusCircle,
  AlertCircle
} from 'lucide-react';
import { 
  AI_SERVICES_DIRECTORY, 
  AIServiceConfig, 
  getAIServicesByCategory, 
  searchAIServices, 
  getPopularAIServices,
  getAIServicesWithFreeTier
} from '@/lib/ai-services-directory';
import { toast } from 'sonner';

interface ServiceSelectorProps {
  onServiceSelect: (service: AIServiceConfig) => void;
  children: React.ReactNode;
}

export function EnhancedServiceSelector({ onServiceSelect, children }: ServiceSelectorProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [filteredServices, setFilteredServices] = useState<AIServiceConfig[]>(AI_SERVICES_DIRECTORY);
  const [showRequestForm, setShowRequestForm] = useState(false);
  const [requestServiceName, setRequestServiceName] = useState('');
  const [requestServiceUrl, setRequestServiceUrl] = useState('');
  const [requestServiceDescription, setRequestServiceDescription] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const categories = [
    { id: 'all', name: 'All Services', count: AI_SERVICES_DIRECTORY.length, icon: Globe },
    { id: 'text', name: 'Text & Chat', count: getAIServicesByCategory('text').length, icon: MessageCircle },
    { id: 'image', name: 'Image Generation', count: getAIServicesByCategory('image').length, icon: ImageIcon },
    { id: 'audio', name: 'Audio & Music', count: getAIServicesByCategory('audio').length, icon: Music },
    { id: 'video', name: 'Video Generation', count: getAIServicesByCategory('video').length, icon: Video },
    { id: 'code', name: 'Code & Development', count: getAIServicesByCategory('code').length, icon: Code },
    { id: 'multimodal', name: 'Multimodal', count: getAIServicesByCategory('multimodal').length, icon: Wand2 },
  ];

  useEffect(() => {
    let services = AI_SERVICES_DIRECTORY;

    // Filter by category
    if (selectedCategory !== 'all') {
      services = getAIServicesByCategory(selectedCategory);
    }

    // Filter by search query
    if (searchQuery.trim()) {
      services = searchAIServices(searchQuery);
    }

    setFilteredServices(services);
  }, [searchQuery, selectedCategory]);

  const handleServiceClick = (service: AIServiceConfig) => {
    onServiceSelect(service);
  };

  const handleRequestService = async () => {
    if (!requestServiceName.trim() || !requestServiceUrl.trim()) {
      toast.error('Please fill in all required fields');
      return;
    }

    setIsSubmitting(true);
    try {
      const response = await fetch('/api/service-request', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          serviceName: requestServiceName,
          serviceUrl: requestServiceUrl,
          serviceDescription: requestServiceDescription,
          userId: 'cmdypf4pf0006shrbkmv1mk8i', // Current user ID
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to submit request');
      }

      const data = await response.json();
      toast.success(`Service request submitted successfully! Request ID: ${data.requestId}`);
      
      // Reset form
      setRequestServiceName('');
      setRequestServiceUrl('');
      setRequestServiceDescription('');
      setShowRequestForm(false);
    } catch (error) {
      console.error('Error submitting service request:', error);
      toast.error('Failed to submit request. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const getAuthIcon = (authType: string) => {
    switch (authType) {
      case 'oauth':
        return <Users className="w-4 h-4" />;
      case 'api-key':
        return <Key className="w-4 h-4" />;
      case 'none':
        return <Shield className="w-4 h-4" />;
      default:
        return <Key className="w-4 h-4" />;
    }
  };

  const getAuthColor = (authType: string) => {
    switch (authType) {
      case 'oauth':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'api-key':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'none':
        return 'bg-gray-100 text-gray-800 border-gray-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'hard':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const ServiceCard = ({ service }: { service: AIServiceConfig }) => (
    <Card className="hover:shadow-lg transition-all duration-300 cursor-pointer group border-border/50 shadow-sm">
      <CardContent className="p-6">
        <div className="flex items-start space-x-6">
          {/* Logo */}
          <div className="flex-shrink-0">
            <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-950/20 dark:to-indigo-950/20 flex items-center justify-center overflow-hidden border border-border/50">
              {service.logoEmoji ? (
                <span className="text-3xl">{service.logoEmoji}</span>
              ) : (
                <img
                  src={service.logo}
                  alt={service.name}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.style.display = 'none';
                    const parent = target.parentElement;
                    if (parent) {
                      const fallback = document.createElement('span');
                      fallback.textContent = '🤖';
                      fallback.className = 'text-3xl';
                      parent.appendChild(fallback);
                    }
                  }}
                />
              )}
            </div>
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center space-x-3 mb-2">
                  <h3 className="font-bold text-base group-hover:text-blue-600 transition-colors">
                    {service.name}
                  </h3>
                  <div className="flex items-center">
                    <Star className="w-4 h-4 text-yellow-500 fill-current" />
                    <span className="text-sm text-muted-foreground ml-1">{service.popularity}</span>
                  </div>
                </div>
                
                <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
                  {service.description}
                </p>

                {/* Features */}
                <div className="flex flex-wrap gap-2 mb-3">
                  {service.features.slice(0, 3).map((feature, index) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      {feature}
                    </Badge>
                  ))}
                  {service.features.length > 3 && (
                    <Badge variant="outline" className="text-xs">
                      +{service.features.length - 3}
                    </Badge>
                  )}
                </div>

                {/* Connection Method & Difficulty */}
                <div className="flex items-center space-x-2 text-sm">
                  <Badge className={getAuthColor(service.authType)}>
                    {getAuthIcon(service.authType)}
                    <span className="ml-1">{service.authType === 'oauth' ? 'OAuth' : service.authType === 'api-key' ? 'API Key' : 'None'}</span>
                  </Badge>
                  <Badge className={getDifficultyColor(service.setupDifficulty)}>
                    {service.setupDifficulty}
                  </Badge>
                  <Badge variant="secondary">
                    {service.pricing}
                  </Badge>
                  {service.hasFreeTier && (
                    <Badge variant="outline" className="text-green-600 border-green-600">
                      <Zap className="w-3 h-3 mr-1" />
                      Free Tier
                    </Badge>
                  )}
                </div>
              </div>

              {/* Connect Button */}
              <Button 
                size="sm" 
                className="ml-4 opacity-0 group-hover:opacity-100 transition-all duration-300 h-9 px-4"
                onClick={(e) => {
                  e.stopPropagation();
                  handleServiceClick(service);
                }}
              >
                <Plus className="w-4 h-4 mr-1" />
                Connect
              </Button>
            </div>

            {/* Connection Method Description */}
            <div className="mt-3 p-3 bg-muted/30 rounded-lg text-sm text-muted-foreground">
              <span className="font-medium">How to connect:</span> {service.connectionMethod}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <Dialog>
      <DialogTrigger asChild>
        {children}
      </DialogTrigger>
      <DialogContent className="max-w-7xl max-h-[90vh] p-0">
        <div className="h-full flex flex-col">
          <DialogHeader className="px-8 pt-8 pb-6 border-b">
            <DialogTitle className="text-2xl font-bold flex items-center space-x-3">
              <PlusCircle className="w-6 h-6" />
              <span>Add AI Service</span>
            </DialogTitle>
          </DialogHeader>
          
          <div className="flex-1 overflow-y-auto px-8 pb-8">
            <div className="space-y-8">
              {/* Search and Request Service */}
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-muted-foreground w-5 h-5" />
                  <Input
                    placeholder="Search AI services by name, description, or features..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-12 h-12 text-base"
                  />
                </div>
                <Button 
                  variant="outline" 
                  onClick={() => setShowRequestForm(!showRequestForm)}
                  className="h-12 px-6 font-medium whitespace-nowrap"
                >
                  <PlusCircle className="w-5 h-5 mr-2" />
                  Request Service
                </Button>
              </div>

              {/* Request Service Form */}
              {showRequestForm && (
                <Card className="border-blue-200 bg-blue-50 dark:bg-blue-950/20 dark:border-blue-800">
                  <CardHeader className="pb-4">
                    <CardTitle className="text-lg flex items-center">
                      <PlusCircle className="w-5 h-5 mr-2" />
                      Request New AI Service
                    </CardTitle>
                    <CardDescription className="text-base">
                      Can't find the AI service you're looking for? Let us know and we'll add it!
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="block text-sm font-medium">
                          Service Name *
                        </label>
                        <Input
                          placeholder="e.g., New AI Service"
                          value={requestServiceName}
                          onChange={(e) => setRequestServiceName(e.target.value)}
                          className="h-11"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="block text-sm font-medium">
                          Website URL *
                        </label>
                        <Input
                          placeholder="https://example.com"
                          value={requestServiceUrl}
                          onChange={(e) => setRequestServiceUrl(e.target.value)}
                          className="h-11"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <label className="block text-sm font-medium">
                        Description (Optional)
                      </label>
                      <Input
                        placeholder="Brief description of the service..."
                        value={requestServiceDescription}
                        onChange={(e) => setRequestServiceDescription(e.target.value)}
                        className="h-11"
                      />
                    </div>
                    <div className="flex justify-end space-x-3">
                      <Button 
                        variant="outline" 
                        onClick={() => setShowRequestForm(false)}
                        className="h-11 px-6"
                      >
                        Cancel
                      </Button>
                      <Button 
                        onClick={handleRequestService}
                        disabled={isSubmitting}
                        className="h-11 px-6"
                      >
                        {isSubmitting ? 'Submitting...' : 'Submit Request'}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Category Tabs */}
              <Tabs value={selectedCategory} onValueChange={setSelectedCategory}>
                <TabsList className="grid w-full grid-cols-7 h-auto p-1 bg-muted/50 rounded-lg">
                  {categories.map((category) => {
                    const Icon = category.icon;
                    return (
                      <TabsTrigger
                        key={category.id}
                        value={category.id}
                        className="flex flex-col items-center gap-2 py-3 px-2 data-[state=active]:bg-background data-[state=active]:shadow-sm rounded-md transition-all"
                      >
                        <Icon className="w-4 h-4" />
                        <span className="text-xs font-medium">{category.name}</span>
                        <Badge variant="secondary" className="text-xs">
                          {category.count}
                        </Badge>
                      </TabsTrigger>
                    );
                  })}
                </TabsList>

                <TabsContent value={selectedCategory} className="mt-6">
                  <ScrollArea className="h-[50vh]">
                    {filteredServices.length === 0 ? (
                      <div className="text-center py-16">
                        <AlertCircle className="w-16 h-16 text-muted-foreground mx-auto mb-6" />
                        <p className="text-lg text-muted-foreground mb-6">No services found matching your search.</p>
                        <Button 
                          variant="outline" 
                          onClick={() => setShowRequestForm(true)}
                          className="h-11 px-6"
                        >
                          <PlusCircle className="w-5 h-5 mr-2" />
                          Request This Service
                        </Button>
                      </div>
                    ) : (
                      <div className="grid gap-6">
                        {filteredServices.map((service) => (
                          <ServiceCard key={service.id} service={service} />
                        ))}
                      </div>
                    )}
                  </ScrollArea>
                </TabsContent>
              </Tabs>

              {/* Popular Services Section */}
              {searchQuery === '' && selectedCategory === 'all' && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-semibold flex items-center">
                      <Star className="w-5 h-5 mr-2" />
                      Popular Services
                    </h3>
                    <Badge variant="outline" className="text-sm">
                      Most Used
                    </Badge>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {getPopularAIServices(4).map((service) => (
                      <ServiceCard key={service.id} service={service} />
                    ))}
                  </div>
                </div>
              )}

              {/* Free Tier Services Section */}
              {searchQuery === '' && selectedCategory === 'all' && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-semibold flex items-center">
                      <Zap className="w-5 h-5 mr-2" />
                      Services with Free Tier
                    </h3>
                    <Badge variant="outline" className="text-sm text-green-600 border-green-600">
                      Try Before You Buy
                    </Badge>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {getAIServicesWithFreeTier().slice(0, 4).map((service) => (
                      <ServiceCard key={service.id} service={service} />
                    ))}
                  </div>
                </div>
              )}

              {/* Legend */}
              <div className="border-t pt-6">
                <h4 className="text-sm font-medium mb-4">Connection Types:</h4>
                <div className="flex flex-wrap gap-3">
                  <Badge className="bg-blue-100 text-blue-800 border-blue-200 px-3 py-1">
                    <Users className="w-3 h-3 mr-1" />
                    OAuth - Sign in with account
                  </Badge>
                  <Badge className="bg-green-100 text-green-800 border-green-200 px-3 py-1">
                    <Key className="w-3 h-3 mr-1" />
                    API Key - Enter credentials
                  </Badge>
                  <Badge className="bg-gray-100 text-gray-800 border-gray-200 px-3 py-1">
                    <Shield className="w-3 h-3 mr-1" />
                    None - No authentication
                  </Badge>
                </div>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}