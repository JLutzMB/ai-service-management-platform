"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { 
  Brain, 
  DollarSign, 
  Calendar, 
  Settings, 
  Power, 
  ExternalLink,
  TrendingUp,
  TrendingDown,
  RefreshCw,
  CheckCircle,
  XCircle,
  Clock
} from "lucide-react"

interface AIService {
  id: string
  name: string
  provider: string
  isActive: boolean
  credits?: number
  tokens?: number
  creditLimit?: number
  tokenLimit?: number
  planType?: string
  renewalDate?: string
  pricePer1kTokens?: number
  monthlyCost?: number
  currency?: string
  lastSync?: string
  syncStatus?: 'synced' | 'syncing' | 'error'
}

interface AIServiceCardProps {
  service: AIService
  onSync: () => void
  isSyncing: boolean
  onEdit: () => void
  onToggle: () => void
}

export function AIServiceCard({ service, onSync, isSyncing, onEdit, onToggle }: AIServiceCardProps) {
  const creditPercentage = service.creditLimit && service.credits 
    ? (service.credits / service.creditLimit) * 100 
    : 0
  
  const tokenPercentage = service.tokenLimit && service.tokens 
    ? (service.tokens / service.tokenLimit) * 100 
    : 0

  const getProviderColor = (provider: string) => {
    switch (provider.toLowerCase()) {
      case "openai":
        return "bg-green-100 text-green-800 border-green-200"
      case "anthropic":
        return "bg-purple-100 text-purple-800 border-purple-200"
      case "google":
        return "bg-blue-100 text-blue-800 border-blue-200"
      case "microsoft":
        return "bg-orange-100 text-orange-800 border-orange-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  const getPlanColor = (planType?: string) => {
    switch (planType?.toLowerCase()) {
      case "free":
        return "secondary"
      case "pro":
        return "default"
      case "enterprise":
        return "destructive"
      default:
        return "outline"
    }
  }

  const getSyncStatusIcon = () => {
    if (isSyncing) {
      return <RefreshCw className="h-4 w-4 animate-spin text-blue-500" />
    }
    switch (service.syncStatus) {
      case 'synced':
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case 'error':
        return <XCircle className="h-4 w-4 text-red-500" />
      default:
        return <Clock className="h-4 w-4 text-gray-400" />
    }
  }

  const getSyncStatusText = () => {
    if (isSyncing) return 'Syncing...'
    switch (service.syncStatus) {
      case 'synced':
        return 'Synced'
      case 'error':
        return 'Sync Error'
      default:
        return 'Not Synced'
    }
  }

  const formatNumber = (num: number) => {
    if (num >= 1000000) {
      return `${(num / 1000000).toFixed(1)}M`
    } else if (num >= 1000) {
      return `${(num / 1000).toFixed(1)}K`
    }
    return num.toString()
  }

  const getDaysUntilRenewal = (renewalDate?: string) => {
    if (!renewalDate) return null
    const renewal = new Date(renewalDate)
    const today = new Date()
    const daysUntilRenewal = Math.ceil((renewal.getTime() - today.getTime()) / (1000 * 60 * 60 * 24))
    return daysUntilRenewal
  }

  const formatLastSync = (lastSync?: string) => {
    if (!lastSync) return 'Never'
    const date = new Date(lastSync)
    const now = new Date()
    const diffMs = now.getTime() - date.getTime()
    const diffMinutes = Math.floor(diffMs / (1000 * 60))
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60))
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24))

    if (diffMinutes < 1) return 'Just now'
    if (diffMinutes < 60) return `${diffMinutes}m ago`
    if (diffHours < 24) return `${diffHours}h ago`
    return `${diffDays}d ago`
  }

  const daysUntilRenewal = getDaysUntilRenewal(service.renewalDate)

  return (
    <Card className={`transition-all duration-200 hover:shadow-lg ${!service.isActive ? 'opacity-60' : ''}`}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="space-y-1">
            <CardTitle className="text-lg font-semibold flex items-center gap-2">
              {service.name}
              {!service.isActive && (
                <Badge variant="secondary" className="text-xs">
                  Inactive
                </Badge>
              )}
            </CardTitle>
            <CardDescription className="flex items-center gap-2">
              <Badge variant="outline" className={getProviderColor(service.provider)}>
                {service.provider}
              </Badge>
              {service.planType && (
                <Badge variant={getPlanColor(service.planType)}>
                  {service.planType}
                </Badge>
              )}
            </CardDescription>
          </div>
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="sm"
              onClick={onSync}
              disabled={isSyncing}
              className="h-8 w-8 p-0"
              title={getSyncStatusText()}
            >
              {getSyncStatusIcon()}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={onEdit}
              className="h-8 w-8 p-0"
              title="Edit Service"
            >
              <Settings className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={onToggle}
              className="h-8 w-8 p-0"
              title={service.isActive ? 'Deactivate Service' : 'Activate Service'}
            >
              <Power className={`h-4 w-4 ${service.isActive ? 'text-green-600' : 'text-gray-400'}`} />
            </Button>
          </div>
        </div>
        
        {/* Sync Status */}
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          {getSyncStatusIcon()}
          <span>{getSyncStatusText()}</span>
          {service.lastSync && (
            <>
              <span>•</span>
              <span>{formatLastSync(service.lastSync)}</span>
            </>
          )}
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Credits Section */}
        {service.credits !== undefined && service.creditLimit !== undefined && (
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-1">
                <DollarSign className="h-4 w-4 text-muted-foreground" />
                <span className="font-medium">Credits</span>
              </div>
              <span className="text-muted-foreground">
                ${service.credits.toFixed(2)} / ${service.creditLimit.toFixed(2)}
              </span>
            </div>
            <Progress 
              value={creditPercentage} 
              className="h-2"
            />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>{creditPercentage.toFixed(0)}% used</span>
              <span className={creditPercentage > 80 ? 'text-orange-600' : ''}>
                ${service.creditLimit - service.credits} remaining
              </span>
            </div>
          </div>
        )}

        {/* Tokens Section */}
        {service.tokens !== undefined && service.tokenLimit !== undefined && (
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-1">
                <Brain className="h-4 w-4 text-muted-foreground" />
                <span className="font-medium">Tokens</span>
              </div>
              <span className="text-muted-foreground">
                {formatNumber(service.tokens)} / {formatNumber(service.tokenLimit)}
              </span>
            </div>
            <Progress 
              value={tokenPercentage} 
              className="h-2"
            />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>{tokenPercentage.toFixed(0)}% used</span>
              <span className={tokenPercentage > 80 ? 'text-orange-600' : ''}>
                {formatNumber(service.tokenLimit - service.tokens)} remaining
              </span>
            </div>
          </div>
        )}

        {/* Pricing Info */}
        <div className="grid grid-cols-2 gap-4 text-sm">
          {service.pricePer1kTokens !== undefined && (
            <div className="flex items-center gap-1">
              <TrendingUp className="h-3 w-3 text-muted-foreground" />
              <span className="text-muted-foreground">Price:</span>
              <span className="font-medium">${service.pricePer1kTokens}/1k</span>
            </div>
          )}
          {service.monthlyCost !== undefined && (
            <div className="flex items-center gap-1">
              <Calendar className="h-3 w-3 text-muted-foreground" />
              <span className="text-muted-foreground">Monthly:</span>
              <span className="font-medium">${service.monthlyCost}</span>
            </div>
          )}
        </div>

        {/* Renewal Info */}
        {service.renewalDate && daysUntilRenewal !== null && (
          <div className="pt-2 border-t">
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-1">
                <Calendar className="h-4 w-4 text-muted-foreground" />
                <span className="font-medium">Renewal</span>
              </div>
              <div className="text-right">
                <span className={`font-medium ${
                  daysUntilRenewal <= 3 ? 'text-red-600' : 
                  daysUntilRenewal <= 7 ? 'text-orange-600' : 
                  'text-muted-foreground'
                }`}>
                  {daysUntilRenewal > 0 ? `${daysUntilRenewal} days` : 'Today'}
                </span>
                <p className="text-xs text-muted-foreground">
                  {new Date(service.renewalDate).toLocaleDateString()}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            className="flex-1"
            onClick={() => window.open('#', '_blank')}
          >
            <ExternalLink className="mr-2 h-4 w-4" />
            View Details
          </Button>
          <Button 
            variant="outline"
            onClick={onSync}
            disabled={isSyncing}
            className="flex-1"
          >
            {isSyncing ? (
              <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <RefreshCw className="mr-2 h-4 w-4" />
            )}
            Sync
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}