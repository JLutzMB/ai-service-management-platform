"use client"

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Bell, X, ExternalLink, AlertTriangle, Info, CheckCircle } from "lucide-react"
import { useRealTime } from "@/hooks/use-real-time"
import { toast } from "sonner"

interface Notification {
  id: string
  type: 'info' | 'warning' | 'error' | 'success'
  title: string
  message: string
  isRead: boolean
  createdAt: string
  serviceId?: string
  serviceName?: string
  metadata?: any
}

interface RealTimeNotificationsProps {
  userId: string
  onNotificationClick?: (notification: Notification) => void
}

export function RealTimeNotifications({ userId, onNotificationClick }: RealTimeNotificationsProps) {
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [unreadCount, setUnreadCount] = useState(0)
  const [isOpen, setIsOpen] = useState(false)

  const handleNotification = (notification: any) => {
    const newNotification: Notification = {
      id: notification.id || `notification-${Date.now()}`,
      type: notification.type,
      title: notification.title,
      message: notification.message,
      isRead: false,
      createdAt: notification.timestamp || new Date().toISOString(),
      serviceId: notification.serviceId,
      serviceName: notification.serviceName,
      metadata: notification.metadata
    }

    setNotifications(prev => [newNotification, ...prev.slice(0, 49)]) // Keep last 50
    setUnreadCount(prev => prev + 1)

    // Show toast notification for real-time alerts
    if (notification.type === 'error' || notification.type === 'warning') {
      toast.error(notification.title, {
        description: notification.message,
        action: {
          label: "View",
          onClick: () => handleNotificationClick(newNotification)
        }
      })
    } else {
      toast.success(notification.title, {
        description: notification.message,
        action: {
          label: "View",
          onClick: () => handleNotificationClick(newNotification)
        }
      })
    }
  }

  const handleSyncUpdate = (data: any) => {
    // Handle sync updates that might generate notifications
    if (data.data?.usage?.percentage > 90) {
      handleNotification({
        type: 'error',
        title: 'High Usage Alert',
        message: `${data.serviceId} usage is critical`,
        serviceId: data.serviceId,
        metadata: { type: 'usage_threshold', percentage: data.data.usage.percentage }
      })
    }
  }

  const handleUsageAlert = (data: any) => {
    handleNotification({
      type: data.severity || 'warning',
      title: data.title || 'Usage Alert',
      message: data.message || 'Unusual usage pattern detected',
      serviceId: data.serviceId,
      metadata: data.metadata
    })
  }

  const handleServiceStatus = (data: any) => {
    handleNotification({
      type: data.status === 'error' ? 'error' : 'info',
      title: `Service Status: ${data.serviceId}`,
      message: `Service status changed to ${data.status}`,
      serviceId: data.serviceId,
      metadata: { type: 'service_status', status: data.status }
    })
  }

  useRealTime({
    userId,
    enabled: true,
    onNotification: handleNotification,
    onSyncUpdate: handleSyncUpdate,
    onUsageAlert: handleUsageAlert,
    onServiceStatus: handleServiceStatus
  })

  const handleNotificationClick = (notification: Notification) => {
    // Mark as read
    setNotifications(prev => 
      prev.map(n => n.id === notification.id ? { ...n, isRead: true } : n)
    )
    setUnreadCount(prev => Math.max(0, prev - 1))
    
    onNotificationClick?.(notification)
    setIsOpen(false)
  }

  const markAllAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, isRead: true })))
    setUnreadCount(0)
  }

  const clearAll = () => {
    setNotifications([])
    setUnreadCount(0)
  }

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'error':
        return <AlertTriangle className="h-4 w-4 text-red-500" />
      case 'warning':
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />
      case 'success':
        return <CheckCircle className="h-4 w-4 text-green-500" />
      default:
        return <Info className="h-4 w-4 text-blue-500" />
    }
  }

  const getNotificationVariant = (type: string) => {
    switch (type) {
      case 'error':
        return 'destructive'
      case 'warning':
        return 'default'
      case 'success':
        return 'default'
      default:
        return 'secondary'
    }
  }

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffMs = now.getTime() - date.getTime()
    const diffMinutes = Math.floor(diffMs / (1000 * 60))
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60))
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24))

    if (diffMinutes < 1) return 'Just now'
    if (diffMinutes < 60) return `${diffMinutes}m ago`
    if (diffHours < 24) return `${diffHours}h ago`
    return `${diffDays}d ago`
  }

  return (
    <div className="relative">
      {/* Notification Bell */}
      <Button
        variant="ghost"
        size="sm"
        onClick={() => setIsOpen(!isOpen)}
        className="relative"
      >
        <Bell className="h-4 w-4" />
        {unreadCount > 0 && (
          <Badge
            variant="destructive"
            className="absolute -top-2 -right-2 h-5 w-5 flex items-center justify-center p-0 text-xs"
          >
            {unreadCount > 99 ? '99+' : unreadCount}
          </Badge>
        )}
      </Button>

      {/* Notification Panel */}
      {isOpen && (
        <Card className="absolute right-0 top-full mt-2 w-80 z-50 shadow-lg">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm">Notifications</CardTitle>
              <div className="flex items-center gap-1">
                {unreadCount > 0 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={markAllAsRead}
                    className="text-xs h-6"
                  >
                    Mark all read
                  </Button>
                )}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={clearAll}
                  className="text-xs h-6"
                >
                  Clear
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsOpen(false)}
                  className="h-6 w-6 p-0"
                >
                  <X className="h-3 w-3" />
                </Button>
              </div>
            </div>
            <CardDescription className="text-xs">
              Real-time updates and alerts
            </CardDescription>
          </CardHeader>

          <CardContent className="p-0">
            <ScrollArea className="h-96">
              {notifications.length === 0 ? (
                <div className="p-4 text-center text-muted-foreground">
                  <Bell className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">No notifications</p>
                </div>
              ) : (
                <div className="space-y-1">
                  {notifications.map((notification) => (
                    <div
                      key={notification.id}
                      className={`p-3 hover:bg-muted cursor-pointer transition-colors ${
                        !notification.isRead ? 'bg-muted/50' : ''
                      }`}
                      onClick={() => handleNotificationClick(notification)}
                    >
                      <div className="flex items-start gap-3">
                        {getNotificationIcon(notification.type)}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <h4 className="text-sm font-medium truncate">
                              {notification.title}
                            </h4>
                            {!notification.isRead && (
                              <div className="h-2 w-2 bg-blue-500 rounded-full" />
                            )}
                          </div>
                          <p className="text-xs text-muted-foreground mb-1 line-clamp-2">
                            {notification.message}
                          </p>
                          <div className="flex items-center justify-between">
                            <span className="text-xs text-muted-foreground">
                              {formatTimeAgo(notification.createdAt)}
                            </span>
                            {notification.serviceName && (
                              <Badge variant="outline" className="text-xs">
                                {notification.serviceName}
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </ScrollArea>
          </CardContent>
        </Card>
      )}
    </div>
  )
}