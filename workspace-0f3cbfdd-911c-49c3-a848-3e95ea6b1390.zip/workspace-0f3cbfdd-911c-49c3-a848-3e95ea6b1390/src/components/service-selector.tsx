'use client';

import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Search, Plus, ExternalLink, Star, Zap } from 'lucide-react';
import { 
  AI_SERVICES_DIRECTORY, 
  AIServiceConfig, 
  getAIServicesByCategory, 
  searchAIServices, 
  getPopularAIServices,
  getAIServicesWithFreeTier
} from '@/lib/ai-services-directory';

interface ServiceSelectorProps {
  onServiceSelect: (service: AIServiceConfig) => void;
  children: React.ReactNode;
}

export function ServiceSelector({ onServiceSelect, children }: ServiceSelectorProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [filteredServices, setFilteredServices] = useState<AIServiceConfig[]>(AI_SERVICES_DIRECTORY);

  const categories = [
    { id: 'all', name: 'All Services', count: AI_SERVICES_DIRECTORY.length },
    { id: 'text', name: 'Text & Chat', count: getAIServicesByCategory('text').length },
    { id: 'image', name: 'Image Generation', count: getAIServicesByCategory('image').length },
    { id: 'audio', name: 'Audio & Music', count: getAIServicesByCategory('audio').length },
    { id: 'video', name: 'Video Generation', count: getAIServicesByCategory('video').length },
    { id: 'code', name: 'Code & Development', count: getAIServicesByCategory('code').length },
    { id: 'multimodal', name: 'Multimodal', count: getAIServicesByCategory('multimodal').length },
  ];

  useEffect(() => {
    let services = AI_SERVICES_DIRECTORY;

    // Filter by category
    if (selectedCategory !== 'all') {
      services = getAIServicesByCategory(selectedCategory);
    }

    // Filter by search query
    if (searchQuery.trim()) {
      services = searchAIServices(searchQuery);
    }

    setFilteredServices(services);
  }, [searchQuery, selectedCategory]);

  const handleServiceClick = (service: AIServiceConfig) => {
    onServiceSelect(service);
  };

  const ServiceCard = ({ service }: { service: AIServiceConfig }) => (
    <div
      className="p-4 border rounded-lg hover:bg-gray-50 cursor-pointer transition-colors"
      onClick={() => handleServiceClick(service)}
    >
      <div className="flex items-start space-x-3">
        <img
          src={service.logo}
          alt={service.name}
          className="w-12 h-12 rounded-lg object-cover"
          onError={(e) => {
            const target = e.target as HTMLImageElement;
            target.src = 'https://via.placeholder.com/48x48?text=AI';
          }}
        />
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-sm truncate">{service.name}</h3>
            <div className="flex items-center space-x-1">
              {service.hasFreeTier && (
                <Badge variant="secondary" className="text-xs">
                  <Zap className="w-3 h-3 mr-1" />
                  Free
                </Badge>
              )}
              <div className="flex items-center">
                <Star className="w-3 h-3 text-yellow-500 fill-current" />
                <span className="text-xs text-gray-500 ml-1">{service.popularity}</span>
              </div>
            </div>
          </div>
          <p className="text-xs text-gray-600 mt-1 line-clamp-2">{service.description}</p>
          <div className="flex items-center justify-between mt-2">
            <div className="flex flex-wrap gap-1">
              {service.features.slice(0, 2).map((feature, index) => (
                <Badge key={index} variant="outline" className="text-xs">
                  {feature}
                </Badge>
              ))}
              {service.features.length > 2 && (
                <Badge variant="outline" className="text-xs">
                  +{service.features.length - 2}
                </Badge>
              )}
            </div>
            <Badge variant="secondary" className="text-xs">
              {service.pricing}
            </Badge>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <Dialog>
      <DialogTrigger asChild>
        {children}
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[80vh]">
        <DialogHeader>
          <DialogTitle>Add AI Service</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Search AI services..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>

          {/* Category Tabs */}
          <Tabs value={selectedCategory} onValueChange={setSelectedCategory}>
            <TabsList className="grid w-full grid-cols-7">
              {categories.map((category) => (
                <TabsTrigger
                  key={category.id}
                  value={category.id}
                  className="text-xs"
                >
                  {category.name}
                  <Badge variant="secondary" className="ml-1 text-xs">
                    {category.count}
                  </Badge>
                </TabsTrigger>
              ))}
            </TabsList>

            <TabsContent value={selectedCategory} className="mt-4">
              <ScrollArea className="h-[50vh]">
                {filteredServices.length === 0 ? (
                  <div className="text-center py-8">
                    <p className="text-gray-500">No services found matching your search.</p>
                  </div>
                ) : (
                  <div className="grid gap-3">
                    {filteredServices.map((service) => (
                      <ServiceCard key={service.id} service={service} />
                    ))}
                  </div>
                )}
              </ScrollArea>
            </TabsContent>
          </Tabs>

          {/* Popular Services Section */}
          {searchQuery === '' && selectedCategory === 'all' && (
            <div className="space-y-3">
              <h3 className="font-semibold text-sm">Popular Services</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {getPopularAIServices(4).map((service) => (
                  <ServiceCard key={service.id} service={service} />
                ))}
              </div>
            </div>
          )}

          {/* Free Tier Services Section */}
          {searchQuery === '' && selectedCategory === 'all' && (
            <div className="space-y-3">
              <h3 className="font-semibold text-sm">Services with Free Tier</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {getAIServicesWithFreeTier().slice(0, 4).map((service) => (
                  <ServiceCard key={service.id} service={service} />
                ))}
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}