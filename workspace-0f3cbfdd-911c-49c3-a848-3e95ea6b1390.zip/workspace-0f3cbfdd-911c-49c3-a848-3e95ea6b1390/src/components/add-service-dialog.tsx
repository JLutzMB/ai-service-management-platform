"use client"

import { useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Brain, Plus, X } from "lucide-react"

interface AIService {
  id: string
  name: string
  provider: string
  isActive: boolean
  credits?: number
  tokens?: number
  creditLimit?: number
  tokenLimit?: number
  planType?: string
  renewalDate?: string
  pricePer1kTokens?: number
  monthlyCost?: number
  currency?: string
}

interface AddServiceDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onAddService: (service: AIService) => void
}

const providers = [
  { value: "OpenAI", name: "OpenAI", models: ["GPT-4", "GPT-3.5", "DALL-E 3", "Whisper"] },
  { value: "Anthropic", name: "Anthropic", models: ["Claude 3 Opus", "Claude 3 Sonnet", "Claude 3 Haiku"] },
  { value: "Google", name: "Google", models: ["Gemini Pro", "Gemini Ultra", "PaLM 2"] },
  { value: "Microsoft", name: "Microsoft", models: ["Azure OpenAI", "Copilot", "Bing AI"] },
  { value: "Meta", name: "Meta", models: ["Llama 2", "Code Llama"] },
  { value: "Cohere", name: "Cohere", models: ["Command", "Embed", "Generate"] },
  { value: "Hugging Face", name: "Hugging Face", models: ["Various Open Source Models"] },
]

const planTypes = [
  { value: "Free", description: "Limited usage, no cost" },
  { value: "Pro", description: "Enhanced features, monthly subscription" },
  { value: "Enterprise", description: "Full access, custom pricing" },
  { value: "Pay-as-you-go", description: "Pay only for what you use" },
]

export function AddServiceDialog({ open, onOpenChange, onAddService }: AddServiceDialogProps) {
  const [selectedProvider, setSelectedProvider] = useState("")
  const [selectedModel, setSelectedModel] = useState("")
  const [serviceName, setServiceName] = useState("")
  const [planType, setPlanType] = useState("")
  const [apiKey, setApiKey] = useState("")
  const [baseUrl, setBaseUrl] = useState("")
  const [credits, setCredits] = useState("")
  const [creditLimit, setCreditLimit] = useState("")
  const [tokens, setTokens] = useState("")
  const [tokenLimit, setTokenLimit] = useState("")
  const [pricePer1kTokens, setPricePer1kTokens] = useState("")
  const [monthlyCost, setMonthlyCost] = useState("")
  const [renewalDate, setRenewalDate] = useState("")

  const selectedProviderData = providers.find(p => p.value === selectedProvider)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    const newService: AIService = {
      id: Date.now().toString(),
      name: serviceName || `${selectedProvider} ${selectedModel}`,
      provider: selectedProvider,
      isActive: true,
      credits: credits ? parseFloat(credits) : undefined,
      creditLimit: creditLimit ? parseFloat(creditLimit) : undefined,
      tokens: tokens ? parseFloat(tokens) : undefined,
      tokenLimit: tokenLimit ? parseFloat(tokenLimit) : undefined,
      planType: planType || undefined,
      pricePer1kTokens: pricePer1kTokens ? parseFloat(pricePer1kTokens) : undefined,
      monthlyCost: monthlyCost ? parseFloat(monthlyCost) : undefined,
      renewalDate: renewalDate || undefined,
      currency: "USD"
    }

    onAddService(newService)
    resetForm()
    onOpenChange(false)
  }

  const resetForm = () => {
    setSelectedProvider("")
    setSelectedModel("")
    setServiceName("")
    setPlanType("")
    setApiKey("")
    setBaseUrl("")
    setCredits("")
    setCreditLimit("")
    setTokens("")
    setTokenLimit("")
    setPricePer1kTokens("")
    setMonthlyCost("")
    setRenewalDate("")
  }

  const handleClose = () => {
    resetForm()
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5" />
            Add AI Service
          </DialogTitle>
          <DialogDescription>
            Connect a new AI service to monitor its usage, credits, and billing information.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Provider Selection */}
          <div className="space-y-3">
            <Label htmlFor="provider">Service Provider</Label>
            <Select value={selectedProvider} onValueChange={setSelectedProvider}>
              <SelectTrigger>
                <SelectValue placeholder="Select a provider" />
              </SelectTrigger>
              <SelectContent>
                {providers.map((provider) => (
                  <SelectItem key={provider.value} value={provider.value}>
                    {provider.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Model Selection */}
          {selectedProviderData && (
            <div className="space-y-3">
              <Label htmlFor="model">Model/Service</Label>
              <Select value={selectedModel} onValueChange={setSelectedModel}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a model" />
                </SelectTrigger>
                <SelectContent>
                  {selectedProviderData.models.map((model) => (
                    <SelectItem key={model} value={model}>
                      {model}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          <Separator />

          {/* Basic Information */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-3">
              <Label htmlFor="serviceName">Service Name (Optional)</Label>
              <Input
                id="serviceName"
                placeholder="Custom name for this service"
                value={serviceName}
                onChange={(e) => setServiceName(e.target.value)}
              />
            </div>

            <div className="space-y-3">
              <Label htmlFor="planType">Plan Type</Label>
              <Select value={planType} onValueChange={setPlanType}>
                <SelectTrigger>
                  <SelectValue placeholder="Select plan type" />
                </SelectTrigger>
                <SelectContent>
                  {planTypes.map((plan) => (
                    <SelectItem key={plan.value} value={plan.value}>
                      <div>
                        <div className="font-medium">{plan.value}</div>
                        <div className="text-xs text-muted-foreground">{plan.description}</div>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* API Configuration */}
          <div className="space-y-3">
            <Label>API Configuration</Label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="apiKey" className="text-sm">API Key</Label>
                <Input
                  id="apiKey"
                  type="password"
                  placeholder="Enter your API key"
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="baseUrl" className="text-sm">Base URL (Optional)</Label>
                <Input
                  id="baseUrl"
                  placeholder="Custom API endpoint"
                  value={baseUrl}
                  onChange={(e) => setBaseUrl(e.target.value)}
                />
              </div>
            </div>
          </div>

          <Separator />

          {/* Credits and Tokens */}
          <div className="space-y-3">
            <Label>Usage Limits</Label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="credits" className="text-sm">Available Credits ($)</Label>
                <Input
                  id="credits"
                  type="number"
                  step="0.01"
                  placeholder="0.00"
                  value={credits}
                  onChange={(e) => setCredits(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="creditLimit" className="text-sm">Credit Limit ($)</Label>
                <Input
                  id="creditLimit"
                  type="number"
                  step="0.01"
                  placeholder="0.00"
                  value={creditLimit}
                  onChange={(e) => setCreditLimit(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="tokens" className="text-sm">Available Tokens</Label>
                <Input
                  id="tokens"
                  type="number"
                  placeholder="0"
                  value={tokens}
                  onChange={(e) => setTokens(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="tokenLimit" className="text-sm">Token Limit</Label>
                <Input
                  id="tokenLimit"
                  type="number"
                  placeholder="0"
                  value={tokenLimit}
                  onChange={(e) => setTokenLimit(e.target.value)}
                />
              </div>
            </div>
          </div>

          {/* Pricing Information */}
          <div className="space-y-3">
            <Label>Pricing Information</Label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="pricePer1kTokens" className="text-sm">Price per 1K Tokens ($)</Label>
                <Input
                  id="pricePer1kTokens"
                  type="number"
                  step="0.001"
                  placeholder="0.000"
                  value={pricePer1kTokens}
                  onChange={(e) => setPricePer1kTokens(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="monthlyCost" className="text-sm">Monthly Cost ($)</Label>
                <Input
                  id="monthlyCost"
                  type="number"
                  step="0.01"
                  placeholder="0.00"
                  value={monthlyCost}
                  onChange={(e) => setMonthlyCost(e.target.value)}
                />
              </div>
            </div>
          </div>

          {/* Renewal Date */}
          <div className="space-y-3">
            <Label htmlFor="renewalDate">Renewal Date (Optional)</Label>
            <Input
              id="renewalDate"
              type="date"
              value={renewalDate}
              onChange={(e) => setRenewalDate(e.target.value)}
            />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={handleClose}>
              Cancel
            </Button>
            <Button 
              type="submit" 
              disabled={!selectedProvider || !selectedModel}
            >
              <Plus className="mr-2 h-4 w-4" />
              Add Service
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}