"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { 
  Crown, 
  Zap, 
  Users, 
  Check, 
  X, 
  Star,
  CreditCard,
  AlertCircle,
  TrendingUp
} from "lucide-react"
import { toast } from "sonner"

interface SubscriptionTier {
  id: string
  name: string
  price: {
    monthly: number
    yearly: number
  }
  features: string[]
  description: string
  popular?: boolean
  serviceLimit: number
}

interface UserSubscription {
  tier: string
  status: string
  expiresAt?: string
  isActive: boolean
}

interface SubscriptionLimits {
  serviceLimit: number
  canAddService: boolean
}

export function SubscriptionManager() {
  const [subscription, setSubscription] = useState<UserSubscription | null>(null)
  const [limits, setLimits] = useState<SubscriptionLimits | null>(null)
  const [loading, setLoading] = useState(true)
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('yearly')
  const [userId] = useState("cmdypf4pf0006shrbkmv1mk8i") // Test user ID from database

  const subscriptionTiers: SubscriptionTier[] = [
    {
      id: "free",
      name: "Free",
      price: { monthly: 0, yearly: 0 },
      features: [
        "Connect up to 2 AI services",
        "Basic usage tracking",
        "Manual sync only",
        "Email notifications",
        "Basic analytics"
      ],
      description: "Perfect for individuals managing a few AI services",
      serviceLimit: 2
    },
    {
      id: "pro",
      name: "Pro",
      price: { monthly: 6.99, yearly: 4.99 },
      features: [
        "Unlimited AI service connections",
        "Real-time sync",
        "Advanced analytics & insights",
        "Cost optimization recommendations",
        "Priority support",
        "Custom notification rules",
        "API access"
      ],
      description: "For power users and professionals",
      serviceLimit: Infinity,
      popular: true
    }
  ]

  useEffect(() => {
    fetchSubscription()
  }, [userId])

  const fetchSubscription = async () => {
    try {
      const response = await fetch(`/api/subscription?userId=${userId}`)
      if (!response.ok) throw new Error('Failed to fetch subscription')
      
      const data = await response.json()
      setSubscription(data.subscription)
      setLimits(data.limits)
    } catch (error) {
      console.error('Error fetching subscription:', error)
      toast.error('Failed to fetch subscription information')
    } finally {
      setLoading(false)
    }
  }

  const handleUpgrade = async (tierId: string) => {
    try {
      const response = await fetch('/api/subscription', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          userId,
          action: 'upgrade',
          tier: tierId,
          billingCycle
        })
      })

      if (!response.ok) throw new Error('Failed to upgrade subscription')
      
      const data = await response.json()
      toast.success(data.message)
      fetchSubscription() // Refresh subscription data
    } catch (error) {
      console.error('Error upgrading subscription:', error)
      toast.error('Failed to upgrade subscription')
    }
  }

  const handleCancelSubscription = async () => {
    try {
      const response = await fetch('/api/subscription', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          userId,
          action: 'cancel'
        })
      })

      if (!response.ok) throw new Error('Failed to cancel subscription')
      
      const data = await response.json()
      toast.success(data.message)
      fetchSubscription() // Refresh subscription data
    } catch (error) {
      console.error('Error cancelling subscription:', error)
      toast.error('Failed to cancel subscription')
    }
  }

  const getCurrentTier = () => {
    return subscriptionTiers.find(tier => tier.id === subscription?.tier) || subscriptionTiers[0]
  }

  const getUpgradeTiers = () => {
    if (!subscription) return subscriptionTiers
    
    const currentIndex = subscriptionTiers.findIndex(tier => tier.id === subscription.tier)
    return subscriptionTiers.slice(currentIndex + 1)
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    )
  }

  const currentTier = getCurrentTier()
  const upgradeTiers = getUpgradeTiers()

  return (
    <div className="space-y-6">
      {/* Current Subscription Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Crown className="h-5 w-5" />
            Current Subscription
          </CardTitle>
          <CardDescription>
            Manage your subscription and view usage limits
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-semibold">{currentTier.name}</h3>
                <Badge variant={subscription?.isActive ? "default" : "secondary"}>
                  {subscription?.status}
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground mt-1">
                {currentTier.description}
              </p>
              {limits && (
                <div className="mt-2 text-sm">
                  <span className="font-medium">Service Limit:</span> {limits.serviceLimit === Infinity ? "Unlimited" : limits.serviceLimit}
                </div>
              )}
            </div>
            
            {subscription?.tier !== 'free' && subscription?.isActive && (
              <Button 
                variant="outline" 
                onClick={handleCancelSubscription}
                className="text-red-600 border-red-600 hover:bg-red-50"
              >
                Cancel Subscription
              </Button>
            )}
          </div>
          
          {!limits?.canAddService && (
            <Alert className="mt-4">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                You've reached your service limit. Upgrade to Pro to connect more AI services.
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Billing Cycle Toggle */}
      <div className="flex items-center justify-center">
        <div className="flex items-center gap-2 bg-muted p-1 rounded-lg">
          <Button
            variant={billingCycle === 'monthly' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setBillingCycle('monthly')}
          >
            Monthly
          </Button>
          <Button
            variant={billingCycle === 'yearly' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setBillingCycle('yearly')}
          >
            Yearly <span className="ml-1 text-green-600">-28%</span>
          </Button>
        </div>
      </div>

      {/* Subscription Plans */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {subscriptionTiers.map((tier) => {
          const isCurrent = subscription?.tier === tier.id
          const canUpgrade = upgradeTiers.some(upgradeTier => upgradeTier.id === tier.id)
          
          return (
            <Card 
              key={tier.id} 
              className={`relative ${tier.popular ? 'ring-2 ring-primary' : ''}`}
            >
              {tier.popular && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-primary text-primary-foreground">
                    <Star className="h-3 w-3 mr-1" />
                    Most Popular
                  </Badge>
                </div>
              )}
              
              <CardHeader className="text-center">
                <CardTitle className="flex items-center justify-center gap-2">
                  {tier.id === 'free' && <Users className="h-5 w-5" />}
                  {tier.id === 'pro' && <Zap className="h-5 w-5" />}
                  {tier.id === 'enterprise' && <Crown className="h-5 w-5" />}
                  {tier.name}
                </CardTitle>
                <div className="text-3xl font-bold">
                  ${billingCycle === 'monthly' ? tier.price.monthly : tier.price.yearly}
                  <span className="text-sm font-normal text-muted-foreground">
                    /{billingCycle === 'monthly' ? 'month' : 'year'}
                  </span>
                </div>
                <CardDescription>{tier.description}</CardDescription>
              </CardHeader>
              
              <CardContent>
                <ul className="space-y-2 mb-6">
                  {tier.features.map((feature, index) => (
                    <li key={index} className="flex items-center gap-2 text-sm">
                      <Check className="h-4 w-4 text-green-600" />
                      {feature}
                    </li>
                  ))}
                </ul>
                
                <Button 
                  className="w-full" 
                  variant={isCurrent ? "outline" : "default"}
                  disabled={!canUpgrade && !isCurrent}
                  onClick={() => !isCurrent && handleUpgrade(tier.id)}
                >
                  {isCurrent ? (
                    <>
                      <Check className="h-4 w-4 mr-2" />
                      Current Plan
                    </>
                  ) : canUpgrade ? (
                    <>
                      <CreditCard className="h-4 w-4 mr-2" />
                      Upgrade to {tier.name}
                    </>
                  ) : (
                    'Upgrade Required'
                  )}
                </Button>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Value Proposition */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Why Upgrade to Pro?
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h4 className="font-semibold mb-2">Cost Savings</h4>
              <p className="text-sm text-muted-foreground">
                Our AI-powered cost optimization can save you up to 30% on your AI service expenses.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-2">Time Efficiency</h4>
              <p className="text-sm text-muted-foreground">
                Real-time sync and automated insights save hours of manual monitoring each month.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-2">Unlimited Potential</h4>
              <p className="text-sm text-muted-foreground">
                Connect as many AI services as you need without limitations.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-2">Priority Support</h4>
              <p className="text-sm text-muted-foreground">
                Get help when you need it with our priority customer support.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}