"use client"

import { useEffect, useRef, useState } from 'react'
import { io, Socket } from 'socket.io-client'

interface RealTimeEvent {
  event: string
  data: any
  timestamp: string
}

interface UseRealTimeOptions {
  userId?: string
  enabled?: boolean
  onNotification?: (notification: any) => void
  onSyncUpdate?: (data: any) => void
  onInsightUpdate?: (data: any) => void
  onUsageAlert?: (data: any) => void
  onServiceStatus?: (data: any) => void
  onUsageUpdate?: (data: any) => void
}

export function useRealTime(options: UseRealTimeOptions = {}) {
  const {
    userId,
    enabled = true,
    onNotification,
    onSyncUpdate,
    onInsightUpdate,
    onUsageAlert,
    onServiceStatus,
    onUsageUpdate
  } = options

  const [isConnected, setIsConnected] = useState(false)
  const [connectionError, setConnectionError] = useState<string | null>(null)
  const socketRef = useRef<Socket | null>(null)
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  const reconnectAttempts = useRef(0)
  const maxReconnectAttempts = 5

  // Initialize socket connection
  useEffect(() => {
    if (!enabled || !userId) return

    const connectSocket = () => {
      try {
        const socket = io(process.env.NODE_ENV === 'production' ? '' : 'http://localhost:3000', {
          transports: ['websocket', 'polling'],
          timeout: 10000,
          reconnection: true,
          reconnectionAttempts: maxReconnectAttempts,
          reconnectionDelay: 1000,
          reconnectionDelayMax: 5000,
        })

        socketRef.current = socket

        // Connection events
        socket.on('connect', () => {
          console.log('Socket connected:', socket.id)
          setIsConnected(true)
          setConnectionError(null)
          reconnectAttempts.current = 0

          // Authenticate user
          socket.emit('authenticate', { userId })
        })

        socket.on('authenticated', (data) => {
          console.log('Socket authenticated:', data)
        })

        socket.on('disconnect', (reason) => {
          console.log('Socket disconnected:', reason)
          setIsConnected(false)
          
          // Attempt to reconnect if not manually disconnected
          if (reason !== 'io client disconnect' && reconnectAttempts.current < maxReconnectAttempts) {
            reconnectAttempts.current++
            const delay = Math.min(1000 * Math.pow(2, reconnectAttempts.current), 5000)
            
            console.log(`Attempting to reconnect in ${delay}ms... (attempt ${reconnectAttempts.current}/${maxReconnectAttempts})`)
            
            reconnectTimeoutRef.current = setTimeout(() => {
              connectSocket()
            }, delay)
          } else if (reconnectAttempts.current >= maxReconnectAttempts) {
            setConnectionError('Failed to establish connection after multiple attempts')
          }
        })

        socket.on('connect_error', (error) => {
          console.error('Socket connection error:', error)
          setConnectionError(error.message)
          setIsConnected(false)
        })

        // Real-time event handlers
        socket.on('notification', (data) => {
          console.log('Received notification:', data)
          onNotification?.(data)
        })

        socket.on('sync_update', (data) => {
          console.log('Received sync update:', data)
          onSyncUpdate?.(data)
        })

        socket.on('insight_update', (data) => {
          console.log('Received insight update:', data)
          onInsightUpdate?.(data)
        })

        socket.on('usage_alert', (data) => {
          console.log('Received usage alert:', data)
          onUsageAlert?.(data)
        })

        socket.on('service_status', (data) => {
          console.log('Received service status:', data)
          onServiceStatus?.(data)
        })

        socket.on('usage_update', (data) => {
          console.log('Received usage update:', data)
          onUsageUpdate?.(data)
        })

        // System messages
        socket.on('message', (data) => {
          console.log('Received system message:', data)
        })

      } catch (error) {
        console.error('Error creating socket connection:', error)
        setConnectionError('Failed to create socket connection')
      }
    }

    connectSocket()

    // Cleanup function
    return () => {
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current)
      }
      
      if (socketRef.current) {
        socketRef.current.disconnect()
        socketRef.current = null
      }
      
      setIsConnected(false)
    }
  }, [enabled, userId, onNotification, onSyncUpdate, onInsightUpdate, onUsageAlert, onServiceStatus, onUsageUpdate])

  // Manual reconnection
  const reconnect = () => {
    if (socketRef.current) {
      socketRef.current.disconnect()
    }
    reconnectAttempts.current = 0
    setConnectionError(null)
    
    if (enabled && userId) {
      const socket = io(process.env.NODE_ENV === 'production' ? '' : 'http://localhost:3000', {
        transports: ['websocket', 'polling'],
        timeout: 10000,
        reconnection: true,
        reconnectionAttempts: maxReconnectAttempts,
        reconnectionDelay: 1000,
        reconnectionDelayMax: 5000,
      })
      
      socketRef.current = socket
    }
  }

  // Send events
  const sendEvent = (event: string, data: any) => {
    if (socketRef.current && isConnected) {
      socketRef.current.emit(event, data)
    } else {
      console.warn('Cannot send event - socket not connected')
    }
  }

  // Send sync update
  const sendSyncUpdate = (serviceId: string, data: any) => {
    sendEvent('sync_update', { userId, serviceId, data })
  }

  // Send notification
  const sendNotification = (notification: any) => {
    sendEvent('notification', { userId, notification })
  }

  // Send insight update
  const sendInsightUpdate = (insight: any) => {
    sendEvent('insight_update', { userId, insight })
  }

  // Send service status
  const sendServiceStatus = (serviceId: string, status: string) => {
    sendEvent('service_status', { userId, serviceId, status })
  }

  // Send usage alert
  const sendUsageAlert = (serviceId: string, alert: any) => {
    sendEvent('usage_alert', { userId, serviceId, alert })
  }

  // Send usage update
  const sendUsageUpdate = (serviceId: string, usage: any) => {
    sendEvent('usage_update', { userId, serviceId, usage })
  }

  return {
    isConnected,
    connectionError,
    reconnect,
    sendEvent,
    sendSyncUpdate,
    sendNotification,
    sendInsightUpdate,
    sendServiceStatus,
    sendUsageAlert,
    sendUsageUpdate,
  }
}