import { db } from '@/lib/db'
import { SyncService } from './sync-service'

export interface Notification {
  id: string
  type: 'info' | 'warning' | 'error' | 'success'
  title: string
  message: string
  userId: string
  serviceId?: string
  isRead: boolean
  createdAt: Date
  metadata?: any
}

export interface NotificationRule {
  id: string
  name: string
  type: 'usage_threshold' | 'renewal_reminder' | 'cost_alert' | 'connection_error'
  conditions: any
  actions: string
  isActive: boolean
  userId: string
}

export class NotificationService {
  private static instance: NotificationService
  private checkIntervals: Map<string, NodeJS.Timeout> = new Map()

  static getInstance(): NotificationService {
    if (!NotificationService.instance) {
      NotificationService.instance = new NotificationService()
    }
    return NotificationService.instance
  }

  async createNotification(data: Omit<Notification, 'id' | 'createdAt' | 'isRead'>): Promise<Notification> {
    const notification = await db.notification.create({
      data: {
        ...data,
        isRead: false,
        createdAt: new Date()
      }
    })

    // Send real-time notification via WebSocket if available
    this.sendRealTimeNotification(notification)

    return notification
  }

  async getNotifications(userId: string, unreadOnly: boolean = false): Promise<Notification[]> {
    const where: any = { userId }
    if (unreadOnly) {
      where.isRead = false
    }

    return await db.notification.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: 50
    })
  }

  async markAsRead(notificationId: string, userId: string): Promise<void> {
    await db.notification.updateMany({
      where: { 
        id: notificationId,
        userId
      },
      data: { isRead: true }
    })
  }

  async markAllAsRead(userId: string): Promise<void> {
    await db.notification.updateMany({
      where: { userId },
      data: { isRead: true }
    })
  }

  async deleteNotification(notificationId: string, userId: string): Promise<void> {
    await db.notification.deleteMany({
      where: { 
        id: notificationId,
        userId
      }
    })
  }

  // Notification rules and automated checks
  async createNotificationRule(rule: Omit<NotificationRule, 'id'>): Promise<NotificationRule> {
    return await db.notificationRule.create({
      data: rule
    })
  }

  async checkAndTriggerNotifications(userId: string): Promise<void> {
    try {
      const services = await db.aIService.findMany({
        where: { userId, isActive: true }
      })

      for (const service of services) {
        await this.checkUsageThresholds(service)
        await this.checkRenewalReminders(service)
        await this.checkCostAlerts(service)
      }

    } catch (error) {
      console.error('Error checking notifications:', error)
    }
  }

  private async checkUsageThresholds(service: any): Promise<void> {
    if (!service.tokenLimit || !service.tokens) return

    const usagePercentage = (service.tokens / service.tokenLimit) * 100

    // Check different threshold levels
    if (usagePercentage >= 90) {
      await this.createNotification({
        type: 'error',
        title: 'Critical Usage Alert',
        message: `${service.name} has reached ${usagePercentage.toFixed(1)}% of its token limit.`,
        userId: service.userId,
        serviceId: service.id,
        metadata: {
          type: 'usage_threshold',
          percentage: usagePercentage,
          threshold: 90
        }
      })
    } else if (usagePercentage >= 75) {
      await this.createNotification({
        type: 'warning',
        title: 'High Usage Warning',
        message: `${service.name} has used ${usagePercentage.toFixed(1)}% of its token limit.`,
        userId: service.userId,
        serviceId: service.id,
        metadata: {
          type: 'usage_threshold',
          percentage: usagePercentage,
          threshold: 75
        }
      })
    }

    // Check credits if available
    if (service.creditLimit && service.credits) {
      const creditPercentage = (service.credits / service.creditLimit) * 100
      
      if (creditPercentage >= 90) {
        await this.createNotification({
          type: 'error',
          title: 'Low Credits Alert',
          message: `${service.name} has only ${(service.creditLimit - service.credits).toFixed(2)} credits remaining.`,
          userId: service.userId,
          serviceId: service.id,
          metadata: {
            type: 'credit_threshold',
            percentage: creditPercentage,
            remaining: service.creditLimit - service.credits
          }
        })
      }
    }
  }

  private async checkRenewalReminders(service: any): Promise<void> {
    if (!service.renewalDate) return

    const renewalDate = new Date(service.renewalDate)
    const today = new Date()
    const daysUntilRenewal = Math.ceil((renewalDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24))

    if (daysUntilRenewal <= 3) {
      await this.createNotification({
        type: 'error',
        title: 'Urgent: Service Renewal Required',
        message: `${service.name} needs renewal in ${daysUntilRenewal} day${daysUntilRenewal !== 1 ? 's' : ''}.`,
        userId: service.userId,
        serviceId: service.id,
        metadata: {
          type: 'renewal_reminder',
          daysUntilRenewal,
          renewalDate: service.renewalDate
        }
      })
    } else if (daysUntilRenewal <= 7) {
      await this.createNotification({
        type: 'warning',
        title: 'Service Renewal Reminder',
        message: `${service.name} will renew in ${daysUntilRenewal} days.`,
        userId: service.userId,
        serviceId: service.id,
        metadata: {
          type: 'renewal_reminder',
          daysUntilRenewal,
          renewalDate: service.renewalDate
        }
      })
    }
  }

  private async checkCostAlerts(service: any): Promise<void> {
    if (!service.monthlyCost) return

    // Get usage for the current month
    const startOfMonth = new Date()
    startOfMonth.setDate(1)
    startOfMonth.setHours(0, 0, 0, 0)

    const usageRecords = await db.usageRecord.findMany({
      where: {
        aiServiceId: service.id,
        date: { gte: startOfMonth }
      }
    })

    const totalCost = usageRecords.reduce((sum, record) => sum + (record.cost || 0), 0)
    
    // Alert if current usage exceeds monthly cost by 20%
    if (totalCost > service.monthlyCost * 1.2) {
      await this.createNotification({
        type: 'error',
        title: 'Cost Overrun Alert',
        message: `${service.name} has exceeded its monthly budget. Current cost: $${totalCost.toFixed(2)}`,
        userId: service.userId,
        serviceId: service.id,
        metadata: {
          type: 'cost_alert',
          currentCost: totalCost,
          monthlyBudget: service.monthlyCost,
          overagePercentage: ((totalCost - service.monthlyCost) / service.monthlyCost) * 100
        }
      })
    } else if (totalCost > service.monthlyCost * 0.8) {
      await this.createNotification({
        type: 'warning',
        title: 'High Usage Warning',
        message: `${service.name} has used 80% of its monthly budget. Current cost: $${totalCost.toFixed(2)}`,
        userId: service.userId,
        serviceId: service.id,
        metadata: {
          type: 'cost_alert',
          currentCost: totalCost,
          monthlyBudget: service.monthlyCost,
          usagePercentage: (totalCost / service.monthlyCost) * 100
        }
      })
    }
  }

  async startNotificationChecks(userId: string, intervalMinutes: number = 60): Promise<void> {
    this.stopNotificationChecks(userId)

    const intervalMs = intervalMinutes * 60 * 1000
    const interval = setInterval(async () => {
      await this.checkAndTriggerNotifications(userId)
    }, intervalMs)

    this.checkIntervals.set(userId, interval)

    // Initial check
    await this.checkAndTriggerNotifications(userId)
  }

  stopNotificationChecks(userId: string): void {
    const interval = this.checkIntervals.get(userId)
    if (interval) {
      clearInterval(interval)
      this.checkIntervals.delete(userId)
    }
  }

  private sendRealTimeNotification(notification: any): void {
    // This would integrate with WebSocket to send real-time notifications
    // For now, we'll just log it
    console.log('Real-time notification:', notification)
  }

  async getConnectionErrorNotifications(userId: string): Promise<void> {
    const services = await db.aIService.findMany({
      where: { userId, isActive: true }
    })

    const syncService = SyncService.getInstance()

    for (const service of services) {
      if (service.apiKey) {
        const connectionTest = await syncService.testServiceConnection(service.id)
        
        if (!connectionTest.success) {
          await this.createNotification({
            type: 'error',
            title: 'Connection Error',
            message: `Failed to connect to ${service.name}. Please check your API key.`,
            userId: service.userId,
            serviceId: service.id,
            metadata: {
              type: 'connection_error',
              error: connectionTest.error
            }
          })
        }
      }
    }
  }
}