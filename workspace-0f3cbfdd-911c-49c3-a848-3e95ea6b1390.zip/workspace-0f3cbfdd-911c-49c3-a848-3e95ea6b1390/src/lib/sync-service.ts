import { db } from '@/lib/db'
import { createAIProvider, type AIProviderConfig } from './ai-provider'
import { type UsageRecord } from '@prisma/client'

export interface SyncResult {
  success: boolean
  message: string
  data?: any
  error?: string
}

export class SyncService {
  private static instance: SyncService
  private syncIntervals: Map<string, NodeJS.Timeout> = new Map()

  static getInstance(): SyncService {
    if (!SyncService.instance) {
      SyncService.instance = new SyncService()
    }
    return SyncService.instance
  }

  async syncService(serviceId: string): Promise<SyncResult> {
    try {
      // Get service from database
      const service = await db.aIService.findUnique({
        where: { id: serviceId },
        include: { user: true }
      })

      if (!service) {
        return {
          success: false,
          message: 'Service not found',
          error: 'Service not found in database'
        }
      }

      if (!service.apiKey) {
        return {
          success: false,
          message: 'No API key configured',
          error: 'API key is required for synchronization'
        }
      }

      // Create provider instance
      const provider = createAIProvider(service.provider, {
        apiKey: service.apiKey,
        baseUrl: service.baseUrl || undefined,
      })

      // Test connection
      const isConnected = await provider.testConnection()
      if (!isConnected) {
        return {
          success: false,
          message: 'Connection failed',
          error: 'Unable to connect to AI provider API'
        }
      }

      // Fetch data from provider
      const [usageResult, subscriptionResult, quotaResult] = await Promise.allSettled([
        provider.fetchUsage(),
        provider.fetchSubscription(),
        provider.fetchQuota()
      ])

      // Process and update service data
      const updates: any = {}

      if (usageResult.status === 'fulfilled' && usageResult.value.usage) {
        const usage = usageResult.value.usage
        updates.tokens = usage.totalTokens
        updates.credits = usage.totalCost
      }

      if (subscriptionResult.status === 'fulfilled' && subscriptionResult.value.subscription) {
        const subscription = subscriptionResult.value.subscription
        updates.planType = subscription.plan
        updates.monthlyCost = subscription.amount
        updates.currency = subscription.currency
        updates.renewalDate = subscription.currentPeriodEnd
        updates.isActive = subscription.status === 'active'
      }

      if (quotaResult.status === 'fulfilled' && quotaResult.value.quota) {
        const quota = quotaResult.value.quota
        updates.tokenLimit = quota.limit
      }

      // Update service in database
      await db.aIService.update({
        where: { id: serviceId },
        data: {
          ...updates,
          updatedAt: new Date()
        }
      })

      // Create usage record if we have usage data
      if (usageResult.status === 'fulfilled' && usageResult.value.usage) {
        const usage = usageResult.value.usage
        await this.createUsageRecord(serviceId, usage)
      }

      return {
        success: true,
        message: 'Service synchronized successfully',
        data: {
          usage: usageResult.status === 'fulfilled' ? usageResult.value : null,
          subscription: subscriptionResult.status === 'fulfilled' ? subscriptionResult.value : null,
          quota: quotaResult.status === 'fulfilled' ? quotaResult.value : null,
        }
      }

    } catch (error) {
      console.error(`Sync failed for service ${serviceId}:`, error)
      return {
        success: false,
        message: 'Synchronization failed',
        error: error instanceof Error ? error.message : 'Unknown error'
      }
    }
  }

  async syncAllServices(userId: string): Promise<SyncResult[]> {
    try {
      const services = await db.aIService.findMany({
        where: { 
          userId,
          isActive: true,
          apiKey: { not: null }
        }
      })

      const results = await Promise.allSettled(
        services.map(service => this.syncService(service.id))
      )

      return results.map((result, index) => {
        if (result.status === 'fulfilled') {
          return result.value
        } else {
          return {
            success: false,
            message: 'Sync failed',
            error: result.reason instanceof Error ? result.reason.message : 'Unknown error'
          }
        }
      })

    } catch (error) {
      console.error('Failed to sync all services:', error)
      return [{
        success: false,
        message: 'Failed to sync services',
        error: error instanceof Error ? error.message : 'Unknown error'
      }]
    }
  }

  async startAutoSync(serviceId: string, intervalMinutes: number = 30): Promise<void> {
    // Clear existing interval if any
    this.stopAutoSync(serviceId)

    const intervalMs = intervalMinutes * 60 * 1000
    const interval = setInterval(async () => {
      await this.syncService(serviceId)
    }, intervalMs)

    this.syncIntervals.set(serviceId, interval)

    // Initial sync
    await this.syncService(serviceId)
  }

  stopAutoSync(serviceId: string): void {
    const interval = this.syncIntervals.get(serviceId)
    if (interval) {
      clearInterval(interval)
      this.syncIntervals.delete(serviceId)
    }
  }

  private async createUsageRecord(serviceId: string, usage: any): Promise<UsageRecord> {
    // Calculate cost based on tokens and pricing
    const costPer1kTokens = 0.01 // Default rate
    const cost = (usage.totalTokens / 1000) * costPer1kTokens

    return await db.usageRecord.create({
      data: {
        aiServiceId: serviceId,
        date: new Date(),
        tokensUsed: usage.totalTokens,
        creditsUsed: usage.totalCost,
        cost: cost,
        model: 'sync', // Indicates this is from sync
        endpoint: 'api_sync'
      }
    })
  }

  async getSyncStatus(serviceId: string): Promise<{
    lastSync?: Date
    nextSync?: Date
    isAutoSyncEnabled: boolean
    syncInterval: number
  }> {
    const service = await db.aIService.findUnique({
      where: { id: serviceId },
      select: { updatedAt: true }
    })

    const isAutoSyncEnabled = this.syncIntervals.has(serviceId)
    
    return {
      lastSync: service?.updatedAt,
      nextSync: isAutoSyncEnabled ? new Date(Date.now() + 30 * 60 * 1000) : undefined,
      isAutoSyncEnabled,
      syncInterval: 30 // minutes
    }
  }

  async testServiceConnection(serviceId: string): Promise<SyncResult> {
    try {
      const service = await db.aIService.findUnique({
        where: { id: serviceId }
      })

      if (!service || !service.apiKey) {
        return {
          success: false,
          message: 'Service or API key not found',
          error: 'Service configuration incomplete'
        }
      }

      const provider = createAIProvider(service.provider, {
        apiKey: service.apiKey,
        baseUrl: service.baseUrl || undefined,
      })

      const isConnected = await provider.testConnection()
      
      return {
        success: isConnected,
        message: isConnected ? 'Connection successful' : 'Connection failed',
        error: isConnected ? undefined : 'Unable to connect to provider API'
      }

    } catch (error) {
      return {
        success: false,
        message: 'Connection test failed',
        error: error instanceof Error ? error.message : 'Unknown error'
      }
    }
  }
}