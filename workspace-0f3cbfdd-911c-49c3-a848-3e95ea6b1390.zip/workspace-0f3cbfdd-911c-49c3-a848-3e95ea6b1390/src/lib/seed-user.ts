import { db } from './db'

async function seedUser() {
  try {
    // Check if user already exists
    const existingUser = await db.user.findUnique({
      where: { id: 'user-1' }
    })

    if (existingUser) {
      console.log('User already exists')
      return
    }

    // Create a test user
    const user = await db.user.create({
      data: {
        id: 'user-1',
        email: 'test@example.com',
        name: 'Test User',
        subscriptionTier: 'free',
        subscriptionStatus: 'active'
      }
    })

    console.log('User created successfully:', user.id)
  } catch (error) {
    console.error('Error creating user:', error)
  }
}

// Run the seed function
seedUser()
  .then(() => {
    console.log('Seeding completed')
    process.exit(0)
  })
  .catch((error) => {
    console.error('Seeding failed:', error)
    process.exit(1)
  })