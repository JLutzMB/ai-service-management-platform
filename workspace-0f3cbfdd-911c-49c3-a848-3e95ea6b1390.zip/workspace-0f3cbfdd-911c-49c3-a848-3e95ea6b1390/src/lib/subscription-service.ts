import { db } from './db'
import { User, SubscriptionTier, SubscriptionStatus } from '@prisma/client'

export interface SubscriptionService {
  getUserSubscription(userId: string): Promise<User | null>
  canAddService(userId: string): Promise<boolean>
  getServiceLimit(userId: string): Promise<number>
  upgradeSubscription(userId: string, tier: SubscriptionTier): Promise<User>
  cancelSubscription(userId: string): Promise<User>
  checkSubscriptionStatus(userId: string): Promise<boolean>
}

class SubscriptionServiceImpl implements SubscriptionService {
  async getUserSubscription(userId: string): Promise<User | null> {
    try {
      const user = await db.user.findUnique({
        where: { id: userId }
      })
      return user
    } catch (error) {
      console.error('Error fetching user subscription:', error)
      throw new Error('Failed to fetch subscription')
    }
  }

  async canAddService(userId: string): Promise<boolean> {
    try {
      const user = await this.getUserSubscription(userId)
      if (!user) return false

      const serviceCount = await db.aIService.count({
        where: { userId }
      })

      const limit = this.getServiceLimitByTier(user.subscriptionTier)
      return serviceCount < limit
    } catch (error) {
      console.error('Error checking service limit:', error)
      return false
    }
  }

  async getServiceLimit(userId: string): Promise<number> {
    try {
      const user = await this.getUserSubscription(userId)
      if (!user) return 0

      return this.getServiceLimitByTier(user.subscriptionTier)
    } catch (error) {
      console.error('Error getting service limit:', error)
      return 0
    }
  }

  private getServiceLimitByTier(tier: SubscriptionTier): number {
    switch (tier) {
      case 'free':
        return 2
      case 'pro':
        return Number.MAX_SAFE_INTEGER // Unlimited
      default:
        return 2
    }
  }

  async upgradeSubscription(userId: string, tier: SubscriptionTier): Promise<User> {
    try {
      const updatedUser = await db.user.update({
        where: { id: userId },
        data: {
          subscriptionTier: tier,
          subscriptionStatus: 'active',
          updatedAt: new Date()
        }
      })
      return updatedUser
    } catch (error) {
      console.error('Error upgrading subscription:', error)
      throw new Error('Failed to upgrade subscription')
    }
  }

  async cancelSubscription(userId: string): Promise<User> {
    try {
      const updatedUser = await db.user.update({
        where: { id: userId },
        data: {
          subscriptionStatus: 'cancelled',
          updatedAt: new Date()
        }
      })
      return updatedUser
    } catch (error) {
      console.error('Error cancelling subscription:', error)
      throw new Error('Failed to cancel subscription')
    }
  }

  async checkSubscriptionStatus(userId: string): Promise<boolean> {
    try {
      const user = await this.getUserSubscription(userId)
      if (!user) return false

      // Check if subscription is expired
      if (user.subscriptionExpiresAt && new Date() > user.subscriptionExpiresAt) {
        await db.user.update({
          where: { id: userId },
          data: {
            subscriptionStatus: 'expired',
            updatedAt: new Date()
          }
        })
        return false
      }

      return user.subscriptionStatus === 'active'
    } catch (error) {
      console.error('Error checking subscription status:', error)
      return false
    }
  }

  // Helper methods for pricing
  getSubscriptionPrice(tier: SubscriptionTier, billingCycle: 'monthly' | 'yearly'): number {
    const prices = {
      free: 0,
      pro: {
        monthly: 6.99,
        yearly: 4.99
      }
    }

    return prices[tier][billingCycle]
  }

  getSubscriptionFeatures(tier: SubscriptionTier): string[] {
    const features = {
      free: [
        'Connect up to 2 AI services',
        'Basic usage tracking',
        'Manual sync only',
        'Email notifications',
        'Basic analytics'
      ],
      pro: [
        'Unlimited AI service connections',
        'Real-time sync',
        'Advanced analytics & insights',
        'Cost optimization recommendations',
        'Priority support',
        'Custom notification rules',
        'API access'
      ]
    }

    return features[tier]
  }
}

export const subscriptionService = new SubscriptionServiceImpl()