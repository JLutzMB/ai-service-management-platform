import { db } from './db'

async function cleanupServices() {
  try {
    // Delete inactive services (keep only 2 active ones)
    const result = await db.aIService.deleteMany({
      where: {
        userId: 'cmdypf4pf0006shrbkmv1mk8i',
        isActive: false
      }
    })
    
    console.log('Deleted inactive services:', result.count)
    
    // Check remaining services
    const remainingServices = await db.aIService.findMany({
      where: { userId: 'cmdypf4pf0006shrbkmv1mk8i' }
    })
    
    console.log('Remaining services:', remainingServices.length)
    console.log('Services:', remainingServices.map(s => ({ id: s.id, name: s.name, isActive: s.isActive })))
  } catch (error) {
    console.error('Error cleaning up services:', error)
  }
}

cleanupServices()
  .then(() => {
    console.log('Cleanup completed')
    process.exit(0)
  })
  .catch((error) => {
    console.error('Cleanup failed:', error)
    process.exit(1)
  })