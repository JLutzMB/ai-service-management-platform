import { db } from '@/lib/db'

export interface ForecastData {
  serviceId: string
  serviceName: string
  currentTokens: number
  currentCost: number
  projectedTokens: number
  projectedCost: number
  growthRate: number
  confidence: number
  timeframe: '7d' | '30d' | '90d'
  warnings: string[]
  recommendations: string[]
}

export interface BudgetPrediction {
  userId: string
  currentMonthCost: number
  projectedMonthCost: number
  budgetOverrun: boolean
  overrunAmount: number
  confidence: number
  factors: {
    usageTrend: 'increasing' | 'decreasing' | 'stable'
    seasonality: boolean
    anomalies: boolean
  }
  recommendations: string[]
}

export class ForecastingService {
  private static instance: ForecastingService

  static getInstance(): ForecastingService {
    if (!ForecastingService.instance) {
      ForecastingService.instance = new ForecastingService()
    }
    return ForecastingService.instance
  }

  async generateServiceForecast(
    serviceId: string, 
    timeframe: '7d' | '30d' | '90d' = '30d'
  ): Promise<ForecastData> {
    try {
      // Get service data
      const service = await db.aIService.findUnique({
        where: { id: serviceId }
      })

      if (!service) {
        throw new Error('Service not found')
      }

      // Get historical usage data
      const daysBack = timeframe === '7d' ? 30 : timeframe === '30d' ? 90 : 180
      const startDate = new Date()
      startDate.setDate(startDate.getDate() - daysBack)

      const usageRecords = await db.usageRecord.findMany({
        where: {
          aiServiceId: serviceId,
          date: { gte: startDate }
        },
        orderBy: { date: 'asc' }
      })

      if (usageRecords.length < 7) {
        return {
          serviceId,
          serviceName: service.name,
          currentTokens: service.tokens || 0,
          currentCost: service.credits || 0,
          projectedTokens: service.tokens || 0,
          projectedCost: service.credits || 0,
          growthRate: 0,
          confidence: 0.3,
          timeframe,
          warnings: ['Insufficient historical data for accurate forecasting'],
          recommendations: ['Continue using the service to build up usage history for better forecasts']
        }
      }

      // Calculate trends
      const dailyUsage = this.groupUsageByDay(usageRecords)
      const trendAnalysis = this.analyzeTrend(dailyUsage)
      
      // Calculate seasonality if enough data
      const seasonalityAnalysis = this.detectSeasonality(dailyUsage)
      
      // Detect anomalies
      const anomalies = this.detectAnomalies(dailyUsage)
      
      // Generate forecast
      const forecast = this.generateForecast(
        dailyUsage,
        trendAnalysis,
        seasonalityAnalysis,
        timeframe
      )

      // Calculate projected cost
      const projectedCost = service.pricePer1kTokens 
        ? (forecast.projectedTokens / 1000) * service.pricePer1kTokens
        : forecast.projectedCost

      // Generate warnings and recommendations
      const warnings = this.generateWarnings(
        service,
        forecast,
        trendAnalysis,
        anomalies
      )

      const recommendations = this.generateRecommendations(
        service,
        forecast,
        trendAnalysis,
        seasonalityAnalysis
      )

      return {
        serviceId,
        serviceName: service.name,
        currentTokens: service.tokens || 0,
        currentCost: service.credits || 0,
        projectedTokens: forecast.projectedTokens,
        projectedCost,
        growthRate: trendAnalysis.growthRate,
        confidence: forecast.confidence,
        timeframe,
        warnings,
        recommendations
      }

    } catch (error) {
      console.error('Error generating service forecast:', error)
      throw error
    }
  }

  async generateBudgetPrediction(userId: string): Promise<BudgetPrediction> {
    try {
      // Get current month's usage
      const startOfMonth = new Date()
      startOfMonth.setDate(1)
      startOfMonth.setHours(0, 0, 0, 0)

      const services = await db.aIService.findMany({
        where: { userId, isActive: true }
      })

      const usageRecords = await db.usageRecord.findMany({
        where: {
          aiService: { userId },
          date: { gte: startOfMonth }
        }
      })

      // Calculate current month cost
      const currentMonthCost = usageRecords.reduce((sum, record) => sum + (record.cost || 0), 0)
      
      // Get monthly budget from services
      const totalMonthlyBudget = services.reduce((sum, service) => sum + (service.monthlyCost || 0), 0)

      // Analyze usage patterns
      const dailyUsage = this.groupUsageByDay(usageRecords)
      const trendAnalysis = this.analyzeTrend(dailyUsage)
      
      // Project month-end cost
      const daysInMonth = new Date().getDate()
      const daysRemaining = new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0).getDate() - daysInMonth
      
      const avgDailyCost = dailyUsage.length > 0 
        ? dailyUsage.reduce((sum, day) => sum + day.cost, 0) / dailyUsage.length
        : 0
      
      const projectedMonthCost = currentMonthCost + (avgDailyCost * daysRemaining * trendAnalysis.growthRate)

      // Detect factors
      const factors = {
        usageTrend: trendAnalysis.trend,
        seasonality: this.detectSeasonality(dailyUsage).hasSeasonality,
        anomalies: this.detectAnomalies(dailyUsage).length > 0
      }

      // Generate recommendations
      const recommendations = this.generateBudgetRecommendations(
        currentMonthCost,
        projectedMonthCost,
        totalMonthlyBudget,
        factors
      )

      return {
        userId,
        currentMonthCost,
        projectedMonthCost,
        budgetOverrun: projectedMonthCost > totalMonthlyBudget,
        overrunAmount: Math.max(0, projectedMonthCost - totalMonthlyBudget),
        confidence: Math.min(0.9, Math.max(0.3, dailyUsage.length / 30)),
        factors,
        recommendations
      }

    } catch (error) {
      console.error('Error generating budget prediction:', error)
      throw error
    }
  }

  private groupUsageByDay(usageRecords: any[]): Array<{ date: string; tokens: number; cost: number }> {
    const dailyMap = new Map<string, { tokens: number; cost: number }>()

    usageRecords.forEach(record => {
      const dateKey = record.date.toISOString().split('T')[0]
      if (!dailyMap.has(dateKey)) {
        dailyMap.set(dateKey, { tokens: 0, cost: 0 })
      }
      const day = dailyMap.get(dateKey)!
      day.tokens += record.tokensUsed
      day.cost += record.cost || 0
    })

    return Array.from(dailyMap.entries()).map(([date, data]) => ({
      date,
      tokens: data.tokens,
      cost: data.cost
    })).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
  }

  private analyzeTrend(dailyUsage: Array<{ date: string; tokens: number; cost: number }>) {
    if (dailyUsage.length < 3) {
      return { growthRate: 1, trend: 'stable' as const, rSquared: 0 }
    }

    // Simple linear regression for trend analysis
    const n = dailyUsage.length
    const xValues = dailyUsage.map((_, i) => i)
    const yValues = dailyUsage.map(d => d.tokens)

    const xMean = xValues.reduce((sum, x) => sum + x, 0) / n
    const yMean = yValues.reduce((sum, y) => sum + y, 0) / n

    const numerator = xValues.reduce((sum, x, i) => sum + (x - xMean) * (yValues[i] - yMean), 0)
    const denominator = xValues.reduce((sum, x) => sum + Math.pow(x - xMean, 2), 0)

    const slope = denominator !== 0 ? numerator / denominator : 0
    const growthRate = slope > 0 ? 1 + (slope / yMean) : 1 + (slope / yMean)

    // Calculate R-squared for confidence
    const yPred = xValues.map(x => slope * (x - xMean) + yMean)
    const ssRes = yValues.reduce((sum, y, i) => sum + Math.pow(y - yPred[i], 2), 0)
    const ssTot = yValues.reduce((sum, y) => sum + Math.pow(y - yMean, 2), 0)
    const rSquared = ssTot !== 0 ? 1 - (ssRes / ssTot) : 0

    let trend: 'increasing' | 'decreasing' | 'stable' = 'stable'
    if (slope > yMean * 0.05) trend = 'increasing'
    else if (slope < -yMean * 0.05) trend = 'decreasing'

    return { growthRate, trend, rSquared }
  }

  private detectSeasonality(dailyUsage: Array<{ date: string; tokens: number; cost: number }>) {
    if (dailyUsage.length < 14) {
      return { hasSeasonality: false, pattern: null }
    }

    // Simple seasonality detection - check for weekly patterns
    const weeklyPatterns = new Map<number, number[]>()
    
    dailyUsage.forEach((day, index) => {
      const dayOfWeek = new Date(day.date).getDay()
      if (!weeklyPatterns.has(dayOfWeek)) {
        weeklyPatterns.set(dayOfWeek, [])
      }
      weeklyPatterns.get(dayOfWeek)!.push(day.tokens)
    })

    // Calculate variance for each day of week
    const dayVariances = new Map<number, number>()
    weeklyPatterns.forEach((values, day) => {
      const mean = values.reduce((sum, val) => sum + val, 0) / values.length
      const variance = values.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / values.length
      dayVariances.set(day, variance)
    })

    // Check if there's significant variation between days
    const variances = Array.from(dayVariances.values())
    const meanVariance = variances.reduce((sum, val) => sum + val, 0) / variances.length
    const maxVariance = Math.max(...variances)

    const hasSeasonality = maxVariance > meanVariance * 2

    return {
      hasSeasonality,
      pattern: hasSeasonality ? Array.from(weeklyPatterns.entries()).map(([day, values]) => ({
        day,
        average: values.reduce((sum, val) => sum + val, 0) / values.length
      })) : null
    }
  }

  private detectAnomalies(dailyUsage: Array<{ date: string; tokens: number; cost: number }>) {
    if (dailyUsage.length < 5) return []

    const values = dailyUsage.map(d => d.tokens)
    const mean = values.reduce((sum, val) => sum + val, 0) / values.length
    const variance = values.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / values.length
    const stdDev = Math.sqrt(variance)

    const threshold = 2.5 // 2.5 standard deviations
    const anomalies = []

    for (let i = 0; i < values.length; i++) {
      const zScore = Math.abs((values[i] - mean) / stdDev)
      if (zScore > threshold) {
        anomalies.push({
          index: i,
          date: dailyUsage[i].date,
          value: values[i],
          zScore,
          severity: zScore > 3 ? 'high' : 'medium'
        })
      }
    }

    return anomalies
  }

  private generateForecast(
    dailyUsage: Array<{ date: string; tokens: number; cost: number }>,
    trendAnalysis: { growthRate: number; rSquared: number },
    seasonalityAnalysis: { hasSeasonality: boolean; pattern: any },
    timeframe: '7d' | '30d' | '90d'
  ) {
    const daysToForecast = timeframe === '7d' ? 7 : timeframe === '30d' ? 30 : 90
    const currentTotal = dailyUsage.reduce((sum, day) => sum + day.tokens, 0)
    
    // Base forecast on trend
    let projectedTokens = currentTotal * Math.pow(trendAnalysis.growthRate, daysToForecast / dailyUsage.length)
    
    // Adjust for seasonality if detected
    if (seasonalityAnalysis.hasSeasonality && seasonalityAnalysis.pattern) {
      const seasonalMultiplier = this.calculateSeasonalMultiplier(seasonalityAnalysis.pattern, daysToForecast)
      projectedTokens *= seasonalMultiplier
    }

    // Calculate confidence based on data quality and trend strength
    const confidence = Math.min(0.9, Math.max(0.3, trendAnalysis.rSquared * (dailyUsage.length / 30)))

    return {
      projectedTokens,
      confidence
    }
  }

  private calculateSeasonalMultiplier(pattern: any, daysToForecast: number): number {
    // Simple seasonal adjustment based on day of week patterns
    const today = new Date()
    const futureDates = []
    for (let i = 1; i <= daysToForecast; i++) {
      const futureDate = new Date(today)
      futureDate.setDate(futureDate.getDate() + i)
      futureDates.push(futureDate.getDay())
    }

    const patternMap = new Map(pattern.map((p: any) => [p.day, p.average]))
    const overallAverage = pattern.reduce((sum: number, p: any) => sum + p.average, 0) / pattern.length

    const seasonalSum = futureDates.reduce((sum, dayOfWeek) => {
      const dayAverage = patternMap.get(dayOfWeek) || overallAverage
      return sum + (dayAverage / overallAverage)
    }, 0)

    return seasonalSum / futureDates.length
  }

  private generateWarnings(
    service: any,
    forecast: { projectedTokens: number; confidence: number },
    trendAnalysis: { growthRate: number; trend: string },
    anomalies: any[]
  ): string[] {
    const warnings: string[] = []

    // Check for projected limit exceedance
    if (service.tokenLimit && forecast.projectedTokens > service.tokenLimit * 0.9) {
      warnings.push(`Projected to exceed 90% of token limit within forecast period`)
    }

    // Check for high growth rate
    if (trendAnalysis.growthRate > 1.5) {
      warnings.push(`High growth rate detected (${((trendAnalysis.growthRate - 1) * 100).toFixed(1)}% increase)`)
    }

    // Check for low confidence
    if (forecast.confidence < 0.5) {
      warnings.push(`Low forecast confidence due to limited historical data`)
    }

    // Check for anomalies
    if (anomalies.length > 0) {
      warnings.push(`${anomalies.length} usage anomalies detected in historical data`)
    }

    return warnings
  }

  private generateRecommendations(
    service: any,
    forecast: { projectedTokens: number; confidence: number },
    trendAnalysis: { growthRate: number; trend: string },
    seasonalityAnalysis: { hasSeasonality: boolean }
  ): string[] {
    const recommendations: string[] = []

    // Growth-based recommendations
    if (trendAnalysis.growthRate > 1.2) {
      recommendations.push('Consider upgrading your plan to accommodate increasing usage')
      recommendations.push('Monitor usage closely to avoid unexpected costs')
    } else if (trendAnalysis.growthRate < 0.8) {
      recommendations.push('Consider downgrading your plan to save costs')
      recommendations.push('Review usage patterns to understand the decrease')
    }

    // Seasonality-based recommendations
    if (seasonalityAnalysis.hasSeasonality) {
      recommendations.push('Usage shows seasonal patterns - plan accordingly for peak periods')
      recommendations.push('Consider adjusting budget based on seasonal variations')
    }

    // Confidence-based recommendations
    if (forecast.confidence < 0.5) {
      recommendations.push('Continue using the service to improve forecast accuracy')
      recommendations.push('Monitor usage more frequently until more data is available')
    }

    // General recommendations
    recommendations.push('Set up usage alerts to stay informed about consumption')
    recommendations.push('Review and optimize your API usage patterns regularly')

    return recommendations
  }

  private generateBudgetRecommendations(
    currentCost: number,
    projectedCost: number,
    budget: number,
    factors: { usageTrend: string; seasonality: boolean; anomalies: boolean }
  ): string[] {
    const recommendations: string[] = []

    // Budget overrun recommendations
    if (projectedCost > budget) {
      const overrunPercentage = ((projectedCost - budget) / budget) * 100
      recommendations.push(`Projected to exceed budget by ${overrunPercentage.toFixed(1)}%`)
      recommendations.push('Consider reducing usage or upgrading to a higher tier plan')
      recommendations.push('Review and optimize your most expensive API calls')
    } else {
      const underutilization = ((budget - projectedCost) / budget) * 100
      if (underutilization > 30) {
        recommendations.push(`Budget underutilized by ${underutilization.toFixed(1)}%`)
        recommendations.push('Consider downgrading to a more cost-effective plan')
      }
    }

    // Trend-based recommendations
    if (factors.usageTrend === 'increasing') {
      recommendations.push('Usage is trending upward - monitor closely')
      recommendations.push('Consider setting higher budget limits for future months')
    } else if (factors.usageTrend === 'decreasing') {
      recommendations.push('Usage is trending downward - investigate the cause')
      recommendations.push('Take advantage of lower usage to optimize costs')
    }

    // Seasonality recommendations
    if (factors.seasonality) {
      recommendations.push('Seasonal patterns detected - adjust budgets accordingly')
      recommendations.push('Plan for peak usage periods in advance')
    }

    // Anomaly recommendations
    if (factors.anomalies) {
      recommendations.push('Usage anomalies detected - investigate unusual patterns')
      recommendations.push('Set up alerts for future anomalies')
    }

    return recommendations
  }
}