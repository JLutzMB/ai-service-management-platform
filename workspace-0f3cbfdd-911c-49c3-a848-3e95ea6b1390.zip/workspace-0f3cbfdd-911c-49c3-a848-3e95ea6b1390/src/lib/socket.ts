import { Server } from 'socket.io';

interface ClientUser {
  userId: string;
  socketId: string;
}

export const setupSocket = (io: Server) => {
  // Store connected users
  const connectedUsers = new Map<string, string>(); // userId -> socketId
  
  io.on('connection', (socket) => {
    console.log('Client connected:', socket.id);
    
    // Handle user authentication
    socket.on('authenticate', (data: { userId: string }) => {
      const { userId } = data;
      socket.userId = userId;
      connectedUsers.set(userId, socket.id);
      
      // Join user-specific room
      socket.join(`user:${userId}`);
      
      console.log(`User ${userId} authenticated with socket ${socket.id}`);
      
      // Send confirmation
      socket.emit('authenticated', { success: true, userId });
    });

    // Handle real-time sync updates
    socket.on('sync_update', (data: { 
      userId: string; 
      serviceId: string; 
      data: any;
    }) => {
      // Broadcast to all user's connected devices
      io.to(`user:${data.userId}`).emit('sync_update', {
        serviceId: data.serviceId,
        data: data.data,
        timestamp: new Date().toISOString()
      });
    });

    // Handle notification updates
    socket.on('notification', (data: {
      userId: string;
      notification: any;
    }) => {
      // Send to specific user
      io.to(`user:${data.userId}`).emit('notification', {
        ...data.notification,
        timestamp: new Date().toISOString()
      });
    });

    // Handle insight updates
    socket.on('insight_update', (data: {
      userId: string;
      insight: any;
    }) => {
      // Send to specific user
      io.to(`user:${data.userId}`).emit('insight_update', {
        ...data.insight,
        timestamp: new Date().toISOString()
      });
    });

    // Handle service status changes
    socket.on('service_status', (data: {
      userId: string;
      serviceId: string;
      status: string;
    }) => {
      // Broadcast to user's devices
      io.to(`user:${data.userId}`).emit('service_status', {
        serviceId: data.serviceId,
        status: data.status,
        timestamp: new Date().toISOString()
      });
    });

    // Handle usage alerts
    socket.on('usage_alert', (data: {
      userId: string;
      serviceId: string;
      alert: any;
    }) => {
      // Send urgent alert to user
      io.to(`user:${data.userId}`).emit('usage_alert', {
        serviceId: data.serviceId,
        ...data.alert,
        timestamp: new Date().toISOString()
      });
    });

    // Handle real-time usage updates
    socket.on('usage_update', (data: {
      userId: string;
      serviceId: string;
      usage: any;
    }) => {
      // Broadcast usage update
      io.to(`user:${data.userId}`).emit('usage_update', {
        serviceId: data.serviceId,
        ...data.usage,
        timestamp: new Date().toISOString()
      });
    });

    // Handle system messages
    socket.on('message', (msg: { text: string; senderId: string }) => {
      // Echo: broadcast message only to the client who sent the message
      socket.emit('message', {
        text: `Echo: ${msg.text}`,
        senderId: 'system',
        timestamp: new Date().toISOString(),
      });
    });

    // Handle disconnect
    socket.on('disconnect', () => {
      console.log('Client disconnected:', socket.id);
      
      // Remove from connected users
      if (socket.userId) {
        connectedUsers.delete(socket.userId);
        console.log(`User ${socket.userId} disconnected`);
      }
    });

    // Send welcome message
    socket.emit('message', {
      text: 'Welcome to AI Services Dashboard Real-time Updates!',
      senderId: 'system',
      timestamp: new Date().toISOString(),
    });
  });

  // Helper function to send data to specific user
  io.sendToUser = (userId: string, event: string, data: any) => {
    const socketId = connectedUsers.get(userId);
    if (socketId) {
      io.to(socketId).emit(event, {
        ...data,
        timestamp: new Date().toISOString()
      });
    }
  };

  // Helper function to broadcast to all users
  io.broadcastToAll = (event: string, data: any) => {
    io.emit(event, {
      ...data,
      timestamp: new Date().toISOString()
    });
  };
};