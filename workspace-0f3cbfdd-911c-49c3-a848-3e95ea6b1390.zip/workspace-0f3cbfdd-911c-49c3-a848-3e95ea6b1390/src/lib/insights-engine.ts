import { db } from '@/lib/db'

export interface Insight {
  id: string
  type: 'cost_optimization' | 'usage_pattern' | 'recommendation' | 'anomaly' | 'forecast'
  title: string
  description: string
  impact: 'low' | 'medium' | 'high'
  confidence: number // 0-1
  userId: string
  serviceId?: string
  data: any
  createdAt: Date
  isDismissed: boolean
}

export interface UsagePattern {
  serviceId: string
  serviceName: string
  dailyAverage: number
  weeklyTrend: 'increasing' | 'decreasing' | 'stable'
  peakHours: number[]
  costEfficiency: number
  recommendations: string[]
}

export interface CostOptimization {
  potentialSavings: number
  recommendations: Array<{
    type: string
    description: string
    estimatedSavings: number
    confidence: number
    implementation: string
  }>
}

export class InsightsEngine {
  private static instance: InsightsEngine

  static getInstance(): InsightsEngine {
    if (!InsightsEngine.instance) {
      InsightsEngine.instance = new InsightsEngine()
    }
    return InsightsEngine.instance
  }

  async generateInsights(userId: string): Promise<Insight[]> {
    const insights: Insight[] = []

    try {
      // Get all services for the user
      const services = await db.aIService.findMany({
        where: { userId, isActive: true }
      })

      for (const service of services) {
        // Generate cost optimization insights
        const costInsights = await this.analyzeCostOptimization(service)
        insights.push(...costInsights)

        // Generate usage pattern insights
        const patternInsights = await this.analyzeUsagePatterns(service)
        insights.push(...patternInsights)

        // Generate anomaly detection
        const anomalyInsights = await this.detectAnomalies(service)
        insights.push(...anomalyInsights)

        // Generate recommendations
        const recommendationInsights = await this.generateRecommendations(service)
        insights.push(...recommendationInsights)
      }

      // Generate cross-service insights
      const crossServiceInsights = await this.analyzeCrossServicePatterns(userId)
      insights.push(...crossServiceInsights)

      // Generate forecasting insights
      const forecastInsights = await this.generateForecasts(userId)
      insights.push(...forecastInsights)

      // Save insights to database
      await this.saveInsights(insights)

      return insights

    } catch (error) {
      console.error('Error generating insights:', error)
      return []
    }
  }

  private async analyzeCostOptimization(service: any): Promise<Insight[]> {
    const insights: Insight[] = []

    try {
      // Get usage data for the last 30 days
      const thirtyDaysAgo = new Date()
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30)

      const usageRecords = await db.usageRecord.findMany({
        where: {
          aiServiceId: service.id,
          date: { gte: thirtyDaysAgo }
        }
      })

      if (usageRecords.length === 0) return insights

      const totalCost = usageRecords.reduce((sum, record) => sum + (record.cost || 0), 0)
      const totalTokens = usageRecords.reduce((sum, record) => sum + record.tokensUsed, 0)

      // Analyze cost efficiency
      if (service.pricePer1kTokens) {
        const expectedCost = (totalTokens / 1000) * service.pricePer1kTokens
        const efficiency = expectedCost > 0 ? (totalCost / expectedCost) * 100 : 100

        if (efficiency > 120) {
          insights.push({
            id: `cost-inefficiency-${service.id}-${Date.now()}`,
            type: 'cost_optimization',
            title: 'High Cost Efficiency Detected',
            description: `Your actual cost is ${efficiency.toFixed(1)}% of expected cost for ${service.name}. Consider reviewing your usage patterns.`,
            impact: 'medium',
            confidence: 0.8,
            userId: service.userId,
            serviceId: service.id,
            data: {
              actualCost: totalCost,
              expectedCost,
              efficiency,
              totalTokens
            },
            createdAt: new Date(),
            isDismissed: false
          })
        }
      }

      // Compare with similar services
      const similarServices = await db.aIService.findMany({
        where: {
          userId: service.userId,
          provider: service.provider,
          id: { not: service.id },
          isActive: true
        }
      })

      if (similarServices.length > 0) {
        const avgCostPerToken = similarServices.reduce((sum, s) => {
          return sum + (s.pricePer1kTokens || 0)
        }, 0) / similarServices.length

        if (service.pricePer1kTokens && service.pricePer1kTokens > avgCostPerToken * 1.2) {
          insights.push({
            id: `cost-comparison-${service.id}-${Date.now()}`,
            type: 'cost_optimization',
            title: 'Higher Than Average Pricing',
            description: `${service.name} costs ${(service.pricePer1kTokens / avgCostPerToken * 100).toFixed(1)}% more than similar services.`,
            impact: 'high',
            confidence: 0.9,
            userId: service.userId,
            serviceId: service.id,
            data: {
              currentPrice: service.pricePer1kTokens,
              averagePrice: avgCostPerToken,
              premiumPercentage: ((service.pricePer1kTokens - avgCostPerToken) / avgCostPerToken) * 100
            },
            createdAt: new Date(),
            isDismissed: false
          })
        }
      }

    } catch (error) {
      console.error('Error analyzing cost optimization:', error)
    }

    return insights
  }

  private async analyzeUsagePatterns(service: any): Promise<Insight[]> {
    const insights: Insight[] = []

    try {
      // Get usage data for the last 30 days
      const thirtyDaysAgo = new Date()
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30)

      const usageRecords = await db.usageRecord.findMany({
        where: {
          aiServiceId: service.id,
          date: { gte: thirtyDaysAgo }
        },
        orderBy: { date: 'asc' }
      })

      if (usageRecords.length < 7) return insights

      // Analyze daily usage patterns
      const dailyUsage = new Map<string, number>()
      usageRecords.forEach(record => {
        const date = record.date.toISOString().split('T')[0]
        dailyUsage.set(date, (dailyUsage.get(date) || 0) + record.tokensUsed)
      })

      const usageValues = Array.from(dailyUsage.values())
      const avgDailyUsage = usageValues.reduce((sum, val) => sum + val, 0) / usageValues.length

      // Detect increasing or decreasing trends
      const firstHalf = usageValues.slice(0, Math.floor(usageValues.length / 2))
      const secondHalf = usageValues.slice(Math.floor(usageValues.length / 2))
      
      const firstHalfAvg = firstHalf.reduce((sum, val) => sum + val, 0) / firstHalf.length
      const secondHalfAvg = secondHalf.reduce((sum, val) => sum + val, 0) / secondHalf.length

      const trendChange = ((secondHalfAvg - firstHalfAvg) / firstHalfAvg) * 100

      if (Math.abs(trendChange) > 20) {
        const trend = trendChange > 0 ? 'increasing' : 'decreasing'
        insights.push({
          id: `usage-trend-${service.id}-${Date.now()}`,
          type: 'usage_pattern',
          title: `${trend === 'increasing' ? 'Rising' : 'Declining'} Usage Pattern`,
          description: `${service.name} usage is ${trend} by ${Math.abs(trendChange).toFixed(1)}% compared to the previous period.`,
          impact: trendChange > 0 ? 'medium' : 'low',
          confidence: 0.7,
          userId: service.userId,
          serviceId: service.id,
          data: {
            trend,
            trendChange,
            firstHalfAvg,
            secondHalfAvg,
            avgDailyUsage
          },
          createdAt: new Date(),
          isDismissed: false
        })
      }

      // Detect usage spikes
      const standardDeviation = Math.sqrt(
        usageValues.reduce((sum, val) => sum + Math.pow(val - avgDailyUsage, 2), 0) / usageValues.length
      )

      const spikes = usageValues.filter(val => val > avgDailyUsage + 2 * standardDeviation)
      
      if (spikes.length > 0) {
        insights.push({
          id: `usage-spikes-${service.id}-${Date.now()}`,
          type: 'usage_pattern',
          title: 'Usage Spikes Detected',
          description: `${service.name} had ${spikes.length} usage spikes in the last 30 days, which may indicate unusual activity.`,
          impact: 'medium',
          confidence: 0.8,
          userId: service.userId,
          serviceId: service.id,
          data: {
            spikeCount: spikes.length,
            avgDailyUsage,
            threshold: avgDailyUsage + 2 * standardDeviation,
            spikes
          },
          createdAt: new Date(),
          isDismissed: false
        })
      }

    } catch (error) {
      console.error('Error analyzing usage patterns:', error)
    }

    return insights
  }

  private async detectAnomalies(service: any): Promise<Insight[]> {
    const insights: Insight[] = []

    try {
      // Get recent usage data
      const sevenDaysAgo = new Date()
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7)

      const recentUsage = await db.usageRecord.findMany({
        where: {
          aiServiceId: service.id,
          date: { gte: sevenDaysAgo }
        }
      })

      if (recentUsage.length < 3) return insights

      // Check for unusual cost patterns
      const costs = recentUsage.map(r => r.cost || 0).filter(c => c > 0)
      if (costs.length > 0) {
        const avgCost = costs.reduce((sum, cost) => sum + cost, 0) / costs.length
        const maxCost = Math.max(...costs)

        if (maxCost > avgCost * 3) {
          insights.push({
            id: `cost-anomaly-${service.id}-${Date.now()}`,
            type: 'anomaly',
            title: 'Unusual Cost Pattern Detected',
            description: `${service.name} had an unusually high cost of $${maxCost.toFixed(2)} compared to the average of $${avgCost.toFixed(2)}.`,
            impact: 'high',
            confidence: 0.9,
            userId: service.userId,
            serviceId: service.id,
            data: {
              maxCost,
              avgCost,
              multiple: maxCost / avgCost
            },
            createdAt: new Date(),
            isDismissed: false
          })
        }
      }

      // Check for unusual request patterns
      const tokens = recentUsage.map(r => r.tokensUsed)
      const avgTokens = tokens.reduce((sum, tokens) => sum + tokens, 0) / tokens.length
      const maxTokens = Math.max(...tokens)

      if (maxTokens > avgTokens * 5) {
        insights.push({
          id: `token-anomaly-${service.id}-${Date.now()}`,
          type: 'anomaly',
          title: 'Unusual Token Usage Detected',
          description: `${service.name} had an unusually high token usage of ${maxTokens.toLocaleString()} tokens in a single request.`,
          impact: 'medium',
          confidence: 0.8,
          userId: service.userId,
          serviceId: service.id,
          data: {
            maxTokens,
            avgTokens,
            multiple: maxTokens / avgTokens
          },
          createdAt: new Date(),
          isDismissed: false
        })
      }

    } catch (error) {
      console.error('Error detecting anomalies:', error)
    }

    return insights
  }

  private async generateRecommendations(service: any): Promise<Insight[]> {
    const insights: Insight[] = []

    try {
      // Recommend plan upgrades/downgrades based on usage
      if (service.tokens && service.tokenLimit) {
        const usagePercentage = (service.tokens / service.tokenLimit) * 100

        if (usagePercentage < 20 && service.planType !== 'free') {
          insights.push({
            id: `plan-downgrade-${service.id}-${Date.now()}`,
            type: 'recommendation',
            title: 'Consider Downgrading Your Plan',
            description: `${service.name} usage is only ${usagePercentage.toFixed(1)}% of your current limit. You might save money by downgrading to a lower tier.`,
            impact: 'medium',
            confidence: 0.7,
            userId: service.userId,
            serviceId: service.id,
            data: {
              currentUsage: service.tokens,
              currentLimit: service.tokenLimit,
              usagePercentage,
              currentPlan: service.planType
            },
            createdAt: new Date(),
            isDismissed: false
          })
        } else if (usagePercentage > 90 && service.planType !== 'enterprise') {
          insights.push({
            id: `plan-upgrade-${service.id}-${Date.now()}`,
            type: 'recommendation',
            title: 'Consider Upgrading Your Plan',
            description: `${service.name} usage is at ${usagePercentage.toFixed(1)}% of your current limit. Consider upgrading to avoid service interruptions.`,
            impact: 'high',
            confidence: 0.9,
            userId: service.userId,
            serviceId: service.id,
            data: {
              currentUsage: service.tokens,
              currentLimit: service.tokenLimit,
              usagePercentage,
              currentPlan: service.planType
            },
            createdAt: new Date(),
            isDismissed: false
          })
        }
      }

      // Recommend API key rotation for security
      const lastUpdate = new Date(service.updatedAt)
      const daysSinceUpdate = Math.floor((Date.now() - lastUpdate.getTime()) / (1000 * 60 * 60 * 24))

      if (daysSinceUpdate > 90) {
        insights.push({
          id: `security-rotation-${service.id}-${Date.now()}`,
          type: 'recommendation',
          title: 'API Key Rotation Recommended',
          description: `Your API key for ${service.name} hasn't been updated in ${daysSinceUpdate} days. Consider rotating it for security.`,
          impact: 'medium',
          confidence: 0.6,
          userId: service.userId,
          serviceId: service.id,
          data: {
            daysSinceUpdate,
            lastUpdate: service.updatedAt
          },
          createdAt: new Date(),
          isDismissed: false
        })
      }

    } catch (error) {
      console.error('Error generating recommendations:', error)
    }

    return insights
  }

  private async analyzeCrossServicePatterns(userId: string): Promise<Insight[]> {
    const insights: Insight[] = []

    try {
      const services = await db.aIService.findMany({
        where: { userId, isActive: true }
      })

      if (services.length < 2) return insights

      // Analyze cost distribution across services
      const totalMonthlyCost = services.reduce((sum, service) => sum + (service.monthlyCost || 0), 0)
      
      services.forEach(service => {
        if (service.monthlyCost) {
          const costPercentage = (service.monthlyCost / totalMonthlyCost) * 100
          
          if (costPercentage > 60) {
            insights.push({
              id: `cost-concentration-${service.id}-${Date.now()}`,
              type: 'usage_pattern',
              title: 'High Cost Concentration',
              description: `${service.name} represents ${costPercentage.toFixed(1)}% of your total AI service costs. Consider diversifying to reduce risk.`,
              impact: 'medium',
              confidence: 0.8,
              userId,
              serviceId: service.id,
              data: {
                serviceCost: service.monthlyCost,
                totalCost: totalMonthlyCost,
                costPercentage
              },
              createdAt: new Date(),
              isDismissed: false
            })
          }
        }
      })

      // Identify redundant services
      const providers = new Map<string, any[]>()
      services.forEach(service => {
        if (!providers.has(service.provider)) {
          providers.set(service.provider, [])
        }
        providers.get(service.provider)!.push(service)
      })

      providers.forEach((servicesForProvider, provider) => {
        if (servicesForProvider.length > 1) {
          insights.push({
            id: `redundant-services-${provider}-${Date.now()}`,
            type: 'recommendation',
            title: 'Multiple Services from Same Provider',
            description: `You have ${servicesForProvider.length} services from ${provider}. Consider consolidating to simplify management.`,
            impact: 'low',
            confidence: 0.6,
            userId,
            data: {
              provider,
              serviceCount: servicesForProvider.length,
              services: servicesForProvider.map(s => s.name)
            },
            createdAt: new Date(),
            isDismissed: false
          })
        }
      })

    } catch (error) {
      console.error('Error analyzing cross-service patterns:', error)
    }

    return insights
  }

  private async generateForecasts(userId: string): Promise<Insight[]> {
    const insights: Insight[] = []

    try {
      const services = await db.aIService.findMany({
        where: { userId, isActive: true }
      })

      // Get usage data for the last 90 days
      const ninetyDaysAgo = new Date()
      ninetyDaysAgo.setDate(ninetyDaysAgo.getDate() - 90)

      const usageRecords = await db.usageRecord.findMany({
        where: {
          aiService: { userId },
          date: { gte: ninetyDaysAgo }
        },
        include: {
          aiService: true
        }
      })

      if (usageRecords.length === 0) return insights

      // Group by service and calculate trends
      const serviceTrends = new Map<string, any[]>()
      usageRecords.forEach(record => {
        if (!serviceTrends.has(record.aiServiceId)) {
          serviceTrends.set(record.aiServiceId, [])
        }
        serviceTrends.get(record.aiServiceId)!.push({
          date: record.date,
          tokens: record.tokensUsed,
          cost: record.cost || 0
        })
      })

      // Generate forecasts for each service
      serviceTrends.forEach((trendData, serviceId) => {
        const service = services.find(s => s.id === serviceId)
        if (!service) return

        // Simple linear regression for forecasting
        const sortedData = trendData.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
        
        if (sortedData.length < 10) return

        // Calculate trend
        const tokens = sortedData.map(d => d.tokens)
        const avgTokens = tokens.reduce((sum, t) => sum + t, 0) / tokens.length
        
        // Simple trend calculation (last 10 days vs previous 10 days)
        const recentTokens = tokens.slice(-10)
        const previousTokens = tokens.slice(-20, -10)
        
        if (previousTokens.length > 0) {
          const recentAvg = recentTokens.reduce((sum, t) => sum + t, 0) / recentTokens.length
          const previousAvg = previousTokens.reduce((sum, t) => sum + t, 0) / previousTokens.length
          
          const growthRate = ((recentAvg - previousAvg) / previousAvg) * 100
          
          // Project next 30 days
          const projectedTokens = avgTokens * (1 + growthRate / 100)
          const projectedCost = (projectedTokens / 1000) * (service.pricePer1kTokens || 0.01)

          if (Math.abs(growthRate) > 10) {
            insights.push({
              id: `forecast-${serviceId}-${Date.now()}`,
              type: 'forecast',
              title: `${growthRate > 0 ? 'Increasing' : 'Decreasing'} Usage Forecast`,
              description: `${service.name} usage is trending ${growthRate > 0 ? 'up' : 'down'} by ${Math.abs(growthRate).toFixed(1)}%. Projected next 30 days: ${projectedTokens.toLocaleString()} tokens.`,
              impact: Math.abs(growthRate) > 20 ? 'high' : 'medium',
              confidence: 0.7,
              userId,
              serviceId,
              data: {
                growthRate,
                currentAvg: avgTokens,
                projectedTokens,
                projectedCost,
                timeframe: '30 days'
              },
              createdAt: new Date(),
              isDismissed: false
            })
          }
        }
      })

    } catch (error) {
      console.error('Error generating forecasts:', error)
    }

    return insights
  }

  private async saveInsights(insights: Insight[]): Promise<void> {
    try {
      // Delete old insights for the same user to keep only recent ones
      const userIds = [...new Set(insights.map(i => i.userId))]
      
      for (const userId of userIds) {
        await db.insight.deleteMany({
          where: { 
            userId,
            createdAt: { lt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) } // Keep only last 30 days
          }
        })
      }

      // Save new insights
      await db.insight.createMany({
        data: insights.map(insight => ({
          ...insight,
          createdAt: new Date()
        }))
      })
    } catch (error) {
      console.error('Error saving insights:', error)
    }
  }

  async getInsights(userId: string, type?: string): Promise<Insight[]> {
    const where: any = { 
      userId, 
      isDismissed: false 
    }
    
    if (type) {
      where.type = type
    }

    return await db.insight.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: 50
    })
  }

  async dismissInsight(insightId: string, userId: string): Promise<void> {
    await db.insight.updateMany({
      where: { 
        id: insightId,
        userId
      },
      data: { isDismissed: true }
    })
  }
}