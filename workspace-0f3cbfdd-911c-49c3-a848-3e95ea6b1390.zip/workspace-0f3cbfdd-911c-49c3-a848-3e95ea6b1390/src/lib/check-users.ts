import { db } from './db'

async function checkUsers() {
  try {
    const users = await db.user.findMany()
    console.log('Existing users:', users)
  } catch (error) {
    console.error('Error checking users:', error)
  }
}

checkUsers()
  .then(() => {
    console.log('Check completed')
    process.exit(0)
  })
  .catch((error) => {
    console.error('Check failed:', error)
    process.exit(1)
  })