import { db } from '@/lib/db'

export interface OptimizationOpportunity {
  id: string
  type: 'plan_downgrade' | 'plan_upgrade' | 'provider_switch' | 'usage_optimization' | 'reservation_commitment'
  title: string
  description: string
  impact: 'low' | 'medium' | 'high'
  estimatedSavings: number
  confidence: number
  implementation: string
  timeframe: 'immediate' | 'short_term' | 'long_term'
  serviceId?: string
  serviceName?: string
  currentPlan?: string
  recommendedPlan?: string
}

export interface CostAnalysis {
  userId: string
  totalMonthlyCost: number
  potentialSavings: number
  optimizationScore: number // 0-100
  opportunities: OptimizationOpportunity[]
  summary: {
    highImpactOpportunities: number
    mediumImpactOpportunities: number
    lowImpactOpportunities: number
    immediateActions: number
    shortTermActions: number
    longTermActions: number
  }
}

export class CostOptimizationEngine {
  private static instance: CostOptimizationEngine

  static getInstance(): CostOptimizationEngine {
    if (!CostOptimizationEngine.instance) {
      CostOptimizationEngine.instance = new CostOptimizationEngine()
    }
    return CostOptimizationEngine.instance
  }

  async analyzeCosts(userId: string): Promise<CostAnalysis> {
    try {
      // Get user's services
      const services = await db.aIService.findMany({
        where: { userId, isActive: true }
      })

      // Get usage data for analysis
      const ninetyDaysAgo = new Date()
      ninetyDaysAgo.setDate(ninetyDaysAgo.getDate() - 90)

      const usageRecords = await db.usageRecord.findMany({
        where: {
          aiService: { userId },
          date: { gte: ninetyDaysAgo }
        },
        include: {
          aiService: true
        }
      })

      // Generate optimization opportunities
      const opportunities: OptimizationOpportunity[] = []

      // Analyze each service
      for (const service of services) {
        const serviceOpportunities = await this.analyzeService(service, usageRecords)
        opportunities.push(...serviceOpportunities)
      }

      // Analyze cross-service patterns
      const crossServiceOpportunities = await this.analyzeCrossServicePatterns(services, usageRecords)
      opportunities.push(...crossServiceOpportunities)

      // Calculate total current cost
      const totalMonthlyCost = services.reduce((sum, service) => sum + (service.monthlyCost || 0), 0)

      // Calculate potential savings
      const potentialSavings = opportunities.reduce((sum, opp) => sum + opp.estimatedSavings, 0)

      // Calculate optimization score
      const optimizationScore = this.calculateOptimizationScore(opportunities, totalMonthlyCost)

      // Summarize opportunities
      const summary = {
        highImpactOpportunities: opportunities.filter(opp => opp.impact === 'high').length,
        mediumImpactOpportunities: opportunities.filter(opp => opp.impact === 'medium').length,
        lowImpactOpportunities: opportunities.filter(opp => opp.impact === 'low').length,
        immediateActions: opportunities.filter(opp => opp.timeframe === 'immediate').length,
        shortTermActions: opportunities.filter(opp => opp.timeframe === 'short_term').length,
        longTermActions: opportunities.filter(opp => opp.timeframe === 'long_term').length
      }

      return {
        userId,
        totalMonthlyCost,
        potentialSavings,
        optimizationScore,
        opportunities: opportunities.sort((a, b) => b.estimatedSavings - a.estimatedSavings),
        summary
      }

    } catch (error) {
      console.error('Error analyzing costs:', error)
      throw error
    }
  }

  private async analyzeService(service: any, usageRecords: any[]): Promise<OptimizationOpportunity[]> {
    const opportunities: OptimizationOpportunity[] = []
    const serviceUsage = usageRecords.filter(record => record.aiServiceId === service.id)

    // Plan downgrade analysis
    if (service.planType && service.planType !== 'free') {
      const downgradeOpp = this.analyzePlanDowngrade(service, serviceUsage)
      if (downgradeOpp) opportunities.push(downgradeOpp)
    }

    // Plan upgrade analysis
    const upgradeOpp = this.analyzePlanUpgrade(service, serviceUsage)
    if (upgradeOpp) opportunities.push(upgradeOpp)

    // Usage optimization analysis
    const usageOpp = this.analyzeUsageOptimization(service, serviceUsage)
    if (usageOpp) opportunities.push(usageOpp)

    // Provider switch analysis
    const providerSwitchOpp = await this.analyzeProviderSwitch(service, serviceUsage)
    if (providerSwitchOpp) opportunities.push(providerSwitchOpp)

    return opportunities
  }

  private analyzePlanDowngrade(service: any, usageRecords: any[]): OptimizationOpportunity | null {
    if (!service.tokens || !service.tokenLimit) return null

    const usagePercentage = (service.tokens / service.tokenLimit) * 100
    
    // Only suggest downgrade if usage is consistently low
    if (usagePercentage > 40) return null

    // Check if usage has been consistently low
    const thirtyDaysAgo = new Date()
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30)
    
    const recentUsage = usageRecords.filter(record => new Date(record.date) >= thirtyDaysAgo)
    if (recentUsage.length < 7) return null

    const avgDailyUsage = recentUsage.reduce((sum, record) => sum + record.tokensUsed, 0) / recentUsage.length
    const projectedMonthlyUsage = avgDailyUsage * 30
    const projectedUsagePercentage = (projectedMonthlyUsage / service.tokenLimit) * 100

    if (projectedUsagePercentage > 60) return null

    // Calculate potential savings
    const currentCost = service.monthlyCost || 0
    let recommendedPlan = 'free'
    let recommendedCost = 0

    if (service.planType === 'enterprise') {
      recommendedPlan = 'pro'
      recommendedCost = 20 // Assume pro plan costs $20
    } else if (service.planType === 'pro') {
      recommendedPlan = 'free'
      recommendedCost = 0
    }

    const estimatedSavings = currentCost - recommendedCost

    if (estimatedSavings <= 0) return null

    return {
      id: `downgrade-${service.id}-${Date.now()}`,
      type: 'plan_downgrade',
      title: `Downgrade ${service.name} Plan`,
      description: `Your usage is consistently low (${projectedUsagePercentage.toFixed(1)}% of limit). Consider downgrading from ${service.planType} to ${recommendedPlan}.`,
      impact: estimatedSavings > 20 ? 'high' : 'medium',
      estimatedSavings,
      confidence: 0.8,
      implementation: 'Contact provider support to downgrade your plan',
      timeframe: 'short_term',
      serviceId: service.id,
      serviceName: service.name,
      currentPlan: service.planType,
      recommendedPlan
    }
  }

  private analyzePlanUpgrade(service: any, usageRecords: any[]): OptimizationOpportunity | null {
    if (!service.tokens || !service.tokenLimit) return null

    const usagePercentage = (service.tokens / service.tokenLimit) * 100
    
    // Only suggest upgrade if usage is consistently high
    if (usagePercentage < 80) return null

    // Check if usage has been consistently high
    const thirtyDaysAgo = new Date()
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30)
    
    const recentUsage = usageRecords.filter(record => new Date(record.date) >= thirtyDaysAgo)
    if (recentUsage.length < 7) return null

    const avgDailyUsage = recentUsage.reduce((sum, record) => sum + record.tokensUsed, 0) / recentUsage.length
    const projectedMonthlyUsage = avgDailyUsage * 30
    const projectedUsagePercentage = (projectedMonthlyUsage / service.tokenLimit) * 100

    if (projectedUsagePercentage < 90) return null

    // Calculate potential savings from avoiding overage costs
    const currentCost = service.monthlyCost || 0
    let recommendedPlan = 'enterprise'
    let recommendedCost = 50 // Assume enterprise plan costs $50

    if (service.planType === 'free') {
      recommendedPlan = 'pro'
      recommendedCost = 20
    } else if (service.planType === 'pro') {
      recommendedPlan = 'enterprise'
      recommendedCost = 50
    }

    // Estimate overage costs (assume $0.10 per 1k tokens over limit)
    const overageTokens = Math.max(0, projectedMonthlyUsage - service.tokenLimit)
    const overageCost = (overageTokens / 1000) * 0.10
    
    const estimatedSavings = overageCost - (recommendedCost - currentCost)

    if (estimatedSavings <= 0) return null

    return {
      id: `upgrade-${service.id}-${Date.now()}`,
      type: 'plan_upgrade',
      title: `Upgrade ${service.name} Plan`,
      description: `Your usage is consistently high (${projectedUsagePercentage.toFixed(1)}% of limit). Upgrading will prevent overage charges.`,
      impact: estimatedSavings > 30 ? 'high' : 'medium',
      estimatedSavings,
      confidence: 0.9,
      implementation: 'Contact provider support to upgrade your plan',
      timeframe: 'immediate',
      serviceId: service.id,
      serviceName: service.name,
      currentPlan: service.planType,
      recommendedPlan
    }
  }

  private analyzeUsageOptimization(service: any, usageRecords: any[]): OptimizationOpportunity | null {
    if (usageRecords.length < 10) return null

    // Analyze usage patterns for optimization opportunities
    const costs = usageRecords.map(r => r.cost || 0).filter(c => c > 0)
    if (costs.length === 0) return null

    const avgCost = costs.reduce((sum, cost) => sum + cost, 0) / costs.length
    const maxCost = Math.max(...costs)
    
    // Look for unusually high cost requests
    const highCostThreshold = avgCost * 3
    const highCostRequests = costs.filter(cost => cost > highCostThreshold)

    if (highCostRequests.length === 0) return null

    // Estimate potential savings from optimizing high-cost requests
    const potentialSavingsPerRequest = (highCostThreshold - avgCost) * 0.5 // Assume 50% optimization possible
    const totalPotentialSavings = potentialSavingsPerRequest * highCostRequests.length

    if (totalPotentialSavings < 1) return null // Only suggest if savings are significant

    return {
      id: `usage-opt-${service.id}-${Date.now()}`,
      type: 'usage_optimization',
      title: `Optimize ${service.name} Usage Patterns`,
      description: `Found ${highCostRequests.length} high-cost requests that could be optimized for better efficiency.`,
      impact: totalPotentialSavings > 20 ? 'high' : 'medium',
      estimatedSavings: totalPotentialSavings,
      confidence: 0.7,
      implementation: 'Review API calls and implement caching, batching, or model optimization',
      timeframe: 'short_term',
      serviceId: service.id,
      serviceName: service.name
    }
  }

  private async analyzeProviderSwitch(service: any, usageRecords: any[]): Promise<OptimizationOpportunity | null> {
    // Mock provider pricing data
    const providerPricing = {
      'OpenAI': { gpt4: 0.03, gpt35: 0.0015 },
      'Anthropic': { claude3: 0.015 },
      'Google': { gemini: 0.002 },
      'Microsoft': { azure: 0.02 }
    }

    if (!service.pricePer1kTokens) return null

    // Find cheaper alternatives
    const currentProvider = service.provider
    const currentPrice = service.pricePer1kTokens
    
    let bestAlternative = null
    let bestSavings = 0

    for (const [provider, pricing] of Object.entries(providerPricing)) {
      if (provider === currentProvider) continue
      
      // Find the cheapest model from this provider
      const minPrice = Math.min(...Object.values(pricing))
      
      if (minPrice < currentPrice) {
        const savings = (currentPrice - minPrice) / currentPrice
        if (savings > bestSavings) {
          bestSavings = savings
          bestAlternative = { provider, price: minPrice }
        }
      }
    }

    if (!bestAlternative || bestSavings < 0.1) return null // Only suggest if >10% savings

    // Calculate monthly savings based on usage
    const monthlyTokens = usageRecords
      .filter(r => new Date(r.date) >= new Date(Date.now() - 30 * 24 * 60 * 60 * 1000))
      .reduce((sum, r) => sum + r.tokensUsed, 0)
    
    const monthlySavings = (monthlyTokens / 1000) * (currentPrice - bestAlternative.price)

    if (monthlySavings < 5) return null // Only suggest if savings are significant

    return {
      id: `provider-switch-${service.id}-${Date.now()}`,
      type: 'provider_switch',
      title: `Switch ${service.name} Provider`,
      description: `${bestAlternative.provider} offers similar services at ${bestAlternative.price.toFixed(3)}/1k tokens vs your current ${currentPrice.toFixed(3)}/1k tokens.`,
      impact: monthlySavings > 50 ? 'high' : 'medium',
      estimatedSavings: monthlySavings,
      confidence: 0.6,
      implementation: `Migrate from ${currentProvider} to ${bestAlternative.provider}. May require code changes.`,
      timeframe: 'long_term',
      serviceId: service.id,
      serviceName: service.name
    }
  }

  private async analyzeCrossServicePatterns(services: any[], usageRecords: any[]): Promise<OptimizationOpportunity[]> {
    const opportunities: OptimizationOpportunity[] = []

    // Analyze for redundant services
    const providerGroups = new Map<string, any[]>()
    services.forEach(service => {
      if (!providerGroups.has(service.provider)) {
        providerGroups.set(service.provider, [])
      }
      providerGroups.get(service.provider)!.push(service)
    })

    for (const [provider, providerServices] of providerGroups) {
      if (providerServices.length > 1) {
        const totalCost = providerServices.reduce((sum, s) => sum + (s.monthlyCost || 0), 0)
        
        // Suggest consolidation if there are multiple services from same provider
        opportunities.push({
          id: `consolidate-${provider}-${Date.now()}`,
          type: 'usage_optimization',
          title: `Consolidate ${provider} Services`,
          description: `You have ${providerServices.length} services from ${provider}. Consolidating could simplify management and reduce costs.`,
          impact: totalCost > 100 ? 'high' : 'medium',
          estimatedSavings: totalCost * 0.1, // Assume 10% savings from consolidation
          confidence: 0.5,
          implementation: 'Review services and consolidate similar ones under a single plan',
          timeframe: 'long_term'
        })
      }
    }

    // Analyze for cost concentration risk
    const totalCost = services.reduce((sum, s) => sum + (s.monthlyCost || 0), 0)
    const mostExpensiveService = services.reduce((max, service) => 
      (service.monthlyCost || 0) > (max.monthlyCost || 0) ? service : max
    )

    if (mostExpensiveService.monthlyCost && totalCost > 0) {
      const concentration = (mostExpensiveService.monthlyCost / totalCost) * 100
      
      if (concentration > 60) {
        opportunities.push({
          id: `diversify-${Date.now()}`,
          type: 'usage_optimization',
          title: 'Diversify Service Providers',
          description: `${mostExpensiveService.name} represents ${concentration.toFixed(1)}% of your total costs. Consider diversifying to reduce risk.`,
          impact: concentration > 80 ? 'high' : 'medium',
          estimatedSavings: totalCost * 0.05, // Assume 5% savings from risk reduction
          confidence: 0.4,
          implementation: 'Add alternative providers to reduce dependency on a single service',
          timeframe: 'long_term'
        })
      }
    }

    return opportunities
  }

  private calculateOptimizationScore(opportunities: OptimizationOpportunity[], totalCost: number): number {
    if (totalCost === 0) return 0

    const totalSavings = opportunities.reduce((sum, opp) => sum + opp.estimatedSavings, 0)
    const savingsPercentage = (totalSavings / totalCost) * 100

    // Weight by confidence and impact
    const weightedScore = opportunities.reduce((sum, opp) => {
      const impactWeight = opp.impact === 'high' ? 3 : opp.impact === 'medium' ? 2 : 1
      return sum + (opp.confidence * impactWeight * opp.estimatedSavings)
    }, 0)

    const maxPossibleScore = totalCost * 3 // High confidence, high impact = weight 3
    const score = Math.min(100, (weightedScore / maxPossibleScore) * 100)

    return Math.round(score)
  }
}