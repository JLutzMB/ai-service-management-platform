import { AIServiceConfig } from './ai-services-directory';

export interface AuthCredentials {
  type: 'oauth' | 'api-key' | 'none';
  accessToken?: string;
  refreshToken?: string;
  apiKey?: string;
  expiresAt?: Date;
  additionalData?: Record<string, any>;
}

export interface AuthProvider {
  name: string;
  getServiceConfig(): AIServiceConfig;
  initializeAuth(userId: string): Promise<AuthInitResult>;
  handleCallback(code: string, state: string, userId: string): Promise<AuthCredentials>;
  validateCredentials(credentials: AuthCredentials): Promise<boolean>;
  refreshCredentials?(credentials: AuthCredentials): Promise<AuthCredentials>;
  getAuthUrl?(state: string): string;
}

export interface AuthInitResult {
  authUrl?: string;
  requiresInput?: boolean;
  inputFields?: AuthInputField[];
  message?: string;
}

export interface AuthInputField {
  name: string;
  label: string;
  type: 'text' | 'password' | 'select';
  required: boolean;
  placeholder?: string;
  options?: { value: string; label: string }[];
}

// OpenAI Authentication Provider
class OpenAIAuthProvider implements AuthProvider {
  name = 'OpenAI';
  
  getServiceConfig(): AIServiceConfig {
    return {
      id: 'openai',
      name: 'OpenAI',
      description: 'Leading AI research company with GPT models for text generation, coding, and more',
      category: 'text',
      website: 'https://openai.com',
      logo: 'https://openai.com/favicon.ico',
      authType: 'api-key',
      features: ['GPT-4', 'GPT-3.5', 'DALL-E', 'Code Interpreter', 'Plugins'],
      pricing: 'Pay-as-you-go',
      hasFreeTier: false,
      popularity: 10
    };
  }

  async initializeAuth(userId: string): Promise<AuthInitResult> {
    return {
      requiresInput: true,
      inputFields: [
        {
          name: 'apiKey',
          label: 'OpenAI API Key',
          type: 'password',
          required: true,
          placeholder: 'sk-...'
        }
      ],
      message: 'Enter your OpenAI API key from https://platform.openai.com/api-keys'
    };
  }

  async handleCallback(code: string, state: string, userId: string): Promise<AuthCredentials> {
    throw new Error('OpenAI does not use OAuth callback');
  }

  async validateCredentials(credentials: AuthCredentials): Promise<boolean> {
    if (!credentials.apiKey) return false;
    
    try {
      // Test the API key with a simple request
      const response = await fetch('https://api.openai.com/v1/models', {
        headers: {
          'Authorization': `Bearer ${credentials.apiKey}`,
          'Content-Type': 'application/json'
        }
      });
      
      return response.ok;
    } catch (error) {
      console.error('OpenAI API key validation failed:', error);
      return false;
    }
  }
}

// Anthropic Authentication Provider
class AnthropicAuthProvider implements AuthProvider {
  name = 'Anthropic';
  
  getServiceConfig(): AIServiceConfig {
    return {
      id: 'anthropic',
      name: 'Anthropic',
      description: 'AI safety company developing Claude, a helpful and harmless AI assistant',
      category: 'text',
      website: 'https://anthropic.com',
      logo: 'https://anthropic.com/favicon.ico',
      authType: 'api-key',
      features: ['Claude 3', 'Claude 2', 'Constitutional AI', 'Long context'],
      pricing: 'Subscription & Pay-as-you-go',
      hasFreeTier: true,
      popularity: 9
    };
  }

  async initializeAuth(userId: string): Promise<AuthInitResult> {
    return {
      requiresInput: true,
      inputFields: [
        {
          name: 'apiKey',
          label: 'Anthropic API Key',
          type: 'password',
          required: true,
          placeholder: 'sk-ant-...'
        }
      ],
      message: 'Enter your Anthropic API key from https://console.anthropic.com'
    };
  }

  async handleCallback(code: string, state: string, userId: string): Promise<AuthCredentials> {
    throw new Error('Anthropic does not use OAuth callback');
  }

  async validateCredentials(credentials: AuthCredentials): Promise<boolean> {
    if (!credentials.apiKey) return false;
    
    try {
      // Test the API key with a simple request
      const response = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'x-api-key': credentials.apiKey,
          'Content-Type': 'application/json',
          'anthropic-version': '2023-06-01'
        },
        body: JSON.stringify({
          max_tokens: 10,
          messages: [{ role: 'user', content: 'test' }],
          model: 'claude-3-haiku-20240307'
        })
      });
      
      return response.ok;
    } catch (error) {
      console.error('Anthropic API key validation failed:', error);
      return false;
    }
  }
}

// Google Gemini Authentication Provider
class GoogleGeminiAuthProvider implements AuthProvider {
  name = 'Google Gemini';
  
  getServiceConfig(): AIServiceConfig {
    return {
      id: 'google-gemini',
      name: 'Google Gemini',
      description: 'Google\'s advanced AI model with multimodal capabilities',
      category: 'multimodal',
      website: 'https://gemini.google.com',
      logo: 'https://gemini.google.com/favicon.ico',
      authType: 'oauth',
      authUrl: 'https://accounts.google.com/oauth2/auth',
      scopes: ['https://www.googleapis.com/auth/generative-language'],
      features: ['Gemini Pro', 'Gemini Ultra', 'Multimodal', 'Code generation'],
      pricing: 'Free tier available',
      hasFreeTier: true,
      popularity: 9
    };
  }

  async initializeAuth(userId: string): Promise<AuthInitResult> {
    return {
      message: 'Redirecting to Google for authorization...'
    };
  }

  getAuthUrl(state: string): string {
    const params = new URLSearchParams({
      client_id: process.env.GOOGLE_CLIENT_ID || '',
      redirect_uri: `${process.env.NEXT_PUBLIC_APP_URL}/api/auth/google/callback`,
      response_type: 'code',
      scope: 'https://www.googleapis.com/auth/generative-language',
      access_type: 'offline',
      prompt: 'consent',
      state
    });

    return `https://accounts.google.com/oauth2/auth?${params.toString()}`;
  }

  async handleCallback(code: string, state: string, userId: string): Promise<AuthCredentials> {
    try {
      // Exchange code for tokens
      const tokenResponse = await fetch('https://oauth2.googleapis.com/token', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: new URLSearchParams({
          client_id: process.env.GOOGLE_CLIENT_ID || '',
          client_secret: process.env.GOOGLE_CLIENT_SECRET || '',
          code,
          redirect_uri: `${process.env.NEXT_PUBLIC_APP_URL}/api/auth/google/callback`,
          grant_type: 'authorization_code'
        })
      });

      const tokenData = await tokenResponse.json();
      
      if (!tokenResponse.ok) {
        throw new Error(tokenData.error || 'Failed to exchange code for tokens');
      }

      return {
        type: 'oauth',
        accessToken: tokenData.access_token,
        refreshToken: tokenData.refresh_token,
        expiresAt: new Date(Date.now() + tokenData.expires_in * 1000)
      };
    } catch (error) {
      console.error('Google OAuth callback failed:', error);
      throw error;
    }
  }

  async validateCredentials(credentials: AuthCredentials): Promise<boolean> {
    if (!credentials.accessToken) return false;
    
    try {
      // Test the access token
      const response = await fetch('https://generativelanguage.googleapis.com/v1/models', {
        headers: {
          'Authorization': `Bearer ${credentials.accessToken}`,
          'Content-Type': 'application/json'
        }
      });
      
      return response.ok;
    } catch (error) {
      console.error('Google Gemini token validation failed:', error);
      return false;
    }
  }

  async refreshCredentials(credentials: AuthCredentials): Promise<AuthCredentials> {
    if (!credentials.refreshToken) {
      throw new Error('No refresh token available');
    }

    try {
      const response = await fetch('https://oauth2.googleapis.com/token', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: new URLSearchParams({
          client_id: process.env.GOOGLE_CLIENT_ID || '',
          client_secret: process.env.GOOGLE_CLIENT_SECRET || '',
          refresh_token: credentials.refreshToken,
          grant_type: 'refresh_token'
        })
      });

      const tokenData = await response.json();
      
      if (!response.ok) {
        throw new Error(tokenData.error || 'Failed to refresh token');
      }

      return {
        ...credentials,
        accessToken: tokenData.access_token,
        expiresAt: new Date(Date.now() + tokenData.expires_in * 1000)
      };
    } catch (error) {
      console.error('Google token refresh failed:', error);
      throw error;
    }
  }
}

// GitHub Copilot Authentication Provider
class GitHubCopilotAuthProvider implements AuthProvider {
  name = 'GitHub Copilot';
  
  getServiceConfig(): AIServiceConfig {
    return {
      id: 'github-copilot',
      name: 'GitHub Copilot',
      description: 'AI pair programmer that helps you write better code',
      category: 'code',
      website: 'https://github.com/features/copilot',
      logo: 'https://github.com/favicon.ico',
      authType: 'oauth',
      authUrl: 'https://github.com/login/oauth/authorize',
      scopes: ['read:user', 'user:email'],
      features: ['Code completion', 'Chat', 'CLI integration', 'Enterprise features'],
      pricing: 'Subscription',
      hasFreeTier: false,
      popularity: 9
    };
  }

  async initializeAuth(userId: string): Promise<AuthInitResult> {
    return {
      message: 'Redirecting to GitHub for authorization...'
    };
  }

  getAuthUrl(state: string): string {
    const params = new URLSearchParams({
      client_id: process.env.GITHUB_CLIENT_ID || '',
      redirect_uri: `${process.env.NEXT_PUBLIC_APP_URL}/api/auth/github/callback`,
      response_type: 'code',
      scope: 'read:user user:email',
      state
    });

    return `https://github.com/login/oauth/authorize?${params.toString()}`;
  }

  async handleCallback(code: string, state: string, userId: string): Promise<AuthCredentials> {
    try {
      // Exchange code for tokens
      const tokenResponse = await fetch('https://github.com/login/oauth/access_token', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Accept': 'application/json'
        },
        body: new URLSearchParams({
          client_id: process.env.GITHUB_CLIENT_ID || '',
          client_secret: process.env.GITHUB_CLIENT_SECRET || '',
          code,
          redirect_uri: `${process.env.NEXT_PUBLIC_APP_URL}/api/auth/github/callback`,
          grant_type: 'authorization_code'
        })
      });

      const tokenData = await tokenResponse.json();
      
      if (!tokenResponse.ok) {
        throw new Error(tokenData.error || 'Failed to exchange code for tokens');
      }

      return {
        type: 'oauth',
        accessToken: tokenData.access_token,
        expiresAt: new Date(Date.now() + (tokenData.expires_in || 3600) * 1000)
      };
    } catch (error) {
      console.error('GitHub OAuth callback failed:', error);
      throw error;
    }
  }

  async validateCredentials(credentials: AuthCredentials): Promise<boolean> {
    if (!credentials.accessToken) return false;
    
    try {
      // Test the access token
      const response = await fetch('https://api.github.com/user', {
        headers: {
          'Authorization': `Bearer ${credentials.accessToken}`,
          'Accept': 'application/vnd.github.v3+json'
        }
      });
      
      return response.ok;
    } catch (error) {
      console.error('GitHub token validation failed:', error);
      return false;
    }
  }
}

// Midjourney Authentication Provider (Discord-based)
class MidjourneyAuthProvider implements AuthProvider {
  name = 'Midjourney';
  
  getServiceConfig(): AIServiceConfig {
    return {
      id: 'midjourney',
      name: 'Midjourney',
      description: 'AI-powered image generation service through Discord',
      category: 'image',
      website: 'https://midjourney.com',
      logo: 'https://midjourney.com/favicon.ico',
      authType: 'oauth',
      authUrl: 'https://discord.com/oauth2/authorize',
      scopes: ['identify', 'bot'],
      features: ['High-quality images', 'Artistic styles', 'Upscaling', 'Variations'],
      pricing: 'Subscription plans',
      hasFreeTier: false,
      popularity: 10
    };
  }

  async initializeAuth(userId: string): Promise<AuthInitResult> {
    return {
      requiresInput: true,
      inputFields: [
        {
          name: 'discordUsername',
          label: 'Discord Username',
          type: 'text',
          required: true,
          placeholder: 'username#1234'
        }
      ],
      message: 'Enter your Discord username and authorize with Midjourney bot'
    };
  }

  getAuthUrl(state: string): string {
    const params = new URLSearchParams({
      client_id: process.env.DISCORD_CLIENT_ID || '',
      redirect_uri: `${process.env.NEXT_PUBLIC_APP_URL}/api/auth/discord/callback`,
      response_type: 'code',
      scope: 'identify bot',
      permissions: '2048', // Send messages permission
      state
    });

    return `https://discord.com/oauth2/authorize?${params.toString()}`;
  }

  async handleCallback(code: string, state: string, userId: string): Promise<AuthCredentials> {
    try {
      // Exchange code for tokens
      const tokenResponse = await fetch('https://discord.com/api/oauth2/token', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: new URLSearchParams({
          client_id: process.env.DISCORD_CLIENT_ID || '',
          client_secret: process.env.DISCORD_CLIENT_SECRET || '',
          code,
          redirect_uri: `${process.env.NEXT_PUBLIC_APP_URL}/api/auth/discord/callback`,
          grant_type: 'authorization_code'
        })
      });

      const tokenData = await tokenResponse.json();
      
      if (!tokenResponse.ok) {
        throw new Error(tokenData.error || 'Failed to exchange code for tokens');
      }

      return {
        type: 'oauth',
        accessToken: tokenData.access_token,
        refreshToken: tokenData.refresh_token,
        expiresAt: new Date(Date.now() + tokenData.expires_in * 1000)
      };
    } catch (error) {
      console.error('Discord OAuth callback failed:', error);
      throw error;
    }
  }

  async validateCredentials(credentials: AuthCredentials): Promise<boolean> {
    if (!credentials.accessToken) return false;
    
    try {
      // Test the access token
      const response = await fetch('https://discord.com/api/users/@me', {
        headers: {
          'Authorization': `Bearer ${credentials.accessToken}`
        }
      });
      
      return response.ok;
    } catch (error) {
      console.error('Discord token validation failed:', error);
      return false;
    }
  }
}

// Authentication Provider Registry
class AuthProviderRegistry {
  private providers: Map<string, AuthProvider> = new Map();

  constructor() {
    this.registerProvider('openai', new OpenAIAuthProvider());
    this.registerProvider('anthropic', new AnthropicAuthProvider());
    this.registerProvider('google-gemini', new GoogleGeminiAuthProvider());
    this.registerProvider('github-copilot', new GitHubCopilotAuthProvider());
    this.registerProvider('midjourney', new MidjourneyAuthProvider());
  }

  registerProvider(serviceId: string, provider: AuthProvider): void {
    this.providers.set(serviceId, provider);
  }

  getProvider(serviceId: string): AuthProvider | undefined {
    return this.providers.get(serviceId);
  }

  getAllProviders(): AuthProvider[] {
    return Array.from(this.providers.values());
  }

  hasProvider(serviceId: string): boolean {
    return this.providers.has(serviceId);
  }
}

// Export singleton instance
export const authProviderRegistry = new AuthProviderRegistry();

// Helper functions
export function getAuthProvider(serviceId: string): AuthProvider | undefined {
  return authProviderRegistry.getProvider(serviceId);
}

export function getAllAuthProviders(): AuthProvider[] {
  return authProviderRegistry.getAllProviders();
}

export function hasAuthProvider(serviceId: string): boolean {
  return authProviderRegistry.hasProvider(serviceId);
}