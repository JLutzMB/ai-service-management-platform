import { db } from './db'

async function deleteOneService() {
  try {
    // Delete one service to test the limit
    const result = await db.aIService.delete({
      where: { 
        id: 'cmdypf7b00008shrbnip3llmw' // Google Gemini
      }
    })
    
    console.log('Deleted service:', result.name)
    
    // Check remaining services
    const remainingServices = await db.aIService.findMany({
      where: { userId: 'cmdypf4pf0006shrbkmv1mk8i' }
    })
    
    console.log('Remaining services:', remainingServices.length)
    console.log('Services:', remainingServices.map(s => ({ id: s.id, name: s.name, isActive: s.isActive })))
  } catch (error) {
    console.error('Error deleting service:', error)
  }
}

deleteOneService()
  .then(() => {
    console.log('Delete completed')
    process.exit(0)
  })
  .catch((error) => {
    console.error('Delete failed:', error)
    process.exit(1)
  })