export interface AIServiceConfig {
  id: string;
  name: string;
  description: string;
  category: 'text' | 'image' | 'audio' | 'video' | 'code' | 'multimodal';
  website: string;
  logo: string;
  logoEmoji?: string; // Fallback emoji for logos
  authType: 'oauth' | 'api-key' | 'none';
  authUrl?: string;
  scopes?: string[];
  features: string[];
  pricing: string;
  hasFreeTier: boolean;
  popularity: number; // 1-10
  connectionMethod: string; // User-friendly description of how to connect
  setupDifficulty: 'easy' | 'medium' | 'hard'; // How easy it is to set up
}

export const AI_SERVICES_DIRECTORY: AIServiceConfig[] = [
  // Text Generation & Chat
  {
    id: 'openai',
    name: 'OpenAI',
    description: 'Leading AI research company with GPT-4, GPT-3.5, DALL-E, and more advanced AI models',
    category: 'text',
    website: 'https://openai.com',
    logo: 'https://openai.com/favicon.ico',
    logoEmoji: '🤖',
    authType: 'api-key',
    features: ['GPT-4', 'GPT-3.5', 'DALL-E', 'Code Interpreter', 'Plugins', 'Whisper'],
    pricing: 'Pay-as-you-go',
    hasFreeTier: false,
    popularity: 10,
    connectionMethod: 'Enter your OpenAI API key from dashboard',
    setupDifficulty: 'easy'
  },
  {
    id: 'anthropic',
    name: 'Anthropic',
    description: 'AI safety company developing Claude, a helpful and harmless AI assistant',
    category: 'text',
    website: 'https://anthropic.com',
    logo: 'https://anthropic.com/favicon.ico',
    logoEmoji: '🧠',
    authType: 'api-key',
    features: ['Claude 3 Opus', 'Claude 3 Sonnet', 'Claude 3 Haiku', '200K context', 'Analysis'],
    pricing: 'Subscription & Pay-as-you-go',
    hasFreeTier: true,
    popularity: 9,
    connectionMethod: 'Enter your Anthropic API key from console',
    setupDifficulty: 'easy'
  },
  {
    id: 'google-gemini',
    name: 'Google Gemini',
    description: 'Google\'s advanced AI model with multimodal capabilities and deep integration',
    category: 'multimodal',
    website: 'https://gemini.google.com',
    logo: 'https://gemini.google.com/favicon.ico',
    logoEmoji: '🔍',
    authType: 'oauth',
    authUrl: 'https://accounts.google.com/oauth2/auth',
    scopes: ['https://www.googleapis.com/auth/generative-language'],
    features: ['Gemini Pro', 'Gemini Ultra', 'Multimodal', 'Code generation', 'Image analysis'],
    pricing: 'Free tier available',
    hasFreeTier: true,
    popularity: 9,
    connectionMethod: 'Sign in with Google account',
    setupDifficulty: 'easy'
  },
  {
    id: 'cohere',
    name: 'Cohere',
    description: 'Enterprise AI platform for large language models and business applications',
    category: 'text',
    website: 'https://cohere.com',
    logo: 'https://cohere.com/favicon.ico',
    logoEmoji: '🏢',
    authType: 'api-key',
    features: ['Command R+', 'Embed v3', 'Rerank v3', 'Classify', 'Enterprise security'],
    pricing: 'Pay-as-you-go',
    hasFreeTier: true,
    popularity: 7,
    connectionMethod: 'Enter your Cohere API key from dashboard',
    setupDifficulty: 'easy'
  },
  {
    id: 'perplexity',
    name: 'Perplexity AI',
    description: 'AI-powered search engine with real-time information and citations',
    category: 'text',
    website: 'https://perplexity.ai',
    logo: 'https://perplexity.ai/favicon.ico',
    logoEmoji: '🔎',
    authType: 'api-key',
    features: ['Real-time search', 'Citations', 'Pro search', 'Code interpreter', 'File upload'],
    pricing: 'Free & Pro tiers',
    hasFreeTier: true,
    popularity: 8,
    connectionMethod: 'Enter your Perplexity API key from settings',
    setupDifficulty: 'easy'
  },
  {
    id: 'groq',
    name: 'Groq',
    description: 'Ultra-fast AI inference with Llama and Mixtral models',
    category: 'text',
    website: 'https://groq.com',
    logo: 'https://groq.com/favicon.ico',
    logoEmoji: '⚡',
    authType: 'api-key',
    features: ['Llama 3', 'Mixtral', 'Ultra-fast inference', 'Low latency'],
    pricing: 'Free tier available',
    hasFreeTier: true,
    popularity: 8,
    connectionMethod: 'Enter your Groq API key from console',
    setupDifficulty: 'easy'
  },

  // Image Generation
  {
    id: 'midjourney',
    name: 'Midjourney',
    description: 'AI-powered image generation service through Discord with stunning artistic results',
    category: 'image',
    website: 'https://midjourney.com',
    logo: 'https://midjourney.com/favicon.ico',
    logoEmoji: '🎨',
    authType: 'oauth',
    authUrl: 'https://discord.com/oauth2/authorize',
    scopes: ['identify', 'bot'],
    features: ['High-quality images', 'Artistic styles', 'Upscaling', 'Variations', 'V6'],
    pricing: 'Subscription plans',
    hasFreeTier: false,
    popularity: 10,
    connectionMethod: 'Connect Discord account and authorize Midjourney bot',
    setupDifficulty: 'medium'
  },
  {
    id: 'stability-ai',
    name: 'Stability AI',
    description: 'Open-source AI models for image, audio, and video generation',
    category: 'image',
    website: 'https://stability.ai',
    logo: 'https://stability.ai/favicon.ico',
    logoEmoji: '🖼️',
    authType: 'api-key',
    features: ['Stable Diffusion 3', 'SDXL Turbo', 'DreamStudio', 'API access'],
    pricing: 'Pay-as-you-go',
    hasFreeTier: true,
    popularity: 8,
    connectionMethod: 'Enter your Stability AI API key',
    setupDifficulty: 'easy'
  },
  {
    id: 'leonardo-ai',
    name: 'Leonardo AI',
    description: 'AI image generation platform with trained models and real-time canvas',
    category: 'image',
    website: 'https://leonardo.ai',
    logo: 'https://leonardo.ai/favicon.ico',
    logoEmoji: '🎭',
    authType: 'api-key',
    features: ['Custom models', '3D assets', 'Image generation', 'Real-time canvas'],
    pricing: 'Free & paid plans',
    hasFreeTier: true,
    popularity: 8,
    connectionMethod: 'Enter your Leonardo AI API key',
    setupDifficulty: 'easy'
  },
  {
    id: 'runway',
    name: 'Runway',
    description: 'AI video and image generation tools for creators and professionals',
    category: 'video',
    website: 'https://runwayml.com',
    logo: 'https://runwayml.com/favicon.ico',
    logoEmoji: '🎬',
    authType: 'oauth',
    authUrl: 'https://runwayml.com/oauth/authorize',
    scopes: ['read', 'write'],
    features: ['Gen-2', 'Gen-3 Alpha', 'Video generation', 'Image editing', 'Motion brush'],
    pricing: 'Subscription plans',
    hasFreeTier: true,
    popularity: 9,
    connectionMethod: 'Sign in with Runway account',
    setupDifficulty: 'easy'
  },
  {
    id: 'dalle-3',
    name: 'DALL-E 3',
    description: 'OpenAI\'s advanced image generation model integrated with ChatGPT',
    category: 'image',
    website: 'https://openai.com/dall-e-3',
    logo: 'https://openai.com/favicon.ico',
    logoEmoji: '🖼️',
    authType: 'api-key',
    features: ['Text-to-image', 'Image editing', 'High resolution', 'Safety filters'],
    pricing: 'Pay-as-you-go',
    hasFreeTier: false,
    popularity: 9,
    connectionMethod: 'Use your OpenAI API key (requires DALL-E access)',
    setupDifficulty: 'easy'
  },

  // Audio Generation
  {
    id: 'suno-ai',
    name: 'Suno AI',
    description: 'AI music generation platform for creating songs from text prompts',
    category: 'audio',
    website: 'https://suno.ai',
    logo: 'https://suno.ai/favicon.ico',
    logoEmoji: '🎵',
    authType: 'oauth',
    authUrl: 'https://suno.ai/oauth/authorize',
    scopes: ['read', 'write'],
    features: ['Music generation', 'Vocal synthesis', 'Style transfer', 'Lyrics', 'v3'],
    pricing: 'Free & Pro plans',
    hasFreeTier: true,
    popularity: 9,
    connectionMethod: 'Sign in with Suno account',
    setupDifficulty: 'easy'
  },
  {
    id: 'elevenlabs',
    name: 'ElevenLabs',
    description: 'AI voice synthesis and cloning technology with realistic results',
    category: 'audio',
    website: 'https://elevenlabs.io',
    logo: 'https://elevenlabs.io/favicon.ico',
    logoEmoji: '🗣️',
    authType: 'api-key',
    features: ['Voice cloning', 'Text-to-speech', 'Voice design', 'Sound effects', 'Multilingual'],
    pricing: 'Pay-as-you-go',
    hasFreeTier: true,
    popularity: 8,
    connectionMethod: 'Enter your ElevenLabs API key',
    setupDifficulty: 'easy'
  },
  {
    id: 'mubert',
    name: 'Mubert',
    description: 'AI music generation for content creators and businesses',
    category: 'audio',
    website: 'https://mubert.com',
    logo: 'https://mubert.com/favicon.ico',
    logoEmoji: '🎶',
    authType: 'api-key',
    features: ['Background music', 'Royalty-free', 'Custom tracks', 'API access'],
    pricing: 'Subscription plans',
    hasFreeTier: true,
    popularity: 7,
    connectionMethod: 'Enter your Mubert API key',
    setupDifficulty: 'easy'
  },
  {
    id: 'udio',
    name: 'Udio',
    description: 'AI music generation platform with high-quality output and styles',
    category: 'audio',
    website: 'https://udio.com',
    logo: 'https://udio.com/favicon.ico',
    logoEmoji: '🎼',
    authType: 'oauth',
    authUrl: 'https://udio.com/oauth/authorize',
    scopes: ['read', 'write'],
    features: ['Music generation', 'Style transfer', 'Lyrics', 'High quality'],
    pricing: 'Free & Pro tiers',
    hasFreeTier: true,
    popularity: 8,
    connectionMethod: 'Sign in with Udio account',
    setupDifficulty: 'easy'
  },

  // Video Generation
  {
    id: 'pika-labs',
    name: 'Pika Labs',
    description: 'AI video generation from text and images with realistic results',
    category: 'video',
    website: 'https://pika.art',
    logo: 'https://pika.art/favicon.ico',
    logoEmoji: '🎥',
    authType: 'oauth',
    authUrl: 'https://pika.art/oauth/authorize',
    scopes: ['read', 'write'],
    features: ['Text-to-video', 'Image-to-video', 'Video editing', '3D animation', 'Lip sync'],
    pricing: 'Subscription plans',
    hasFreeTier: true,
    popularity: 8,
    connectionMethod: 'Sign in with Pika Labs account',
    setupDifficulty: 'easy'
  },
  {
    id: 'heygen',
    name: 'HeyGen',
    description: 'AI video generation with talking avatars and multiple languages',
    category: 'video',
    website: 'https://heygen.com',
    logo: 'https://heygen.com/favicon.ico',
    logoEmoji: '👤',
    authType: 'api-key',
    features: ['Talking avatars', 'Lip sync', 'Multi-language', 'Templates', 'API access'],
    pricing: 'Subscription plans',
    hasFreeTier: true,
    popularity: 7,
    connectionMethod: 'Enter your HeyGen API key',
    setupDifficulty: 'easy'
  },
  {
    id: 'hailuo',
    name: 'Hailuo AI',
    description: 'AI video generation platform with advanced features and templates',
    category: 'video',
    website: 'https://hailuo.ai',
    logo: 'https://hailuo.ai/favicon.ico',
    logoEmoji: '🌟',
    authType: 'oauth',
    authUrl: 'https://hailuo.ai/oauth/authorize',
    scopes: ['read', 'write'],
    features: ['Video generation', 'AI avatars', 'Script generation', 'Voiceovers'],
    pricing: 'Subscription plans',
    hasFreeTier: true,
    popularity: 7,
    connectionMethod: 'Sign in with Hailuo account',
    setupDifficulty: 'easy'
  },
  {
    id: 'luma-dream-machine',
    name: 'Luma Dream Machine',
    description: 'AI video generation with high-quality output and realistic motion',
    category: 'video',
    website: 'https://lumalabs.ai',
    logo: 'https://lumalabs.ai/favicon.ico',
    logoEmoji: '💭',
    authType: 'api-key',
    features: ['Text-to-video', 'Image-to-video', 'Realistic motion', 'High quality'],
    pricing: 'Pay-as-you-go',
    hasFreeTier: true,
    popularity: 8,
    connectionMethod: 'Enter your Luma Labs API key',
    setupDifficulty: 'easy'
  },

  // Code & Development
  {
    id: 'github-copilot',
    name: 'GitHub Copilot',
    description: 'AI pair programmer that helps you write better code faster',
    category: 'code',
    website: 'https://github.com/features/copilot',
    logo: 'https://github.com/favicon.ico',
    logoEmoji: '💻',
    authType: 'oauth',
    authUrl: 'https://github.com/login/oauth/authorize',
    scopes: ['read:user', 'user:email'],
    features: ['Code completion', 'Chat', 'CLI integration', 'Enterprise features', 'Copilot X'],
    pricing: 'Subscription',
    hasFreeTier: false,
    popularity: 9,
    connectionMethod: 'Sign in with GitHub account',
    setupDifficulty: 'easy'
  },
  {
    id: 'tabnine',
    name: 'Tabnine',
    description: 'AI code completion tool that works with your IDE and respects privacy',
    category: 'code',
    website: 'https://tabnine.com',
    logo: 'https://tabnine.com/favicon.ico',
    logoEmoji: '🔧',
    authType: 'api-key',
    features: ['Code completion', 'Multi-language', 'Privacy-focused', 'Team features'],
    pricing: 'Free & Pro plans',
    hasFreeTier: true,
    popularity: 7,
    connectionMethod: 'Enter your Tabnine API key',
    setupDifficulty: 'easy'
  },
  {
    id: 'replit-ghostwriter',
    name: 'Replit Ghostwriter',
    description: 'AI coding assistant integrated with Replit\'s online IDE',
    category: 'code',
    website: 'https://replit.com',
    logo: 'https://replit.com/favicon.ico',
    logoEmoji: '👻',
    authType: 'oauth',
    authUrl: 'https://replit.com/oauth/authorize',
    scopes: ['read', 'write'],
    features: ['Code generation', 'Debugging', 'Explain code', 'Complete code'],
    pricing: 'Subscription',
    hasFreeTier: true,
    popularity: 6,
    connectionMethod: 'Sign in with Replit account',
    setupDifficulty: 'easy'
  },
  {
    id: 'cursor',
    name: 'Cursor',
    description: 'AI-powered code editor with advanced features and ChatGPT integration',
    category: 'code',
    website: 'https://cursor.sh',
    logo: 'https://cursor.sh/favicon.ico',
    logoEmoji: '🖱️',
    authType: 'api-key',
    features: ['AI chat', 'Code generation', 'Debugging', 'Multi-model support'],
    pricing: 'Free & Pro plans',
    hasFreeTier: true,
    popularity: 8,
    connectionMethod: 'Enter your Cursor API key or OpenAI key',
    setupDifficulty: 'easy'
  },

  // Multimodal & Specialized
  {
    id: 'character-ai',
    name: 'Character AI',
    description: 'Chat with AI characters and create your own personalities',
    category: 'text',
    website: 'https://character.ai',
    logo: 'https://character.ai/favicon.ico',
    logoEmoji: '🎭',
    authType: 'oauth',
    authUrl: 'https://character.ai/oauth/authorize',
    scopes: ['read', 'write'],
    features: ['Character creation', 'Chat', 'Voice chat', 'Group chats', 'Character calls'],
    pricing: 'Free & Premium',
    hasFreeTier: true,
    popularity: 8,
    connectionMethod: 'Sign in with Character AI account',
    setupDifficulty: 'easy'
  },
  {
    id: 'claude',
    name: 'Claude',
    description: 'Anthropic\'s AI assistant for helpful and harmless interactions',
    category: 'text',
    website: 'https://claude.ai',
    logo: 'https://claude.ai/favicon.ico',
    logoEmoji: '🧠',
    authType: 'oauth',
    authUrl: 'https://claude.ai/oauth/authorize',
    scopes: ['read', 'write'],
    features: ['Chat', 'Code help', 'Analysis', 'Long context', 'File upload'],
    pricing: 'Free & Pro',
    hasFreeTier: true,
    popularity: 9,
    connectionMethod: 'Sign in with Claude account',
    setupDifficulty: 'easy'
  },
  {
    id: 'deepseek',
    name: 'DeepSeek',
    description: 'Advanced AI models for coding, math, and reasoning tasks',
    category: 'code',
    website: 'https://deepseek.com',
    logo: 'https://deepseek.com/favicon.ico',
    logoEmoji: '🔮',
    authType: 'api-key',
    features: ['DeepSeek-V2', 'DeepSeek-Coder', 'Math reasoning', 'Chat', 'API access'],
    pricing: 'Free & Paid',
    hasFreeTier: true,
    popularity: 7,
    connectionMethod: 'Enter your DeepSeek API key',
    setupDifficulty: 'easy'
  },
  {
    id: 'mistral',
    name: 'Mistral AI',
    description: 'European AI company with open-source and commercial models',
    category: 'text',
    website: 'https://mistral.ai',
    logo: 'https://mistral.ai/favicon.ico',
    logoEmoji: '🇪🇺',
    authType: 'api-key',
    features: ['Mistral 7B', 'Mixtral 8x7B', 'Codestral', 'Embeddings', 'API access'],
    pricing: 'Pay-as-you-go',
    hasFreeTier: true,
    popularity: 8,
    connectionMethod: 'Enter your Mistral AI API key',
    setupDifficulty: 'easy'
  },
  {
    id: 'replicate',
    name: 'Replicate',
    description: 'Platform for running and fine-tuning open-source AI models',
    category: 'multimodal',
    website: 'https://replicate.com',
    logo: 'https://replicate.com/favicon.ico',
    logoEmoji: '🔁',
    authType: 'api-key',
    features: ['Thousands of models', 'Fine-tuning', 'API access', 'Open source'],
    pricing: 'Pay-as-you-go',
    hasFreeTier: true,
    popularity: 7,
    connectionMethod: 'Enter your Replicate API token',
    setupDifficulty: 'easy'
  }
];

export function getAIServiceById(id: string): AIServiceConfig | undefined {
  return AI_SERVICES_DIRECTORY.find(service => service.id === id);
}

export function getAIServicesByCategory(category: string): AIServiceConfig[] {
  return AI_SERVICES_DIRECTORY.filter(service => service.category === category);
}

export function searchAIServices(query: string): AIServiceConfig[] {
  const lowercaseQuery = query.toLowerCase();
  return AI_SERVICES_DIRECTORY.filter(service => 
    service.name.toLowerCase().includes(lowercaseQuery) ||
    service.description.toLowerCase().includes(lowercaseQuery) ||
    service.features.some(feature => feature.toLowerCase().includes(lowercaseQuery))
  );
}

export function getPopularAIServices(limit: number = 10): AIServiceConfig[] {
  return AI_SERVICES_DIRECTORY
    .sort((a, b) => b.popularity - a.popularity)
    .slice(0, limit);
}

export function getAIServicesWithFreeTier(): AIServiceConfig[] {
  return AI_SERVICES_DIRECTORY.filter(service => service.hasFreeTier);
}