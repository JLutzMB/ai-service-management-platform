import axios from 'axios'

export interface AIProviderConfig {
  apiKey: string
  baseUrl?: string
  organization?: string
}

export interface UsageData {
  totalTokens: number
  totalCost: number
  requests: number
  periodStart: string
  periodEnd: string
}

export interface SubscriptionData {
  plan: string
  status: 'active' | 'inactive' | 'cancelled' | 'past_due'
  currentPeriodStart: string
  currentPeriodEnd: string
  amount: number
  currency: string
}

export interface QuotaData {
  limit: number
  used: number
  remaining: number
  resetsAt: string
}

export interface ProviderResponse {
  usage?: UsageData
  subscription?: SubscriptionData
  quota?: QuotaData
  models?: Array<{
    id: string
    name: string
    pricing: {
      input: number
      output: number
    }
  }>
}

export abstract class AIProvider {
  protected config: AIProviderConfig
  protected httpClient: any

  constructor(config: AIProviderConfig) {
    this.config = config
    this.httpClient = axios.create({
      baseURL: config.baseUrl,
      headers: {
        'Authorization': `Bearer ${config.apiKey}`,
        'Content-Type': 'application/json',
      },
    })
  }

  abstract fetchUsage(): Promise<ProviderResponse>
  abstract fetchSubscription(): Promise<ProviderResponse>
  abstract fetchQuota(): Promise<ProviderResponse>
  abstract testConnection(): Promise<boolean>

  protected async makeRequest(endpoint: string, options = {}): Promise<any> {
    try {
      const response = await this.httpClient.get(endpoint, options)
      return response.data
    } catch (error) {
      console.error(`AI Provider request failed: ${error}`)
      throw error
    }
  }
}

export class OpenAIProvider extends AIProvider {
  constructor(config: AIProviderConfig) {
    super({
      ...config,
      baseUrl: config.baseUrl || 'https://api.openai.com/v1',
    })
  }

  async testConnection(): Promise<boolean> {
    try {
      await this.makeRequest('/models')
      return true
    } catch {
      return false
    }
  }

  async fetchUsage(): Promise<ProviderResponse> {
    try {
      // Note: OpenAI doesn't have a direct usage endpoint in the API
      // This would typically require accessing the billing dashboard
      // For now, we'll return a mock response structure
      return {
        usage: {
          totalTokens: 0,
          totalCost: 0,
          requests: 0,
          periodStart: new Date().toISOString(),
          periodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
        }
      }
    } catch (error) {
      throw new Error(`Failed to fetch OpenAI usage: ${error}`)
    }
  }

  async fetchSubscription(): Promise<ProviderResponse> {
    try {
      // This would typically require accessing the billing API
      // For demonstration, we'll return a mock structure
      return {
        subscription: {
          plan: 'pro',
          status: 'active',
          currentPeriodStart: new Date().toISOString(),
          currentPeriodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
          amount: 20,
          currency: 'USD',
        }
      }
    } catch (error) {
      throw new Error(`Failed to fetch OpenAI subscription: ${error}`)
    }
  }

  async fetchQuota(): Promise<ProviderResponse> {
    try {
      // OpenAI doesn't have a direct quota endpoint
      // This would need to be calculated from usage and billing limits
      return {
        quota: {
          limit: 1000000,
          used: 0,
          remaining: 1000000,
          resetsAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
        }
      }
    } catch (error) {
      throw new Error(`Failed to fetch OpenAI quota: ${error}`)
    }
  }
}

export class AnthropicProvider extends AIProvider {
  constructor(config: AIProviderConfig) {
    super({
      ...config,
      baseUrl: config.baseUrl || 'https://api.anthropic.com',
    })
  }

  async testConnection(): Promise<boolean> {
    try {
      await this.httpClient.post('/v1/messages', {
        model: 'claude-3-haiku-20240307',
        max_tokens: 10,
        messages: [{ role: 'user', content: 'test' }],
      })
      return true
    } catch {
      return false
    }
  }

  async fetchUsage(): Promise<ProviderResponse> {
    try {
      // Anthropic usage endpoint (if available)
      const response = await this.makeRequest('/v1/messages')
      return {
        usage: {
          totalTokens: 0,
          totalCost: 0,
          requests: 0,
          periodStart: new Date().toISOString(),
          periodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
        }
      }
    } catch (error) {
      throw new Error(`Failed to fetch Anthropic usage: ${error}`)
    }
  }

  async fetchSubscription(): Promise<ProviderResponse> {
    try {
      return {
        subscription: {
          plan: 'pro',
          status: 'active',
          currentPeriodStart: new Date().toISOString(),
          currentPeriodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
          amount: 15,
          currency: 'USD',
        }
      }
    } catch (error) {
      throw new Error(`Failed to fetch Anthropic subscription: ${error}`)
    }
  }

  async fetchQuota(): Promise<ProviderResponse> {
    try {
      return {
        quota: {
          limit: 1500000,
          used: 0,
          remaining: 1500000,
          resetsAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
        }
      }
    } catch (error) {
      throw new Error(`Failed to fetch Anthropic quota: ${error}`)
    }
  }
}

export class GoogleProvider extends AIProvider {
  constructor(config: AIProviderConfig) {
    super({
      ...config,
      baseUrl: config.baseUrl || 'https://generativelanguage.googleapis.com/v1beta',
    })
  }

  async testConnection(): Promise<boolean> {
    try {
      await this.makeRequest('/models')
      return true
    } catch {
      return false
    }
  }

  async fetchUsage(): Promise<ProviderResponse> {
    try {
      return {
        usage: {
          totalTokens: 0,
          totalCost: 0,
          requests: 0,
          periodStart: new Date().toISOString(),
          periodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
        }
      }
    } catch (error) {
      throw new Error(`Failed to fetch Google usage: ${error}`)
    }
  }

  async fetchSubscription(): Promise<ProviderResponse> {
    try {
      return {
        subscription: {
          plan: 'enterprise',
          status: 'active',
          currentPeriodStart: new Date().toISOString(),
          currentPeriodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
          amount: 50,
          currency: 'USD',
        }
      }
    } catch (error) {
      throw new Error(`Failed to fetch Google subscription: ${error}`)
    }
  }

  async fetchQuota(): Promise<ProviderResponse> {
    try {
      return {
        quota: {
          limit: 5000000,
          used: 0,
          remaining: 5000000,
          resetsAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
        }
      }
    } catch (error) {
      throw new Error(`Failed to fetch Google quota: ${error}`)
    }
  }
}

export function createAIProvider(provider: string, config: AIProviderConfig): AIProvider {
  switch (provider.toLowerCase()) {
    case 'openai':
      return new OpenAIProvider(config)
    case 'anthropic':
      return new AnthropicProvider(config)
    case 'google':
      return new GoogleProvider(config)
    default:
      throw new Error(`Unsupported provider: ${provider}`)
  }
}