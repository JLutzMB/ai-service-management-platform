import { db } from './db'

async function checkServices() {
  try {
    const services = await db.aIService.findMany({
      where: { userId: 'cmdypf4pf0006shrbkmv1mk8i' }
    })
    console.log('User services:', services)
    console.log('Service count:', services.length)
  } catch (error) {
    console.error('Error checking services:', error)
  }
}

checkServices()
  .then(() => {
    console.log('Check completed')
    process.exit(0)
  })
  .catch((error) => {
    console.error('Check failed:', error)
    process.exit(1)
  })